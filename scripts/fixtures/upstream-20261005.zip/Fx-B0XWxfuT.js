import{r as C,j as u,f as Qa,g as cs,h as Ir,i as ls}from"./index-ChaQPnFI.js";const fs={sm:{borderRadius:32,borderWidth:1,width:70,height:36},md:{borderRadius:16,borderWidth:1},line:{borderRadius:16,borderWidth:1},"pulse-outside":{borderRadius:16,borderWidth:1},"pulse-inner":{borderRadius:16,borderWidth:1}},ds={sm:{dark:{strokeOpacity:.46,innerOpacity:.24,bloomOpacity:.38,innerShadow:"rgba(255, 255, 255, 0.3)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.3,bloomOpacity:.16,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.8}},md:{dark:{strokeOpacity:.26,innerOpacity:.42,bloomOpacity:.24,innerShadow:"rgba(255, 255, 255, 0.27)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.26,bloomOpacity:.34,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.5}},line:{dark:{strokeOpacity:1.14,innerOpacity:.7,bloomOpacity:.8,innerShadow:"rgba(255, 255, 255, 0.1)",saturation:1.2},light:{strokeOpacity:.16,innerOpacity:.32,bloomOpacity:.3,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.95}},"pulse-outside":{dark:{strokeOpacity:.94,innerOpacity:.34,bloomOpacity:.3,innerShadow:"transparent",saturation:1.2,brightness:1.9,hairlineOpacity:0},light:{strokeOpacity:1.96,innerOpacity:1.04,bloomOpacity:.42,innerShadow:"transparent",saturation:.6,brightness:1.7,hairlineOpacity:0}},"pulse-inner":{dark:{strokeOpacity:1.54,innerOpacity:.44,bloomOpacity:.66,innerShadow:"transparent",saturation:1.2,brightness:.75},light:{strokeOpacity:.32,innerOpacity:.4,bloomOpacity:.8,innerShadow:"transparent",saturation:.75,brightness:1.3}}},wt={colorful:{border:[{color:"rgb(255, 50, 100)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(40, 140, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(50, 200, 80)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(30, 185, 170)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(100, 70, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(40, 140, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 120, 40)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(240, 50, 180)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(180, 40, 240)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 60, 80)",secondary:"rgba(40, 190, 180, 0.98)"},spikeLt:{primary:"rgb(200, 30, 60)",secondary:"rgb(20, 150, 140)"}},mono:{border:[{color:"rgb(180, 180, 180)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(140, 140, 140)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(160, 160, 160)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(130, 130, 130)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(170, 170, 170)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(150, 150, 150)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(190, 190, 190)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(145, 145, 145)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(165, 165, 165)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(200, 200, 200)",secondary:"rgb(170, 170, 170)"},spikeLt:{primary:"rgb(80, 80, 80)",secondary:"rgb(120, 120, 120)"}},ocean:{border:[{color:"rgb(100, 80, 220)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(60, 120, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(80, 100, 200)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(50, 140, 220)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(120, 80, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(70, 130, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(140, 100, 240)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(90, 110, 230)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(130, 70, 255)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(100, 120, 255)",secondary:"rgba(130, 100, 220, 0.98)"},spikeLt:{primary:"rgb(60, 60, 180)",secondary:"rgb(80, 100, 200)"}},sunset:{border:[{color:"rgb(255, 80, 50)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(255, 160, 40)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(255, 120, 60)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(255, 200, 50)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(255, 100, 80)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(255, 180, 60)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 60, 60)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(255, 140, 50)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(255, 90, 70)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 140, 80)",secondary:"rgba(255, 100, 60, 0.98)"},spikeLt:{primary:"rgb(200, 80, 40)",secondary:"rgb(220, 120, 30)"}},forest:{border:[{color:"rgb(46, 160, 90)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(30, 190, 120)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(70, 180, 70)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(20, 150, 130)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(90, 200, 80)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(40, 170, 110)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(120, 210, 70)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(35, 145, 100)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(60, 195, 140)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(46, 160, 90)",secondary:"rgba(30, 190, 120,, 0.98)"},spikeLt:{primary:"rgb(33, 115, 65)",secondary:"rgb(22, 137, 86)"}},candy:{border:[{color:"rgb(240, 70, 170)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(255, 90, 140)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(215, 60, 200)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(255, 110, 180)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(200, 80, 240)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(250, 60, 150)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(230, 120, 220)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(245, 85, 165)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(210, 70, 230)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(240, 70, 170)",secondary:"rgba(255, 90, 140,, 0.98)"},spikeLt:{primary:"rgb(173, 50, 122)",secondary:"rgb(184, 65, 101)"}},ice:{border:[{color:"rgb(90, 200, 240)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(60, 175, 230)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(130, 220, 250)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(70, 190, 215)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(110, 210, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(50, 165, 220)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(150, 230, 250)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(85, 195, 235)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(65, 180, 245)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(90, 200, 240)",secondary:"rgba(60, 175, 230,, 0.98)"},spikeLt:{primary:"rgb(65, 144, 173)",secondary:"rgb(43, 126, 166)"}},gold:{border:[{color:"rgb(240, 190, 60)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(255, 210, 90)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(225, 165, 40)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(250, 200, 70)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(255, 225, 120)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(230, 175, 50)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(245, 205, 85)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(215, 155, 35)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(255, 215, 100)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(240, 190, 60)",secondary:"rgba(255, 210, 90,, 0.98)"},spikeLt:{primary:"rgb(173, 137, 43)",secondary:"rgb(184, 151, 65)"}}},Mo={colorful:{border:[{color:"rgb(50, 200, 80)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(30, 185, 170)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 120, 40)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(100, 70, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(240, 50, 180)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(180, 40, 240)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(40, 140, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 50, 100)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(50, 200, 80, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(30, 185, 170, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 120, 40, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(100, 70, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(240, 50, 180, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(180, 40, 240, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(40, 140, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 50, 100, 0.3)",pos:"100% 27%",size:"11px 12px"}]},mono:{border:[{color:"rgb(160, 160, 160)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(140, 140, 140)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(180, 180, 180)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(150, 150, 150)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(170, 170, 170)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(155, 155, 155)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(145, 145, 145)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(165, 165, 165)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(160, 160, 160, 0.25)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(140, 140, 140, 0.22)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(180, 180, 180, 0.17)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(150, 150, 150, 0.17)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(170, 170, 170, 0.15)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(155, 155, 155, 0.20)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(145, 145, 145, 0.15)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(165, 165, 165, 0.15)",pos:"100% 27%",size:"11px 12px"}]},ocean:{border:[{color:"rgb(60, 140, 200)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(50, 120, 180)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(100, 80, 220)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(80, 100, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(120, 70, 240)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(90, 80, 220)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(70, 110, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(110, 90, 230)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(60, 140, 200, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(50, 120, 180, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(100, 80, 220, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(80, 100, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(120, 70, 240, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(90, 80, 220, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(70, 110, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(110, 90, 230, 0.3)",pos:"100% 27%",size:"11px 12px"}]},sunset:{border:[{color:"rgb(255, 180, 50)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(255, 150, 40)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 80, 60)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(255, 100, 80)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(255, 60, 80)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(255, 120, 60)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(255, 200, 50)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 90, 70)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(255, 180, 50, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(255, 150, 40, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 80, 60, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(255, 100, 80, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(255, 60, 80, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(255, 120, 60, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(255, 200, 50, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 90, 70, 0.3)",pos:"100% 27%",size:"11px 12px"}]},forest:{border:[{color:"rgb(46, 160, 90)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(30, 190, 120)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(70, 180, 70)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(20, 150, 130)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(90, 200, 80)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(40, 170, 110)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(120, 210, 70)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(35, 145, 100)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(60, 195, 140,, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(46, 160, 90,, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(30, 190, 120,, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(70, 180, 70,, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(20, 150, 130,, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(90, 200, 80,, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(40, 170, 110,, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(120, 210, 70,, 0.3)",pos:"100% 27%",size:"11px 12px"}]},candy:{border:[{color:"rgb(240, 70, 170)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(255, 90, 140)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(215, 60, 200)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(255, 110, 180)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(200, 80, 240)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(250, 60, 150)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(230, 120, 220)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(245, 85, 165)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(210, 70, 230,, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(240, 70, 170,, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 90, 140,, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(215, 60, 200,, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(255, 110, 180,, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(200, 80, 240,, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(250, 60, 150,, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(230, 120, 220,, 0.3)",pos:"100% 27%",size:"11px 12px"}]},ice:{border:[{color:"rgb(90, 200, 240)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(60, 175, 230)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(130, 220, 250)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(70, 190, 215)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(110, 210, 255)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(50, 165, 220)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(150, 230, 250)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(85, 195, 235)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(65, 180, 245,, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(90, 200, 240,, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(60, 175, 230,, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(130, 220, 250,, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(70, 190, 215,, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(110, 210, 255,, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(50, 165, 220,, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(150, 230, 250,, 0.3)",pos:"100% 27%",size:"11px 12px"}]},gold:{border:[{color:"rgb(240, 190, 60)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(255, 210, 90)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(225, 165, 40)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(250, 200, 70)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(255, 225, 120)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(230, 175, 50)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(245, 205, 85)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(215, 155, 35)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(255, 215, 100,, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(240, 190, 60,, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 210, 90,, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(225, 165, 40,, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(250, 200, 70,, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(255, 225, 120,, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(230, 175, 50,, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(245, 205, 85,, 0.3)",pos:"100% 27%",size:"11px 12px"}]}};function ps(t){return Mo[t].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function bs(t){return Mo[t].inner.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function hs(t){return wt[t].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function us(t){const e=wt[t],a=t==="mono"?.225:.45;return e.border.map(r=>{const s=r.color.replace("rgb(","rgba(").replace(")",`, ${a})`);return`radial-gradient(ellipse ${r.size.split(" ").map(o=>{const i=parseInt(o);return`${Math.round(i*.9)}px`}).join(" ")} at ${r.pos}, ${s}, transparent)`}).join(`,
    `)}function gs(t,e){const a=wt[t];return e?a.spike:a.spikeLt}const ms={colorful:{dark:[{color:"rgb(255, 50, 100)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 180, 220)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 160, 30)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(240, 50, 180)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(30, 185, 170)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(255, 50, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 140, 255)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(30, 185, 170)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(255, 120, 40)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(240, 50, 180)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},mono:{dark:[{color:"rgb(200, 200, 200)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(170, 170, 170)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(155, 155, 155)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(185, 185, 185)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(165, 165, 165)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(180, 180, 180)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(160, 160, 160)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(175, 175, 175)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(190, 190, 190)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(100, 100, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(80, 80, 80)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(90, 90, 90)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(70, 70, 70)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(85, 85, 85)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(95, 95, 95)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(75, 75, 75)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(105, 105, 105)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(65, 65, 65)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},ocean:{dark:[{color:"rgb(100, 80, 220)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(60, 120, 255)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(80, 100, 200)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(130, 70, 255)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(70, 130, 255)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(120, 80, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(90, 110, 230)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(110, 90, 240)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(140, 100, 255)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(80, 60, 200)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(50, 100, 220)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(70, 90, 190)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(110, 60, 220)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(60, 110, 230)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 240)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(80, 100, 210)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(90, 80, 225)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(120, 90, 245)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},sunset:{dark:[{color:"rgb(255, 100, 60)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(255, 180, 50)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(255, 140, 70)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(255, 80, 80)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 200, 60)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(255, 120, 50)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(255, 160, 80)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(255, 90, 60)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(255, 70, 70)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(220, 80, 40)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(230, 150, 30)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(210, 110, 50)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(200, 60, 60)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(220, 170, 40)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(210, 100, 30)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(230, 130, 60)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(190, 70, 50)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(180, 50, 50)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},forest:{dark:[{color:"rgb(46, 160, 90)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(30, 190, 120)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(70, 180, 70)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(20, 150, 130)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(90, 200, 80)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(40, 170, 110)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(120, 210, 70)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(35, 145, 100)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(60, 195, 140)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(33, 115, 65)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(22, 137, 86)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(50, 130, 50)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(14, 108, 94)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(65, 144, 58)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(29, 122, 79)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(86, 151, 50)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(25, 104, 72)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(43, 140, 101)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},candy:{dark:[{color:"rgb(240, 70, 170)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(255, 90, 140)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(215, 60, 200)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(255, 110, 180)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(200, 80, 240)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(250, 60, 150)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(230, 120, 220)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(245, 85, 165)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(210, 70, 230)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(173, 50, 122)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(184, 65, 101)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(155, 43, 144)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(184, 79, 130)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(144, 58, 173)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(180, 43, 108)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(166, 86, 158)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(176, 61, 119)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(151, 50, 166)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},ice:{dark:[{color:"rgb(90, 200, 240)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(60, 175, 230)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(130, 220, 250)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(70, 190, 215)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(110, 210, 255)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(50, 165, 220)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(150, 230, 250)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(85, 195, 235)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(65, 180, 245)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(65, 144, 173)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(43, 126, 166)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(94, 158, 180)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(50, 137, 155)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(79, 151, 184)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(36, 119, 158)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(108, 166, 180)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(61, 140, 169)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(47, 130, 176)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},gold:{dark:[{color:"rgb(240, 190, 60)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(255, 210, 90)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(225, 165, 40)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(250, 200, 70)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 225, 120)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(230, 175, 50)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(245, 205, 85)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(215, 155, 35)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(255, 215, 100)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(173, 137, 43)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(184, 151, 65)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(162, 119, 29)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(180, 144, 50)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(184, 162, 86)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(166, 126, 36)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(176, 148, 61)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(155, 112, 25)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(184, 155, 72)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]}};function xs(t,e,a){return ms[t][e?"dark":"light"].map(r=>{const s=r.offsetX===0?"":r.offsetX>0?` + ${r.offsetX}px`:` - ${Math.abs(r.offsetX)}px`,o=r.offsetY===0?"":r.offsetY>0?` + ${r.offsetY}px`:` - ${Math.abs(r.offsetY)}px`;return`radial-gradient(ellipse calc(${r.sizeW}px * var(--beam-w-${a})) calc(${r.sizeH}px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%${s}) calc(100%${o}), ${r.color}, transparent)`}).join(`,
       `)}const $s={colorful:[{color:"rgba(255, 50, 100, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(40, 180, 220, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(50, 200, 80, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(180, 40, 240, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 160, 30, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(100, 70, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(40, 140, 255, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(240, 50, 180, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(30, 185, 170, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],mono:[{color:"rgba(200, 200, 200, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(170, 170, 170, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(155, 155, 155, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(185, 185, 185, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(165, 165, 165, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(180, 180, 180, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(160, 160, 160, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(175, 175, 175, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(190, 190, 190, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],ocean:[{color:"rgba(100, 80, 220, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(60, 120, 255, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(80, 100, 200, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(130, 70, 255, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(70, 130, 255, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(120, 80, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(90, 110, 230, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(110, 90, 240, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(140, 100, 255, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],sunset:[{color:"rgba(255, 100, 60, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(255, 180, 50, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(255, 140, 70, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(255, 80, 80, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 200, 60, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(255, 120, 50, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(255, 160, 80, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(255, 90, 60, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(255, 70, 70, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],forest:[{color:"rgba(46, 160, 90,, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(30, 190, 120,, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(70, 180, 70,, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(20, 150, 130,, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(90, 200, 80,, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(40, 170, 110,, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(120, 210, 70,, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(35, 145, 100,, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(60, 195, 140,, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],candy:[{color:"rgba(240, 70, 170,, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(255, 90, 140,, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(215, 60, 200,, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(255, 110, 180,, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(200, 80, 240,, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(250, 60, 150,, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(230, 120, 220,, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(245, 85, 165,, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(210, 70, 230,, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],ice:[{color:"rgba(90, 200, 240,, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(60, 175, 230,, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(130, 220, 250,, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(70, 190, 215,, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(110, 210, 255,, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(50, 165, 220,, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(150, 230, 250,, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(85, 195, 235,, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(65, 180, 245,, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],gold:[{color:"rgba(240, 190, 60,, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(255, 210, 90,, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(225, 165, 40,, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(250, 200, 70,, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 225, 120,, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(230, 175, 50,, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(245, 205, 85,, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(215, 155, 35,, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(255, 215, 100,, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}]};function vs(t,e){return $s[t].map(a=>{const r=a.offsetX===0?"":a.offsetX>0?` + ${a.offsetX}px`:` - ${Math.abs(a.offsetX)}px`,s=a.offsetY===0?"":` - ${Math.abs(a.offsetY)}px`;return`radial-gradient(ellipse calc(${a.sizeW}px * var(--beam-w-${e})) calc(${a.sizeH}px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%${r}) calc(100%${s}), ${a.color}, transparent)`}).join(`,
    `)}const ys={colorful:{dark:{spikes:[{color1:"rgb(100, 70, 255)",color2:"rgba(100, 70, 255, 1)"},{color1:"rgba(255, 170, 40, 0.59)",color2:"rgba(255, 170, 40, 0.29)"},{color1:"rgb(50, 200, 100)",color2:"rgba(50, 200, 100, 1)"},{color1:"rgba(200, 50, 240, 0.91)",color2:"rgba(200, 50, 240, 0.45)"},{color1:"rgb(40, 140, 255)",color2:"rgba(40, 140, 255, 1)"}]},light:{spikes:[{color1:"rgb(80, 50, 200)",color2:"rgba(80, 50, 200, 0.8)"},{color1:"rgba(210, 130, 0, 0.7)",color2:"rgba(210, 130, 0, 0.46)"},{color1:"rgb(30, 160, 70)",color2:"rgba(30, 160, 70, 0.82)"},{color1:"rgb(160, 30, 190)",color2:"rgba(160, 30, 190, 0.7)"},{color1:"rgb(30, 100, 200)",color2:"rgba(30, 100, 200, 0.78)"}]}},mono:{dark:{spikes:[{color1:"rgb(200, 200, 200)",color2:"rgba(200, 200, 200, 1)"},{color1:"rgba(180, 180, 180, 0.59)",color2:"rgba(180, 180, 180, 0.29)"},{color1:"rgb(190, 190, 190)",color2:"rgba(190, 190, 190, 1)"},{color1:"rgba(170, 170, 170, 0.91)",color2:"rgba(170, 170, 170, 0.45)"},{color1:"rgb(185, 185, 185)",color2:"rgba(185, 185, 185, 1)"}]},light:{spikes:[{color1:"rgb(80, 80, 80)",color2:"rgba(80, 80, 80, 0.8)"},{color1:"rgba(100, 100, 100, 0.7)",color2:"rgba(100, 100, 100, 0.46)"},{color1:"rgb(70, 70, 70)",color2:"rgba(70, 70, 70, 0.82)"},{color1:"rgb(90, 90, 90)",color2:"rgba(90, 90, 90, 0.7)"},{color1:"rgb(85, 85, 85)",color2:"rgba(85, 85, 85, 0.78)"}]}},ocean:{dark:{spikes:[{color1:"rgb(100, 80, 255)",color2:"rgb(100, 80, 255)"},{color1:"rgba(80, 130, 220, 0.59)",color2:"rgba(80, 130, 220, 0.29)"},{color1:"rgb(60, 100, 255)",color2:"rgb(60, 100, 255)"},{color1:"rgba(90, 120, 200, 0.91)",color2:"rgba(90, 120, 200, 0.45)"},{color1:"rgb(120, 90, 255)",color2:"rgb(120, 90, 255)"}]},light:{spikes:[{color1:"rgb(50, 40, 180)",color2:"rgba(50, 40, 180, 0.8)"},{color1:"rgba(40, 80, 200, 0.7)",color2:"rgba(40, 80, 200, 0.46)"},{color1:"rgb(30, 50, 190)",color2:"rgba(30, 50, 190, 0.82)"},{color1:"rgb(60, 90, 180)",color2:"rgba(60, 90, 180, 0.7)"},{color1:"rgb(70, 60, 200)",color2:"rgba(70, 60, 200, 0.78)"}]}},sunset:{dark:{spikes:[{color1:"rgb(255, 100, 80)",color2:"rgb(255, 100, 80)"},{color1:"rgba(255, 150, 80, 0.59)",color2:"rgba(255, 150, 80, 0.29)"},{color1:"rgb(255, 80, 60)",color2:"rgb(255, 80, 60)"},{color1:"rgba(255, 120, 50, 0.91)",color2:"rgba(255, 120, 50, 0.45)"},{color1:"rgb(255, 140, 70)",color2:"rgb(255, 140, 70)"}]},light:{spikes:[{color1:"rgb(200, 60, 30)",color2:"rgba(200, 60, 30, 0.8)"},{color1:"rgba(220, 100, 20, 0.7)",color2:"rgba(220, 100, 20, 0.46)"},{color1:"rgb(180, 40, 20)",color2:"rgba(180, 40, 20, 0.82)"},{color1:"rgb(210, 80, 10)",color2:"rgba(210, 80, 10, 0.7)"},{color1:"rgb(190, 70, 30)",color2:"rgba(190, 70, 30, 0.78)"}]}},forest:{dark:{spikes:[{color1:"rgb(46, 160, 90)",color2:"rgb(30, 190, 120)"},{color1:"rgba(70, 180, 70,, 0.59)",color2:"rgba(20, 150, 130,, 0.29)"},{color1:"rgb(90, 200, 80)",color2:"rgb(40, 170, 110)"},{color1:"rgba(120, 210, 70,, 0.91)",color2:"rgba(35, 145, 100,, 0.45)"},{color1:"rgb(60, 195, 140)",color2:"rgb(46, 160, 90)"}]},light:{spikes:[{color1:"rgb(33, 115, 65)",color2:"rgba(22, 137, 86,, 0.8)"},{color1:"rgba(50, 130, 50,, 0.7)",color2:"rgba(14, 108, 94,, 0.46)"},{color1:"rgb(65, 144, 58)",color2:"rgba(29, 122, 79,, 0.82)"},{color1:"rgb(86, 151, 50)",color2:"rgba(25, 104, 72,, 0.7)"},{color1:"rgb(43, 140, 101)",color2:"rgba(33, 115, 65,, 0.78)"}]}},candy:{dark:{spikes:[{color1:"rgb(240, 70, 170)",color2:"rgb(255, 90, 140)"},{color1:"rgba(215, 60, 200,, 0.59)",color2:"rgba(255, 110, 180,, 0.29)"},{color1:"rgb(200, 80, 240)",color2:"rgb(250, 60, 150)"},{color1:"rgba(230, 120, 220,, 0.91)",color2:"rgba(245, 85, 165,, 0.45)"},{color1:"rgb(210, 70, 230)",color2:"rgb(240, 70, 170)"}]},light:{spikes:[{color1:"rgb(173, 50, 122)",color2:"rgba(184, 65, 101,, 0.8)"},{color1:"rgba(155, 43, 144,, 0.7)",color2:"rgba(184, 79, 130,, 0.46)"},{color1:"rgb(144, 58, 173)",color2:"rgba(180, 43, 108,, 0.82)"},{color1:"rgb(166, 86, 158)",color2:"rgba(176, 61, 119,, 0.7)"},{color1:"rgb(151, 50, 166)",color2:"rgba(173, 50, 122,, 0.78)"}]}},ice:{dark:{spikes:[{color1:"rgb(90, 200, 240)",color2:"rgb(60, 175, 230)"},{color1:"rgba(130, 220, 250,, 0.59)",color2:"rgba(70, 190, 215,, 0.29)"},{color1:"rgb(110, 210, 255)",color2:"rgb(50, 165, 220)"},{color1:"rgba(150, 230, 250,, 0.91)",color2:"rgba(85, 195, 235,, 0.45)"},{color1:"rgb(65, 180, 245)",color2:"rgb(90, 200, 240)"}]},light:{spikes:[{color1:"rgb(65, 144, 173)",color2:"rgba(43, 126, 166,, 0.8)"},{color1:"rgba(94, 158, 180,, 0.7)",color2:"rgba(50, 137, 155,, 0.46)"},{color1:"rgb(79, 151, 184)",color2:"rgba(36, 119, 158,, 0.82)"},{color1:"rgb(108, 166, 180)",color2:"rgba(61, 140, 169,, 0.7)"},{color1:"rgb(47, 130, 176)",color2:"rgba(65, 144, 173,, 0.78)"}]}},gold:{dark:{spikes:[{color1:"rgb(240, 190, 60)",color2:"rgb(255, 210, 90)"},{color1:"rgba(225, 165, 40,, 0.59)",color2:"rgba(250, 200, 70,, 0.29)"},{color1:"rgb(255, 225, 120)",color2:"rgb(230, 175, 50)"},{color1:"rgba(245, 205, 85,, 0.91)",color2:"rgba(215, 155, 35,, 0.45)"},{color1:"rgb(255, 215, 100)",color2:"rgb(240, 190, 60)"}]},light:{spikes:[{color1:"rgb(173, 137, 43)",color2:"rgba(184, 151, 65,, 0.8)"},{color1:"rgba(162, 119, 29,, 0.7)",color2:"rgba(180, 144, 50,, 0.46)"},{color1:"rgb(184, 162, 86)",color2:"rgba(166, 126, 36,, 0.82)"},{color1:"rgb(176, 148, 61)",color2:"rgba(155, 112, 25,, 0.7)"},{color1:"rgb(184, 155, 72)",color2:"rgba(173, 137, 43,, 0.78)"}]}}};function $a(t,e){const a=t.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*[\d.]+\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${e})`;const r=t.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return r?`rgba(${r[1]}, ${r[2]}, ${r[3]}, ${e})`:t}function ft(t,e){const a=t.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${(parseFloat(a[4])*e).toFixed(2)})`;const r=t.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return r?`rgba(${r[1]}, ${r[2]}, ${r[3]}, ${e.toFixed(2)})`:t}function ws(t,e,a){const r=gs(t,e),s=ys[t][e?"dark":"light"],o=t==="mono",i=o?.14:1,n=o?ft(r.primary,.14):r.primary,l=o?ft(r.primary,.09):r.primary,f=o?ft(r.secondary,.12):r.secondary,p=o?$a(r.secondary,.06):$a(r.secondary,.49),b=s.spikes.map(A=>o?{color1:ft(A.color1,i),color2:ft(A.color2,i*.7)}:A),c=o?"12px":"0.8px",d=o?"14px":"2px",m=o?"12px":"1.2px",k=o?"10px":"0.6px",x=o?"42px":"92px",W=o?"38px":"72px",y=o?"40px":"85px",$=o?"32px":"60px",X=o?"12px":"1px",M=o?"rgba(255, 255, 255, 0.5)":"rgba(255, 255, 255, 1)",v=o?"rgba(255, 255, 255, 0.45)":"rgba(255, 255, 255, 0.9)",h=o?"rgba(255, 255, 255, 0.25)":"rgba(255, 255, 255, 0.5)",g=o?"rgba(255, 255, 255, 0.15)":"rgba(255, 255, 255, 0.3)",H=o?"rgba(255, 255, 255, 0.06)":"rgba(255, 255, 255, 0.12)",w=o?"rgba(255, 255, 255, 0.015)":"rgba(255, 255, 255, 0.03)";if(e)return`radial-gradient(ellipse calc(${c} * var(--beam-spike-${a}) * var(--beam-spike-mul, 1)) calc(${x} * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 8% calc(100% - 2px), ${n}, ${l} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a}) * var(--beam-spike-mul, 1)) calc(35px * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 22% calc(100% - 4px), ${f}, ${p} 50%, transparent 95%),
       radial-gradient(ellipse calc(${d} * (2 - var(--beam-spike-${a})) * var(--beam-spike-mul, 1)) calc(${W} * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 36% calc(100% - 3px), ${b[0].color1}, ${b[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a}) * var(--beam-spike-mul, 1)) calc(28px * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 50% calc(100% - 2px), ${b[1].color1}, ${b[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${m} * (2 - var(--beam-spike2-${a})) * var(--beam-spike-mul, 1)) calc(${y} * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 64% calc(100% - 4px), ${b[2].color1}, ${b[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a}) * var(--beam-spike-mul, 1)) calc(45px * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 78% calc(100% - 2px), ${b[3].color1}, ${b[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${k} * (2 - var(--beam-spike-${a})) * var(--beam-spike-mul, 1)) calc(${$} * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 92% calc(100% - 3px), ${b[4].color1}, ${b[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(21px * var(--beam-spike-${a})) calc(15px * var(--beam-spike2-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100% + 1px), ${M} 0%, ${v} 20%, ${h} 50%, transparent 100%),
       radial-gradient(ellipse calc(42px * var(--beam-w-${a})) calc(40px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) 100%, ${g} 0%, ${H} 25%, ${w} 55%, transparent 80%)`;{const A=o?ft(r.primary,.11):$a(r.primary,.85),O=o?ft(r.secondary,.09):$a(r.secondary,.7);return`radial-gradient(ellipse calc(${c} * var(--beam-spike-${a}) * var(--beam-spike-mul, 1)) calc(${x} * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 8% calc(100% - 2px), ${n}, ${A} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a}) * var(--beam-spike-mul, 1)) calc(35px * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 22% calc(100% - 4px), ${f}, ${O} 50%, transparent 95%),
       radial-gradient(ellipse calc(${d} * (2 - var(--beam-spike-${a})) * var(--beam-spike-mul, 1)) calc(${W} * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 36% calc(100% - 3px), ${b[0].color1}, ${b[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a}) * var(--beam-spike-mul, 1)) calc(28px * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 50% calc(100% - 2px), ${b[1].color1}, ${b[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${m} * (2 - var(--beam-spike2-${a})) * var(--beam-spike-mul, 1)) calc(${y} * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 64% calc(100% - 4px), ${b[2].color1}, ${b[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a}) * var(--beam-spike-mul, 1)) calc(45px * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 78% calc(100% - 2px), ${b[3].color1}, ${b[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${X} * (2 - var(--beam-spike-${a})) * var(--beam-spike-mul, 1)) calc(${$} * var(--beam-h-${a}) * var(--beam-spike-mul, 1)) at 92% calc(100% - 3px), ${b[4].color1}, ${b[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(50px * var(--beam-w-${a})) calc(32px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100%), rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.18) 30%, rgba(0, 0, 0, 0.03) 60%, transparent 85%)`}}const zo=[{region:1,quad:"tl"},{region:2,quad:"tl"},{region:3,quad:"bl"},{region:1,quad:"bl"},{region:2,quad:"br"},{region:3,quad:"br"},{region:1,quad:"tr"},{region:2,quad:"tr"},{region:3,quad:"tr"}],Ms=[[65,35],[55,30],[35,65],[15,30],[173,28],[80,22],[69,28],[22,38],[47,44]],zs=[{ci:0,region:1,quad:"tl",w:84,h:48},{ci:1,region:2,quad:"tl",w:72,h:42},{ci:2,region:3,quad:"bl",w:48,h:84},{ci:4,region:2,quad:"br",w:216,h:38},{ci:5,region:3,quad:"br",w:102,h:31},{ci:6,region:1,quad:"tr",w:89,h:38},{ci:8,region:3,quad:"tr",w:62,h:58}],qr=[{ci:0,region:1,quad:"tl",w:80,h:19,x:"27%",y:"0%"},{ci:6,region:2,quad:"tr",w:74,h:11,x:"73%",y:"-1%"},{ci:7,region:3,quad:"tr",w:15,h:44,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:19,h:38,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:84,h:13,x:"67%",y:"100%"},{ci:1,region:3,quad:"bl",w:60,h:21,x:"24%",y:"101%"},{ci:2,region:1,quad:"bl",w:17,h:40,x:"0%",y:"60%"},{ci:3,region:2,quad:"tl",w:13,h:32,x:"-1%",y:"28%"}],ks=[{ci:0,region:1,quad:"tl",w:110,h:30,x:"27%",y:"3%"},{ci:6,region:2,quad:"tr",w:100,h:20,x:"73%",y:"1%"},{ci:7,region:3,quad:"tr",w:26,h:62,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:30,h:56,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:120,h:22,x:"67%",y:"99%"},{ci:1,region:3,quad:"bl",w:88,h:32,x:"24%",y:"99%"},{ci:2,region:1,quad:"bl",w:28,h:58,x:"0%",y:"60%"}];function Ss(t,e,a){const r=t.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/);return`rgba(${r?`${r[1]}, ${r[2]}, ${r[3]}`:"255, 255, 255"}, var(--bop-${e}-${a}))`}function pr(t,e,a,r,s,o,i,n){return`radial-gradient(ellipse calc(${e}px * var(--bw${r}-${n}) * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${a}px * var(--bh${r}-${n}) * var(--bgh-${n}) * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at calc(${o} + var(--bx${r}-${n})) calc(${i} + var(--by${r}-${n})), ${Ss(t,s,n)}, transparent)`}function Ws(t,e){return wt[t].border.map((a,r)=>{const{region:s,quad:o}=zo[r],[i,n]=a.pos.split(" "),[l,f]=a.size.split(" ").map(parseFloat);return pr(a.color,l,f,s,o,i,n,e)}).join(`,
    `)}function Hs(t,e,a){const r=wt[t].border.map((n,l)=>{const{region:f,quad:p}=zo[l],[b,c]=n.pos.split(" "),[d,m]=Ms[l];return pr(n.color,d,m,f,p,b,c,e)}),s=a?"255, 255, 255":"0, 0, 0",o=a?.18:.08,i=[["0%","0%","tl"],["100%","0%","tr"],["0%","100%","bl"],["100%","100%","br"]].map(([n,l,f])=>`radial-gradient(ellipse 60px 60px at ${n} ${l}, rgba(${s}, calc(${o} * var(--bop-${f}-${e}))), transparent 70%)`);return[...r,...i].join(`,
    `)}function Gr(t,e,a){const r=wt[e].border;return t.map(s=>{const o=r[s.ci],[i,n]=o.pos.split(" ");return pr(o.color,s.w,s.h,s.region,s.quad,s.x??i,s.y??n,a)}).join(`,
    `)}function ko(t,e,a){const r=wt[e].border,s=+a.toFixed(3);return t.map(o=>{const i=r[o.ci],[n,l]=i.pos.split(" "),f=o.x??n,p=o.y??l,b=i.color.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/),c=b?`${b[1]}, ${b[2]}, ${b[3]}`:"255, 255, 255";return`radial-gradient(ellipse calc(${o.w}px * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${o.h}px * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at ${f} ${p}, rgba(${c}, ${s}), transparent)`}).join(`,
    `)}function la(t){return`
[data-beam="${t}"][data-paused],
[data-beam="${t}"][data-paused]::after,
[data-beam="${t}"][data-paused]::before,
[data-beam="${t}"][data-paused] [data-beam-bloom] {
  animation-play-state: paused !important;
}`}function So(t){const e=["bw1","bh1","bw2","bh2","bw3","bh3","bgh","bop-tl","bop-tr","bop-bl","bop-br"],a=["bx1","by1","bx2","by2","bx3","by3"],r=e.map(o=>`@property --${o}-${t} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}`).join(`

`),s=a.map(o=>`@property --${o}-${t} {
  syntax: "<length>";
  initial-value: 0px;
  inherits: true;
}`).join(`

`);return`${r}

${s}

@property --beam-opacity-${t} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-hue-${t} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}`}function br(t,e,a){const r=e==="dark",s=a/2.3;return t==="pulse-inner"?{sp:.28,dr:r?33:40,op:r?.48:.45,gh:r?.34:.22,bs:(r?1.9:2.6)*s,ss:(r?2.6:4.6)*s,ghs:(r?2.4:5.5)*s,huePeriod:16}:{sp:r?.28:.36,dr:r?14:19,op:r?.46:0,gh:r?.16:.58,bs:(r?2.3:3.7)*s,ss:(r?6.4:4.6)*s,ghs:(r?2.4:3.8)*s,huePeriod:14}}function Xs(t,e){const{sp:a,dr:r,op:s,gh:o,bs:i,ss:n,ghs:l}=e;return[{prop:`--bw1-${t}`,a:1-a,b:1+a*1.1,period:n*.9,delay:0,unit:""},{prop:`--bh1-${t}`,a:1+a*.9,b:1-a*.85,period:n*1.26,delay:0,unit:""},{prop:`--bx1-${t}`,a:-r,b:r*.9,period:i*1.6,delay:0,unit:"px"},{prop:`--by1-${t}`,a:r*.55,b:-r*.7,period:i*1.6,delay:0,unit:"px"},{prop:`--bw2-${t}`,a:1+a,b:1-a*.85,period:n*1.1,delay:0,unit:""},{prop:`--bh2-${t}`,a:1-a*.8,b:1+a*1.05,period:n*.81,delay:0,unit:""},{prop:`--bx2-${t}`,a:r*.8,b:-r*.9,period:i*1.88,delay:0,unit:"px"},{prop:`--by2-${t}`,a:-r,b:r*.65,period:i*1.88,delay:0,unit:"px"},{prop:`--bw3-${t}`,a:1-a*.6,b:1+a*1.15,period:n*.98,delay:0,unit:""},{prop:`--bh3-${t}`,a:1+a*.75,b:1-a,period:n*1.4,delay:0,unit:""},{prop:`--bx3-${t}`,a:-r*.6,b:r,period:i*1.45,delay:0,unit:"px"},{prop:`--by3-${t}`,a:-r*.85,b:r*.45,period:i*1.45,delay:0,unit:"px"},{prop:`--bgh-${t}`,a:1-o,b:1+o,period:l,delay:0,unit:""},{prop:`--bop-tl-${t}`,a:1-s,b:1,period:i,delay:0,unit:""},{prop:`--bop-tr-${t}`,a:1-s,b:1,period:i*1.32,delay:i*.28,unit:""},{prop:`--bop-bl-${t}`,a:1-s,b:1,period:i*.84,delay:i*.55,unit:""},{prop:`--bop-br-${t}`,a:1-s,b:1,period:i*1.58,delay:i*.83,unit:""}]}function Ys(t,e,a,r,s,o){if(t!=="pulse-inner"&&t!=="pulse-outside")return null;const i=br(t,e,a);return{oscillators:Xs(o,i),hue:s?null:{prop:`--beam-hue-${o}`,range:360,period:i.huePeriod,continuous:!0}}}function Ya(t,e,a){return`  animation: ${e}-${t} ${a}s ease forwards;`}function tt(t,e=1){return Math.max(.5,Math.round(t*e*100)/100)}function As(t){const{size:e}=t;return e==="line"?js(t):e==="sm"?Os(t):e==="pulse-inner"?Rs(t):e==="pulse-outside"?Cs(t):Fs(t)}function Os(t){const{id:e,borderRadius:a,borderWidth:r,duration:s,strokeOpacity:o,innerOpacity:i,bloomOpacity:n,innerShadow:l,colorVariant:f,staticColors:p,brightness:b,saturation:c,hueRange:d,theme:m,glowSize:k=1}=t,x=Math.max(0,a-r),W=f==="mono"?.5:1,y=o*W,$=i*W,X=n*W,M=p?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,v=p?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${d}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${d}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${d}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
}`,h=m==="dark",g=h?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,H=ps(f),w=bs(f),A=h?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`,O=`conic-gradient(
    from var(--beam-angle-${e}),
    transparent 0%, transparent 22%,
    rgba(255, 255, 255, 0.12) 28%, rgba(255, 255, 255, 0.4) 36%,
    white 46%, white 82%,
    rgba(255, 255, 255, 0.4) 88%, rgba(255, 255, 255, 0.12) 94%,
    transparent 97%, transparent 100%
  )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${x}px;
  padding: ${r}px;
  clip-path: inset(0 round ${a}px);
  background: ${g},${H};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${y.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${M}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${w};
  box-shadow: inset 0 0 5px 1px ${l};
  -webkit-mask-image: ${O};
  -webkit-mask-composite: source-over;
  mask-image: ${O};
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${$.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${M}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${x}px;
  clip-path: inset(0 round ${a}px);
  background: ${A};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${r}px;
  filter: blur(${tt(8,k)}px) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${X.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${v}
${la(e)}
`}function Fs(t){const{id:e,borderRadius:a,borderWidth:r,duration:s,strokeOpacity:o,innerOpacity:i,bloomOpacity:n,innerShadow:l,colorVariant:f,staticColors:p,brightness:b,saturation:c,hueRange:d,theme:m,glowSize:k=1}=t,x=Math.max(0,a-r),W=f==="mono"?.5:1,y=o*W,$=i*W,X=n*W,M=p?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,v=p?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${d}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${d}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${d}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
}`,h=m==="dark",g=h?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,H=hs(f),w=us(f),A=h?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${x}px;
  padding: ${r}px;
  clip-path: inset(0 round ${a}px);
  background: ${g},${H};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${y.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${M}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${w};
  box-shadow: inset 0 0 9px 1px ${l};
  -webkit-mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${$.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${M}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${x}px;
  clip-path: inset(0 round ${a}px);
  background: ${A};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${r}px;
  filter: blur(${tt(8,k)}px) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${X.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${v}
${la(e)}
`}function Rs(t){const{id:e,borderRadius:a,borderWidth:r,duration:s,strokeOpacity:o,innerOpacity:i,bloomOpacity:n,colorVariant:l,staticColors:f,brightness:p,saturation:b,hueRange:c,theme:d,glowSize:m=1}=t,k=d==="dark",x=l==="mono"?.5:1,W=(o*x).toFixed(2),y=(i*x).toFixed(2),$=(n*x).toFixed(2),{op:X}=br("pulse-inner",d,s),M=tt(8,m),v=p.toFixed(2),h=b.toFixed(2),g=f?`filter: brightness(${v}) saturate(${h});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${v}) saturate(${h});`,H=f?`filter: blur(${M}px) brightness(${v}) saturate(${h});`:`filter: blur(${M}px) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${v}) saturate(${h});`,w=Ws(l,e),A=Hs(l,e,k),O=ko(zs,l,1-X*.5);return`
${So(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${Ya(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${Ya(e,"beam-fade-out",.5)}
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: ${r}px;
  clip-path: inset(0 round ${a}px);
  background: ${w};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${W} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${g}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${A};
  -webkit-mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-over;
  mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${y} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${g}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${O};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${r}px;
  pointer-events: none;
  z-index: 3;
  will-change: opacity;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${$} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${H}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${la(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function Cs(t){const{id:e,borderRadius:a,duration:r,strokeOpacity:s,innerOpacity:o,bloomOpacity:i,colorVariant:n,staticColors:l,brightness:f,saturation:p,hueRange:b,theme:c,hairlineOpacity:d=0,glowSize:m=1}=t,k=c==="dark",x=n==="mono"?.5:1,W=(s*x).toFixed(2),y=(o*x).toFixed(2),$=(i*x).toFixed(2),X=k?"70, 70, 70":"0, 0, 0",M=d.toFixed(2),v=`linear-gradient(rgba(${X}, ${M}), rgba(${X}, ${M}))`,{op:h}=br("pulse-outside",c,r),g=.95,H=.9,w=tt(k?3:6,m),A=tt(k?22.5:15,m),O=f.toFixed(2),E=p.toFixed(2),z=l?`filter: brightness(${O}) saturate(${E});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${O}) saturate(${E});`,S=`brightness(var(--beam-glow-brightness, ${O})) saturate(var(--beam-glow-saturate, ${E}))`,Y=l?`filter: blur(var(--beam-core-blur, ${w}px)) ${S};`:`filter: blur(var(--beam-core-blur, ${w}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${S};`,D=l?`filter: blur(var(--beam-bloom-blur, ${A}px)) ${S};`:`filter: blur(var(--beam-bloom-blur, ${A}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${S};`,P=Gr(qr,n,e),L=Gr(qr,n,e),j=ko(ks,n,1-h*.5),T=d>0?`${P},
    ${v}`:P;return`
${So(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: visible;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${Ya(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${Ya(e,"beam-fade-out",.5)}
}
${d>0?`
/* Idle hairline — painted above the (opaque) child in the inner 1px edge ring so
   it overlaps a standard inset component border exactly. */
[data-beam="${e}"]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${v};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
}
`:""}
[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${T};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${W} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${z}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: -10px;
  z-index: -1;
  border-radius: ${a+10}px;
  background: ${L};
  transform: scale(${g}, ${H});
  pointer-events: none;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${y} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${Y}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: -30px;
  z-index: -1;
  border-radius: ${a+30}px;
  background: ${j};
  transform: scale(${g}, ${H});
  pointer-events: none;
  will-change: transform;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${$} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${D}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${la(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function js(t){const{id:e,borderRadius:a,borderWidth:r,duration:s,strokeOpacity:o,innerOpacity:i,bloomOpacity:n,innerShadow:l,colorVariant:f,staticColors:p,brightness:b,saturation:c,hueRange:d,theme:m,glowSize:k=1}=t,x=Math.max(0,a-r),W=m==="dark",y=o,$=i,X=n,M=p?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,v=p?"":`animation: beam-hue-shift-bloom-${e} 8s ease-in-out infinite;`,h=p?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${d}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${d}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${d}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
}

@keyframes beam-hue-shift-bloom-${e} {
  0% { filter: blur(${tt(8,k)}px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${d+10}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
  50% { filter: blur(${tt(8,k)}px) hue-rotate(calc(var(--beam-hue-base, 0deg) + ${d+10}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
  100% { filter: blur(${tt(8,k)}px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${d+10}deg)) brightness(${b.toFixed(2)}) saturate(${c.toFixed(2)}); }
}`,g=W?`radial-gradient(
        ellipse calc(24px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(255, 255, 255, 0.38) 0%,
        rgba(255, 255, 255, 0.12) 30%,
        transparent 65%
      )`:`radial-gradient(
        ellipse calc(35px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(0, 0, 0, 0.6) 0%,
        rgba(0, 0, 0, 0.25) 35%,
        transparent 70%
      )`,H=xs(f,W,e),w=vs(f,e),A=ws(f,W,e),O=f==="mono"?"filter: blur(6px);":"";return`
@property --beam-x-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-w-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-h-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike2-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-edge-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${x}px;
  padding: ${r}px;
  clip-path: inset(0 round ${a}px);
  background: ${g}, ${H};
  -webkit-mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${y.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${M}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${w};
  box-shadow: inset 0 0 9px 1px ${l};
  -webkit-mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${$.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${M}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${x}px;
  clip-path: inset(0 round ${a}px);
  padding: 0;
  -webkit-mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  -webkit-mask-composite: source-over;
  mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  mask-composite: add;
  background: ${A};
  ${O}
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${X.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${v}
}

@keyframes beam-travel-${e} {
  0%   { --beam-x-${e}: 0.06;  --beam-w-${e}: 0.5; }
  10%  { --beam-x-${e}: 0.15;  --beam-w-${e}: 0.8; }
  20%  { --beam-x-${e}: 0.25;  --beam-w-${e}: 1.1; }
  30%  { --beam-x-${e}: 0.35;  --beam-w-${e}: 1.3; }
  40%  { --beam-x-${e}: 0.44;  --beam-w-${e}: 1.45; }
  50%  { --beam-x-${e}: 0.5;   --beam-w-${e}: 1.5; }
  60%  { --beam-x-${e}: 0.56;  --beam-w-${e}: 1.45; }
  70%  { --beam-x-${e}: 0.65;  --beam-w-${e}: 1.3; }
  80%  { --beam-x-${e}: 0.75;  --beam-w-${e}: 1.1; }
  90%  { --beam-x-${e}: 0.85;  --beam-w-${e}: 0.8; }
  100% { --beam-x-${e}: 0.94;  --beam-w-${e}: 0.5; }
}

@keyframes beam-edge-fade-${e} {
  0%    { --beam-edge-${e}: 0; }
  12.5% { --beam-edge-${e}: 0; }
  32.5% { --beam-edge-${e}: 1; }
  67.5% { --beam-edge-${e}: 1; }
  87.5% { --beam-edge-${e}: 0; }
  100%  { --beam-edge-${e}: 0; }
}

@keyframes beam-breathe-${e} {
  0%, 100% { --beam-h-${e}: 0.8; }
  25%      { --beam-h-${e}: 1.25; }
  55%      { --beam-h-${e}: 0.85; }
  80%      { --beam-h-${e}: 1.3; }
}

@keyframes beam-spike-${e} {
  0%   { --beam-spike-${e}: 0.8; }
  25%  { --beam-spike-${e}: 1.3; }
  50%  { --beam-spike-${e}: 0.9; }
  75%  { --beam-spike-${e}: 1.4; }
  100% { --beam-spike-${e}: 0.8; }
}

@keyframes beam-spike2-${e} {
  0%   { --beam-spike2-${e}: 1.2; }
  25%  { --beam-spike2-${e}: 0.7; }
  50%  { --beam-spike2-${e}: 1.4; }
  75%  { --beam-spike2-${e}: 0.8; }
  100% { --beam-spike2-${e}: 1.2; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${h}
${la(e)}
`}const Aa=new Set;let jt=null,er=0;const Es=1e3/30-2,Ps=Math.PI*2;function Vr(t){return(1-Math.cos(Ps*t))/2}function Wo(t){if(jt=requestAnimationFrame(Wo),t-er<Es)return;er=t;const e=t/1e3;Aa.forEach(({el:a,config:r})=>{for(const s of r.oscillators){const o=(e-s.delay)/s.period,i=s.a+(s.b-s.a)*Vr(o);a.style.setProperty(s.prop,s.unit==="px"?`${i.toFixed(2)}px`:i.toFixed(4))}if(r.hue){const{prop:s,range:o,period:i,continuous:n}=r.hue,l=n?e/i%1*o:-o+2*o*Vr(e/i);a.style.setProperty(s,`${l.toFixed(2)}deg`)}})}function Ts(){jt==null&&(er=0,jt=requestAnimationFrame(Wo))}function Ls(){Aa.size===0&&jt!=null&&(cancelAnimationFrame(jt),jt=null)}function Bs(t,e){const a={el:t,config:e};return Aa.add(a),Ts(),()=>{Aa.delete(a),Ls()}}function Ds(){const[t,e]=C.useState(()=>typeof window>"u"||window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");return C.useEffect(()=>{if(typeof window>"u")return;const a=window.matchMedia("(prefers-color-scheme: dark)"),r=s=>{e(s.matches?"dark":"light")};return a.addEventListener("change",r),()=>a.removeEventListener("change",r)},[]),t}function Ns(t,e){return t==="auto"?e:t}const Is=C.forwardRef(function({children:t,size:e="md",colorVariant:a="colorful",theme:r="dark",staticColors:s=!1,duration:o,active:i=!0,borderRadius:n,brightness:l,saturation:f,hueRange:p=30,glowSize:b=1,strength:c=1,className:d,style:m,css:k,onActivate:x,onDeactivate:W,onAnimationEnd:y,...$},X){const M=C.useId().replace(/:/g,"-"),v=Ds(),h=C.useRef(null),[g,H]=C.useState(i),[w,A]=C.useState(!1),[O,E]=C.useState(!0),[z,S]=C.useState(null),[Y,D]=C.useState({x:1,y:1});C.useEffect(()=>{if(n!=null)return;const Z=h.current;if(!Z)return;const oe=()=>{const he=Z.firstElementChild;if(!he)return;const ue=getComputedStyle(he),le=parseFloat(ue.borderTopLeftRadius);!isNaN(le)&&le>0&&S(le)};oe();const me=new MutationObserver(oe);return me.observe(Z,{childList:!0,subtree:!1}),()=>me.disconnect()},[n,t]),C.useEffect(()=>{i&&!g&&!w?H(!0):!i&&g&&!w&&A(!0)},[i,g,w]),C.useEffect(()=>{const Z=h.current;if(!Z||typeof IntersectionObserver>"u")return;const oe=new IntersectionObserver(me=>{for(const he of me)E(he.isIntersecting)},{rootMargin:"256px"});return oe.observe(Z),()=>oe.disconnect()},[]),C.useEffect(()=>{if(e!=="pulse-outside"){D({x:1,y:1});return}const Z=h.current;if(!Z)return;const oe=350,me=140,he=.35,ue=4,le=Ae=>Math.max(he,Math.min(ue,Ae)),Pe=()=>{const Ae=Z.firstElementChild;if(!Ae)return;const ye=Ae.getBoundingClientRect();if(!ye.width||!ye.height)return;const xe=+le(ye.width/oe).toFixed(3),We=+le(ye.height/me).toFixed(3);D(Oe=>Oe.x===xe&&Oe.y===We?Oe:{x:xe,y:We})};if(Pe(),typeof ResizeObserver>"u")return;const Te=Z.firstElementChild;if(!Te)return;const Le=new ResizeObserver(Pe);return Le.observe(Te),()=>Le.disconnect()},[e,t]);const P=C.useCallback(Z=>{const oe=Z.animationName;oe.includes("fade-out")?(H(!1),A(!1),W==null||W()):oe.includes("fade-in")&&(x==null||x()),y==null||y(Z)},[x,W,y]),L=Ns(r,v),j=ds[e][L],T=fs[e],R=e==="pulse-inner"||e==="pulse-outside",I=n??z??T.borderRadius,_=o??(e==="line"?3.1:R?2.3:1.96),V=f??j.saturation,G=l??j.brightness??1.3,ae=e==="line"?Math.min(p,13):p,Q=a==="mono"?!0:s,fe=C.useMemo(()=>As({id:M,borderRadius:I,borderWidth:T.borderWidth,duration:_,strokeOpacity:j.strokeOpacity,innerOpacity:j.innerOpacity,bloomOpacity:j.bloomOpacity,innerShadow:j.innerShadow,size:e,colorVariant:a,staticColors:Q,brightness:G,saturation:V,hueRange:ae,theme:L,hairlineOpacity:j.hairlineOpacity,glowSize:b}),[M,I,T.borderWidth,_,j.strokeOpacity,j.innerOpacity,j.bloomOpacity,j.innerShadow,j.hairlineOpacity,e,a,Q,G,V,ae,b,L]),q=C.useMemo(()=>R?Ys(e,L,_,ae,Q,M):null,[R,e,L,_,ae,Q,M]);C.useEffect(()=>{var Z;if(!q||!(g||w)||!O)return;const oe=h.current;if(oe&&!(typeof window<"u"&&(Z=window.matchMedia)!=null&&Z.call(window,"(prefers-reduced-motion: reduce)").matches))return Bs(oe,q)},[q,g,w,O]);const ie=C.useCallback(Z=>{h.current=Z,typeof X=="function"?X(Z):X&&(X.current=Z)},[X]),de={...m??{},"--beam-strength":Math.max(0,Math.min(1,c)),...e==="pulse-outside"?{"--pulse-glow-sx":Y.x,"--pulse-glow-sy":Y.y}:{}};return u.jsxs(u.Fragment,{children:[u.jsx("style",{children:k?`${fe}
${k.split("{id}").join(M)}`:fe}),u.jsxs("div",{...$,ref:ie,"data-beam":M,"data-active":g&&!w?"":void 0,"data-fading":w?"":void 0,"data-paused":g&&!w&&!O?"":void 0,className:d,style:de,onAnimationEnd:P,children:[t,u.jsx("div",{"data-beam-bloom":!0})]})]})});function Da(t,e,a){return t+(e-t)*a}function Ho(t){return t-Math.floor(t)}function Na(t,e){const a=Math.floor(t),r=Math.floor(e);let s=t-a,o=e-r;s=s*s*(3-2*s),o=o*o*(3-2*o);const i=Se(a,r),n=Se(a+1,r),l=Se(a,r+1),f=Se(a+1,r+1);return i+(n-i)*s+(l-i)*o+(i-n-l+f)*s*o}function Se(t,e){const a=Math.sin(t*12.9898+e*78.233)*43758.5453;return a-Math.floor(a)}function hr(t,e){const a=Math.PI*(3-Math.sqrt(5)),r=1-2*(t+.5)/e,s=Math.sqrt(1-r*r),o=t*a;return[s*Math.cos(o),r,s*Math.sin(o)]}function qs(t,e){return Math.atan2(Math.sin(t-e),Math.cos(t-e))}function Mt(t,e,a,r,s){const o=Math.sin(e),i=Math.cos(e),n=Math.sin(t),l=Math.cos(t);return(f,p,b)=>{const c=f*l+b*n,d=-f*n+b*l,m=p*i-d*o,k=p*o+d*i;return[a+c*s,r-m*s,k]}}function Xo(t,e,a,r){if(!r){const o=Math.round((a?1-t:t)*255);return`rgba(${o},${o},${o},${e})`}const s=o=>Math.round(a?o*(1-t):o+(255-o)*t);return`rgba(${s(r.r)},${s(r.g)},${s(r.b)},${e})`}function Gs(t,e,a,r=.3,s){for(const o of e){const i=o.a??1,n=Math.min(1,Math.max(0,o.white));t.fillStyle=Xo(n,i,a,s),t.beginPath(),t.arc(o.x,o.y,o.r,0,Math.PI*2),t.fill()}}function Vs(t,e,a,r){for(const s of e){const o=s.a??1,i=Math.min(1,Math.max(0,s.white));t.strokeStyle=Xo(i,o,a,r),t.lineWidth=s.w,t.beginPath(),t.moveTo(s.x1,s.y1),t.lineTo(s.x2,s.y2),t.stroke()}}function rt(t,e,a=.3){const r=[];for(const s of t)(s.a??1)<.02||(s.r=Math.max(a,s.r),r.push(s));return r.sort((s,o)=>s.z-o.z),{dots:r,lines:e.filter(s=>(s.a??1)>=.02)}}function Yo(t,e,a,r){e.lines.length&&Vs(t,e.lines,a,r),Gs(t,e.dots,a,.3,r)}function zt(t,e){return(t/300)**e}const Us=[["latRings","lonDensity"],["rings","lonDensity"],["lanes","segs"]],Ks=["orbitN","ghostN","nodeN","strandN","signals"],_s=["iconD"],Js=["rBase","rDepth","rActive","rDot","ghostR","partR","partRDepth","nodeR","nodeRDepth"];function Ao(t,e){const a={...t},r=new Set,s=Math.sqrt(e);for(const[o,i]of Us){const n=a[o],l=a[i];n!=null&&l!=null&&!r.has(o)&&!r.has(i)&&(a[o]=Math.max(2,Math.round(n*s)),a[i]=Math.max(2,Math.round(l*s)),r.add(o),r.add(i))}for(const o of Ks){const i=a[o];i!=null&&i!==0&&!r.has(o)&&(a[o]=Math.max(1,Math.round(i*e)))}for(const o of _s){const i=a[o];i!=null&&(a[o]=Math.max(.02,i*e))}return a}function Oo(t,e){const a={...t};for(const r of Js){const s=a[r];s!=null&&(a[r]=s*e)}return a.rSizeMul=(a.rSizeMul??1)*e,a}const Zs={globe:{latRings:17,lonDensity:44,rBase:.6,rDepth:1.7,rBoost:1,inkFar:.62,inkSpan:.54,rsPow:.6,rMin:.3},orbits:{orbitN:12,ghostN:40,ghostR:.9,ghostA:.5,particles:3,partR:1.2,partRDepth:1.6,rsPow:.6,rMin:.3},rubik:{latRings:15,lonDensity:40,moveCount:14,rBase:.6,rDepth:1.7,rActive:.3,inkFar:.62,inkSpan:.54,rsPow:.6,rMin:.3},wave:{rings:15,lonDensity:40,rBase:.6,rDepth:1.7,rsPow:.6,rMin:.3},web:{nodeN:30,thr:.72,signals:5,nodeR:1.4,nodeRDepth:1.8,lineW:.8,rsPow:.6,rMin:.3},braid:{strandN:52,turns:3,ghostN:150,rBase:1.2,rDepth:1.8,rsPow:.6,rMin:.3},ribbon:{lanes:5,segs:88,ghostN:150,rBase:1.1,rDepth:1.7,rsPow:.6,rMin:.3},ring:{lanes:5,segs:88,ghostN:0,faceOn:1,rBase:1.1,rDepth:1.7,rsPow:.6,rMin:.3},morph:{rDot:.021,iconD:1,rMin:.25}},Qs=(t,e,a)=>{const r=t/2,s=t/2,o=t/2*.76,i=Mt(e*.4,.3,r,s,1),n=zt(t,a.rsPow??.6),l=[],f=a.ghostN??150;for(let c=0;c<f;c++){const d=hr(c,f),[m,k,x]=i(d[0]*o,d[1]*o,d[2]*o),W=(x/o+1)/2;l.push({x:m,y:k,z:x,r:.8*n,white:.78,a:.1+.22*W})}const p=a.strandN??52,b=a.turns??3;for(let c=0;c<3;c++){const d=c/3*2*Math.PI;for(let m=0;m<p;m++){const k=(Ho(m/p+e*.045)*2-1)*.96,x=Math.sqrt(Math.max(0,1-k*k)),W=Math.min(1,(1-Math.abs(k))/.1),y=k*Math.PI*b+d,$=1+.075*Math.sin(k*Math.PI*b*2+d*2+e*.8),X=x*o*$,[M,v,h]=i(Math.cos(y)*X,k*o*$,Math.sin(y)*X),g=(h/o+1)/2;l.push({x:M,y:v,z:h,r:((a.rBase??1.2)+(a.rDepth??1.8)*g)*n,white:.55-.45*g,a:W*(.45+.55*g)})}}return rt(l,[],a.rMin)};function en(t,e,a,r){const s=2*e*a+r,o=t%s,i=new Array(e).fill(0);let n=-1;if(o<2*e*a){const l=Math.floor(o/a),f=(o-l*a)/a,b=1-(1-Math.min(1,f/.7))**3;if(l<e){for(let c=0;c<l;c++)i[c]=1;i[l]=b,n=l}else{const c=2*e-1-l;for(let d=0;d<c;d++)i[d]=1;i[c]=1-b,n=c}}return{amount:i,active:n}}function tn(t,e,a){let[r,s,o]=t,i=!1;for(let n=0;n<e.length;n++){if(a.amount[n]<=0)continue;const l=e[n],f=l.axis===0?r:l.axis===1?s:o;if(f<l.lo||f>=l.hi)continue;n===a.active&&(i=!0);const p=l.ang*a.amount[n],b=Math.cos(p),c=Math.sin(p);if(l.axis===0){const d=s*b-o*c;o=s*c+o*b,s=d}else if(l.axis===1){const d=r*b+o*c;o=-r*c+o*b,r=d}else{const d=r*b-s*c;s=r*c+s*b,r=d}}return[r,s,o,i]}function an(t){const e=[];for(let a=0;a<t;a++){const r=Math.min(2,Math.floor(Se(a,2.3)*3)),s=-1+.5*Math.min(3,Math.floor(Se(a,5.9)*4)),o=Se(a,7.7)<.5?1:-1;e.push({axis:r,lo:s,hi:s+.5,ang:o*Math.PI/2})}return e}const rn=(t,e,a)=>{const s=t/2,o=t/2,i=t/2*.82,n=.4+.06*Math.sin(e*.35),l=Mt(e*.5,n,s,o,i),f=e*(.5+(1.7-.5)*(a.scanMul??1)),p=zt(t,a.rsPow??.6),b=a.dimBase??1,c=[],d=a.latRings??17,m=a.lonDensity??44;for(let k=0;k<=d;k++){const x=-Math.PI/2+k/d*Math.PI,W=Math.cos(x),y=Math.sin(x),$=Math.max(1,Math.round(Math.abs(W)*m));for(let X=0;X<$;X++){const M=X/$*2*Math.PI,[v,h,g]=l(W*Math.cos(M),y,W*Math.sin(M)),H=(g+1)/2,w=qs(M+e*.5,f),A=Math.exp(-(w*w)/.18)*Math.max(0,g);c.push({x:v,y:h,z:g,r:((a.rBase??.6)+(a.rDepth??1.7)*H+(a.rBoost??1)*A)*p,white:(a.inkFar??.62)-(a.inkSpan??.54)*H,a:b+(1-b)*Math.min(1,A)})}}return rt(c,[],a.rMin)},on=(t,e,a)=>{const r=t/2,s=t/2,o=t/2*.82,i=Mt(e*.55,.35+.1*Math.sin(e*.9),r,s,o),n=zt(t,a.rsPow??.6),l=a.moveCount??14,f=an(l),p=en(e,l,.42,1.2),b=[],c=a.latRings??15,d=a.lonDensity??40;for(let m=0;m<=c;m++){const k=-Math.PI/2+m/c*Math.PI,x=Math.cos(k),W=Math.sin(k),y=Math.max(1,Math.round(Math.abs(x)*d));for(let $=0;$<y;$++){const X=$/y*2*Math.PI,[M,v,h,g]=tn([x*Math.cos(X),W,x*Math.sin(X)],f,p),[H,w,A]=i(M,v,h),O=(A+1)/2;b.push({x:H,y:w,z:A,r:((a.rBase??.6)+(a.rDepth??1.7)*O+(g?a.rActive??.3:0))*n,white:(a.inkFar??.62)-(a.inkSpan??.54)*O-(g?.14:0)})}}return rt(b,[],a.rMin)},sn=(t,e,a)=>{const r=t/2,s=t/2,o=t/2*.874,i=Mt(e*.18,.38,r,s,1),n=zt(t,a.rsPow??.6),l=[],f=a.rings??15,p=a.lonDensity??40;for(let b=0;b<=f;b++){const c=-Math.PI/2+b/f*Math.PI,d=Math.cos(c),m=Math.sin(c),k=.62*Math.sin(e*2.1-b*.52)+.38*Math.sin(e*1.27+b*.83),x=o*(.88+.105*k),W=Math.max(1,Math.round(Math.abs(d)*p));for(let y=0;y<W;y++){const $=y/W*2*Math.PI,[X,M,v]=i(d*Math.cos($)*x,m*x,d*Math.sin($)*x),h=(v/o+1)/2,g=Math.max(0,k);l.push({x:X,y:M,z:v,r:((a.rBase??.6)+(a.rDepth??1.7)*h)*(1+.4*g)*n,white:.66-.56*h-.1*g})}}return rt(l,[],a.rMin)};function nn(t){return t*t*(3-2*t)}function Fo(t){const e=t.length,a=[];let r=0;for(let s=0;s<e;s++){const o=t[s],i=t[(s+1)%e],n=Math.hypot(i[0]-o[0],i[1]-o[1]);a.push(n),r+=n}return s=>{let o=s*r,i=0;for(;o>a[i]&&i<e-1;)o-=a[i],i++;const n=t[i],l=t[(i+1)%e],f=a[i]?Math.min(1,o/a[i]):0;return[n[0]+(l[0]-n[0])*f,n[1]+(l[1]-n[1])*f]}}const cn=t=>{const e=-Math.PI/2+t*2*Math.PI;return[Math.cos(e)*.24,Math.sin(e)*.24]},ln=Fo([[0,-.26],[.24,.16],[-.24,.16]]),fn=Fo([[0,-.2],[.2,-.2],[.2,.2],[-.2,.2],[-.2,-.2]]),Ia=[cn,ln,fn];function dn(t){return Math.max(6,Math.round(34*t))}const tr=1.4,Ro=.9,va=tr+Ro,pn=(t,e,a)=>{const r=Ia.length,s=e%(va*r),o=a.shape!=null&&a.shape>=0&&a.shape<r?Math.floor(a.shape):-1,i=o>=0?o:Math.floor(s/va),n=o>=0?e%va:s-i*va,l=o>=0?0:n>tr?nn((n-tr)/Ro):0,f=a.spread??1,p=Ia[i],b=o>=0?p:Ia[(i+1)%r],c=160,d=[];for(let h=0;h<c;h++){const g=h/c,H=p(g),w=b(g);d.push([(H[0]+(w[0]-H[0])*l)*f,(H[1]+(w[1]-H[1])*l)*f])}const m=[];let k=0;for(let h=0;h<c;h++){const g=d[h],H=d[(h+1)%c],w=Math.hypot(H[0]-g[0],H[1]-g[1]);m.push(w),k+=w}const x=dn(a.iconD??1),W=(a.rDot??.021)*1.35*f,y=1+.02*Math.sin(n*3.1),$=[],X=t/2;let M=0,v=0;for(let h=0;h<x;h++){const g=h/x*k;for(;v+m[M]<g&&M<c-1;)v+=m[M],M++;const H=d[M],w=d[(M+1)%c],A=m[M]?Math.min(1,(g-v)/m[M]):0,O=(H[0]+(w[0]-H[0])*A)*y,E=(H[1]+(w[1]-H[1])*A)*y;$.push({x:X+O*t,y:X+E*t,z:0,r:Math.max(.35,W*t),white:.1})}return rt($,[],a.rMin)},bn=(t,e,a)=>{const r=t/2,s=t/2,o=t/2*.82,i=Mt(e*.12,.3,r,s,1),n=zt(t,a.rsPow??.6),l=[],f=a.orbitN??12,p=a.ghostN??40,b=a.particles??3;for(let c=0;c<f;c++){const d=Se(c,1.7),m=Se(c,5.2),k=Se(c,8.9),x=o*(.45+.52*d),W=d*2*Math.PI,y=Math.acos(2*m-1),$=Math.sin(y)*Math.cos(W),X=Math.cos(y),M=Math.sin(y)*Math.sin(W);let v=-X,h=$;const g=0,H=Math.max(1e-6,Math.sqrt(v*v+h*h));v/=H,h/=H;const w=X*g-M*h,A=M*v-$*g,O=$*h-X*v,E=(.25+.55*k)*(k>.5?1:-1);for(let z=0;z<p;z++){const S=z/p*2*Math.PI,[Y,D,P]=i((v*Math.cos(S)+w*Math.sin(S))*x,(h*Math.cos(S)+A*Math.sin(S))*x,(g*Math.cos(S)+O*Math.sin(S))*x),L=(P/x+1)/2;l.push({x:Y,y:D,z:P,r:(a.ghostR??.9)*n,white:.72,a:(a.ghostA??.5)*(.4+.6*L)})}for(let z=0;z<b;z++){const S=e*E+z/b*2*Math.PI+m*6,[Y,D,P]=i((v*Math.cos(S)+w*Math.sin(S))*x,(h*Math.cos(S)+A*Math.sin(S))*x,(g*Math.cos(S)+O*Math.sin(S))*x),L=(P/x+1)/2;l.push({x:Y,y:D,z:P,r:((a.partR??1.2)+(a.partRDepth??1.6)*L)*n,white:.3-.22*L})}}return rt(l,[],a.rMin)},Ur=(t,e,a)=>{const r=t/2,s=t/2,o=t/2*.78,i=a.spin??1,n=.3,l=Mt(e*.1*i,n,r,s,1),f=zt(t,a.rsPow??.6),p=[],b=a.ghostN??150;for(let O=0;O<b;O++){const E=hr(O,b),[z,S,Y]=l(E[0]*o,E[1]*o,E[2]*o),D=(Y/o+1)/2;p.push({x:z,y:S,z:Y,r:.8*f,white:.78,a:.1+.22*D})}const c=e*.24*i,d=a.faceOn?-n:.55+.3*Math.sin(e*.18)*i,m=Math.cos(c),k=0,x=Math.sin(c),W=-x*Math.sin(d),y=Math.cos(d),$=m*Math.sin(d),X=k*$-x*y,M=x*W-m*$,v=m*y-k*W,h=.23*(a.wobMul??1),g=a.faceOn?o/(1+.85*h):o,H=a.lanes??5,w=a.segs??88,A=Math.max(1,Math.round(H*(a.bandMul??1)));for(let O=0;O<A;O++){const E=(O-(A-1)/2)*.075,z=Math.abs(O-(A-1)/2)/Math.max(1,(A-1)/2);for(let S=0;S<w;S++){const Y=S/w*2*Math.PI,D=(.16*Math.sin(Y*3-e*1.7+O*.22)+.07*Math.sin(Y*5+e*1.1))*(a.wobMul??1),P=a.faceOn?1+D:1,L=a.faceOn?E:E+D,j=m*Math.cos(Y)+W*Math.sin(Y)+X*L,T=k*Math.cos(Y)+y*Math.sin(Y)+M*L,R=x*Math.cos(Y)+$*Math.sin(Y)+v*L,I=Math.sqrt(j*j+T*T+R*R),_=g*P,[V,G,ae]=l(j/I*_,T/I*_,R/I*_),Q=(ae/o+1)/2;p.push({x:V,y:G,z:ae,r:((a.rBase??1.1)+(a.rDepth??1.7)*Q)*(1-.25*z)*f,white:.52-.44*Q+.18*z,a:.4+.6*Q})}}return rt(p,[],a.rMin)},hn=(t,e,a)=>{const r=t/2,s=t/2,o=t/2*.8*(a.spread??1),i=Mt(e*.12,.32,r,s,o),n=zt(t,a.rsPow??.6),l=a.nodeN??30,f=a.thr??.72,p=a.nodeR??1.4,b=a.nodeRDepth??1.8,c=[];for(let x=0;x<l;x++){const W=hr(x,l),y=W[0]+.3*(Na(x*.31+9,e*.24)-.5)*2,$=W[1]+.3*(Na(x*.53+27,e*.21)-.5)*2,X=W[2]+.3*(Na(x*.77+55,e*.27)-.5)*2,M=Math.sqrt(y*y+$*$+X*X);c.push([y/M,$/M,X/M])}const d=[],m=[];for(let x=0;x<l;x++)for(let W=x+1;W<l;W++){const y=c[x][0]-c[W][0],$=c[x][1]-c[W][1],X=c[x][2]-c[W][2],M=Math.sqrt(y*y+$*$+X*X);if(M>=f)continue;const[v,h,g]=i(c[x][0],c[x][1],c[x][2]),[H,w,A]=i(c[W][0],c[W][1],c[W][2]),O=((g+A)/2+1)/2;d.push({x1:v,y1:h,x2:H,y2:w,white:.42,a:(1-M/f)*(.3+.55*O),w:Math.max(.6,(a.lineW??.8)*n)})}for(let x=0;x<l;x++){const[W,y,$]=i(c[x][0],c[x][1],c[x][2]),X=($+1)/2,M=1+.25*Math.sin(e*1.4+x*2.7);m.push({x:W,y,z:$,r:(p+b*X)*M*n,white:.55-.45*X})}const k=a.signals??5;for(let x=0;x<k;x++){const W=Math.floor(e*.55+x*7.31),y=Math.floor(Se(W,x*3.1+1.7)*l),$=Math.floor(Se(W,x*5.7+4.2)*l);if(y===$)continue;const X=Ho(e*.55+x*7.31),M=Da(c[y][0],c[$][0],X),v=Da(c[y][1],c[$][1],X),h=Da(c[y][2],c[$][2],X),g=Math.max(1e-6,Math.sqrt(M*M+v*v+h*h)),[H,w,A]=i(M/g,v/g,h/g),O=(A+1)/2;m.push({x:H,y:w,z:A,r:(p*1.5+b*O)*n,white:.05,a:.5+.5*O})}return rt(m,d,a.rMin)},Co={orbits:bn,globe:rn,rubik:on,wave:sn,web:hn,braid:Qs,ribbon:Ur,ring:Ur,morph:pn};Object.fromEntries(Object.entries(Co).map(([t,e])=>[t,(a,r,s,o,i)=>Yo(a,e(r,s,i),o)]));const un={working:"orbits",searching:"globe",solving:"rubik",listening:"wave",connecting:"web",weaving:"braid",composing:"ribbon",breathing:"ring",shaping:"morph"},gn={orbits:{64:{speed:1.885,count:1,size:1},32:{speed:2.9072,count:.4251,size:1.6849},20:{speed:3.9,count:.238,size:2.4}},globe:{64:{speed:2.015,count:.42,size:1.15,extra:{scanMul:4.08,dimBase:.45}},32:{speed:2.3803,count:.1839,size:1.4769,extra:{scanMul:4.2301,dimBase:.45}},20:{speed:2.665,count:.105,size:1.75,extra:{scanMul:4.335,dimBase:.45}}},rubik:{64:{speed:1.82,count:.35,size:1.05},32:{speed:1.8964,count:.1537,size:1.4951},20:{speed:1.95,count:.088,size:1.9}},wave:{64:{speed:4.388,count:.341,size:1},32:{speed:4.1512,count:.169,size:1.3232},20:{speed:3.998,count:.105,size:1.6}},web:{64:{speed:3.315,count:1.35,size:.95},32:{speed:5.0104,count:.4942,size:1.2571},20:{speed:6.63,count:.25,size:1.52}},braid:{64:{speed:1.625,count:.5,size:1},32:{speed:2.2234,count:.2056,size:1.2011},20:{speed:2.75,count:.1125,size:1.36}},ribbon:{64:{speed:2.34,count:.25,size:.85,extra:{spin:0,bandMul:3.9,wobMul:1}},32:{speed:2.7776,count:.0969,size:.9766,extra:{spin:0,bandMul:4.49,wobMul:1}},20:{speed:3.12,count:.051,size:1.073,extra:{spin:0,bandMul:4.94,wobMul:1}}},ring:{64:{speed:3.24,count:.25,size:.956,extra:{spin:0,bandMul:3.627,wobMul:.368}},32:{speed:3.5517,count:.0678,size:1.31,extra:{spin:0,bandMul:3.8265,wobMul:.4751}},20:{speed:3.78,count:.028,size:1.622,extra:{spin:0,bandMul:3.968,wobMul:.565}}},morph:{64:{speed:2.405,count:.702,size:.395,extra:{spread:1.45}},32:{speed:2.2057,count:.5937,size:.6916,extra:{spread:1.45}},20:{speed:2.08,count:.53,size:1.011,extra:{spread:1.45}}}},Kr=new Map;function mn(t,e){const a=`${t}-${e}`,r=Kr.get(a);if(r)return r;const s=un[t],o=gn[s][e];let i={...Zs[s]};o.count!==1&&(i=Ao(i,o.count)),o.size!==1&&(i=Oo(i,o.size)),o.extra&&(i={...i,...o.extra});const n={mode:s,speed:o.speed,opts:i};return Kr.set(a,n),n}function xn(t){let e=t;for(;e;){const a=e.getAttribute("data-theme");if(a==="dark")return!0;if(a==="light")return!1;if(e.classList.contains("dark"))return!0;if(e.classList.contains("light"))return!1;e=e.parentElement}return null}function $n(){return typeof matchMedia>"u"||matchMedia("(prefers-color-scheme: dark)").matches}function vn(t,e){const[a,r]=C.useState(!0);return C.useEffect(()=>{if(t==="dark"){r(!0);return}if(t==="light"){r(!1);return}const s=()=>{const l=xn(e.current);r(l??$n())};s();const o=typeof matchMedia<"u"?matchMedia("(prefers-color-scheme: dark)"):null,i=()=>s();o==null||o.addEventListener("change",i);let n=null;return typeof MutationObserver<"u"&&e.current&&(n=new MutationObserver(s),n.observe(document.documentElement,{attributes:!0,attributeFilter:["class","data-theme"],subtree:!0})),()=>{o==null||o.removeEventListener("change",i),n==null||n.disconnect()}},[t,e]),a}function yn(){const[t,e]=C.useState(!1);return C.useEffect(()=>{if(typeof matchMedia>"u")return;const a=matchMedia("(prefers-reduced-motion: reduce)");e(a.matches);const r=s=>e(s.matches);return a.addEventListener("change",r),()=>a.removeEventListener("change",r)},[]),t}const ze=Object.freeze({reach:160,strength:11,deform:19,taper:1.95,curve:2.8,falloff:24,smoothing:.3,handover:.6,squash:1.2,blur:1,fadeMs:180});let Ye=null,vt=null,Et=null,_r=0,jo=0,aa=!1,ar="",rr=0;function wn(t){if(t===Ye||(Ye=t,vt=null,Et=null,aa=!1,rr=0,jo=typeof window<"u"&&window.devicePixelRatio||1,yt(),!t||typeof Image>"u"))return;const e=new Image;e.decoding="async",e.onload=()=>{Ye===t&&(vt=e,ja())},e.src=t.src}const Ft=new Set;let Tt=!1,at=0,or=0,Xe=Number.NaN,ut=Number.NaN,sr=0,nr=0,Ze=0,ve=null,Wa=!0,ra=!1;function Mn(t,e=!0){const a=e===!0?{}:e;a.sprite&&wn(a.sprite);const r={el:t,opts:{reach:Math.max(1,a.reach??ze.reach),strength:Math.max(0,Math.min(64,a.strength??ze.strength)),deform:Math.max(0,Math.min(32,a.deform??ze.deform)),taper:Math.max(1,Math.min(4,a.taper??ze.taper)),curve:Math.max(1,Math.min(4,a.curve??ze.curve)),falloff:Math.max(2,Math.min(200,a.falloff??ze.falloff)),smoothing:Jr(a.smoothing??ze.smoothing),handover:Jr(a.handover??ze.handover),squash:Math.max(0,Math.min(3,a.squash??ze.squash)),blur:Math.max(0,Math.min(24,a.blur??ze.blur)),fadeMs:Math.max(1,a.fadeMs??ze.fadeMs)}};return Ft.add(r),Sn(),ja(),()=>{Ft.delete(r),ve===r&&(ve=null),Ft.size===0&&queueMicrotask(()=>{Ft.size===0&&Wn()})}}const Jr=t=>Math.max(0,Math.min(1,t)),Ha=t=>t.opts,Qt=t=>typeof window.matchMedia=="function"&&window.matchMedia(t).matches;function zn(){if(aa)return ar||"disabled by a fail-safe";if(!Ye)return"no pointer sprite set";if(!vt)return"pointer sprite still loading";if(Qt("(prefers-reduced-motion: reduce)"))return"prefers-reduced-motion is on";if(Qt("(forced-colors: active)"))return"forced colours are active";if(!Qt("(pointer: fine)")||!Qt("(hover: hover)"))return"no fine pointer";if((window.devicePixelRatio||1)!==jo)return"display scale changed since the sprite was set — reload";const t=window.visualViewport;return t&&Math.abs(t.scale-1)>.001?"page is zoomed":null}function kn(){return zn()===null}function Sn(){Tt||Ft.size===0||typeof document>"u"||Qt("(pointer: fine)")&&(Tt=!0,document.addEventListener("pointermove",Eo,{passive:!0}),document.addEventListener("pointerleave",Qe),document.addEventListener("pointercancel",Qe),document.addEventListener("keydown",Po,{passive:!0}),document.addEventListener("visibilitychange",Qe),window.addEventListener("blur",Qe))}function Wn(){Tt&&(Tt=!1,document.removeEventListener("pointermove",Eo),document.removeEventListener("pointerleave",Qe),document.removeEventListener("pointercancel",Qe),document.removeEventListener("keydown",Po),document.removeEventListener("visibilitychange",Qe),window.removeEventListener("blur",Qe),at!==0&&(cancelAnimationFrame(at),at=0),ve=null,Ze=0,yt(),Ee&&(Ee.remove(),Ee=null,qe=null,Oa=null),mt&&(mt.remove(),mt=null))}function Eo(t){Wa=t.pointerType==="mouse"||t.pointerType==="",ra=!1,ur++,Xe=sr=t.clientX,ut=nr=t.clientY,ca&&(ca=!1,oa(),sa=0,na=0,gt=Rt=Number.NaN),ja()}function Po(){ra=!0,yt()}function Qe(){Xe=ut=Number.NaN,ja()}function ja(){!Tt||at!==0||(or=performance.now(),at=requestAnimationFrame(lr))}let Ee=null,qe=null,Oa=null,Lt=!1;const $t="thinking-orb-gravity-hide";let mt=null,ia=!1;const Zr=new WeakMap;let ur=0,gr=-1,ir=0,To=-1;function Hn(){if(Ee)return!0;const t=document.createElement("div");t.className="thinking-orb-gravity-cursor",t.setAttribute("aria-hidden","true"),t.style.cssText="position:fixed;left:0;top:0;pointer-events:none;z-index:2147483001;will-change:transform;display:none";const e=document.createElement("canvas");e.style.display="block",t.appendChild(e),document.body.appendChild(t);const a=e.getContext("2d");return a?(Ee=t,qe=e,Oa=a,cr=0,!0):(t.remove(),!1)}function Xn(){mt||(mt=document.createElement("style"),mt.textContent=`html.${$t}, html.${$t} * { cursor: none !important; }`,document.head.appendChild(mt))}function Yn(t){const e=Zr.get(t);if(e)return e;const a=document.documentElement,r=a.classList.contains($t);r&&a.classList.remove($t);const s=getComputedStyle(t).cursor;return r&&a.classList.add($t),Zr.set(t,s),s}function Qr(t,e){const a=document.elementFromPoint(t,e);if(!a)return!1;const r=Yn(a);return r!=="auto"&&r!=="default"?(mr(),!1):(ia||(Xn(),document.documentElement.classList.add($t),ia=!0,gr=ur,To=ir),!0)}function mr(){ia&&(document.documentElement.classList.remove($t),ia=!1,gr=-1)}function oa(){Ee&&Lt&&(Ee.style.display="none",Lt=!1)}const An=500;let eo=Number.NEGATIVE_INFINITY,ca=!1;function yt(){ca=!1,mr(),oa(),sa=0,na=0,gt=Rt=Number.NaN}const xt={cx:0,cy:0,r:0};let sa=0,na=0,gt=Number.NaN,Rt=Number.NaN;const dt=48,to=10;let At=null,qa=null,pt=null,bt=null,Ct=null,cr=0,ao=0,ro=0;function On(t){if(!vt||!Ye)return null;const e=document.createElement("canvas");e.width=Math.ceil(Ye.width*t),e.height=Math.ceil(Ye.height*t);const a=e.getContext("2d",{willReadFrequently:!0});return a?(a.scale(t,t),a.drawImage(vt,0,0,Ye.width,Ye.height),a.getImageData(0,0,e.width,e.height)):null}function Fn(t,e,a,r,s,o,i){if(!Et||!Ct)return;const n=Ct.width,l=Ct.height,f=Et,p=f.width,b=f.height,c=f.data,d=Ct.data;d.fill(0);const m=Math.max(1,Math.hypot(p,b)),k=o-r,x=i-s,W=Math.hypot(k,x)||1,y=k/W,$=x/W,X=Math.max(0,Math.floor(a+Math.min(0,t*y)-3)),M=Math.min(n,Math.ceil(a+p+Math.max(0,t*y)+3)),v=Math.max(0,Math.floor(a+Math.min(0,t*$)-3)),h=Math.min(l,Math.ceil(a+b+Math.max(0,t*$)+3));for(let g=v;g<h;g++)for(let H=X;H<M;H++){const w=(g*n+H)*4;let A=H-a,O=g-a;if(t>.01){let T=H,R=g,I=0,_=0,V=0,G=1;for(let fe=0;fe<7;fe++){const q=Math.hypot(T-r,R-s)/m;I=t*Math.pow(Math.min(1,q),e),_=o-T,V=i-R,G=Math.hypot(_,V)||1,T+=(H-I*_/G-T)*.5,R+=(g-I*V/G-R)*.5}const ae=T+I*_/G-H,Q=R+I*V/G-g;if(ae*ae+Q*Q>2.25){d[w]=d[w+1]=d[w+2]=d[w+3]=0;continue}A=T-a,O=R-a}const E=Math.floor(A),z=Math.floor(O);if(E<-1||z<-1||E>=p||z>=b){d[w]=d[w+1]=d[w+2]=d[w+3]=0;continue}const S=A-E,Y=O-z;let D=0,P=0,L=0,j=0;for(let T=0;T<4;T++){const R=E+(T&1),I=z+(T>>1);if(R<0||I<0||R>=p||I>=b)continue;const _=(T&1?S:1-S)*(T>>1?Y:1-Y),V=(I*p+R)*4,G=_*c[V+3];D+=c[V]*G,P+=c[V+1]*G,L+=c[V+2]*G,j+=G}j>0?(d[w]=D/j,d[w+1]=P/j,d[w+2]=L/j,d[w+3]=j):d[w]=d[w+1]=d[w+2]=d[w+3]=0}}function oo(t,e,a){if(!Oa||!qe||!Ee||!Ye||!vt)return;const r=Ye,s=Ha(t),o=Math.min(3,window.devicePixelRatio||1);if(At||(At=document.createElement("canvas"),qa=At.getContext("2d")),pt||(pt=document.createElement("canvas"),bt=pt.getContext("2d")),!qa||!bt||((!Et||_r!==o)&&(Et=On(o),_r=o),!Et))return;if(o!==cr||r.width!==ao||r.height!==ro){cr=o,ao=r.width,ro=r.height;const Y=Math.ceil((r.width+2*dt)*o),D=Math.ceil((r.height+2*dt)*o);qe.width=At.width=pt.width=Y,qe.height=At.height=pt.height=D,qe.style.width=`${r.width+2*dt}px`,qe.style.height=`${r.height+2*dt}px`,Ct=bt.createImageData(Y,D)}const i=qe.width,n=qe.height,l=Math.pow(e,s.curve),f=1-Math.exp(-a/(.012+s.smoothing*.14));sa+=(s.strength*l-sa)*f,na+=(s.deform*l-na)*f;let p=sa*o,b=na*o;if(Number.isNaN(gt))gt=xt.cx,Rt=xt.cy;else{const Y=1-Math.exp(-a/(.05+s.handover*.6));gt+=(xt.cx-gt)*Y,Rt+=(xt.cy-Rt)*Y}const c=dt*o,d=c+r.hotX*o,m=c+r.hotY*o,k=d+(gt-sr)*o,x=m+(Rt-nr)*o,W=Math.hypot(k-d,x-m)||1,y=(k-d)/W,$=(x-m)/W,X=s.falloff*o;if(s.squash>0){const Y=Math.hypot(r.width*.5-r.hotX,r.height-r.hotY)||1,D=(r.width*.5-r.hotX)/Y,P=(r.height-r.hotY)/Y,L=Math.max(0,-(y*D+$*P)),j=1+s.squash*L;p*=j,b*=j}const M=Math.ceil(Math.max(b,1))+4,v=Math.floor(Math.min(c,c+y*p)-M),h=Math.floor(Math.min(c,c+$*p)-M),g=Math.ceil(Math.max(c,c+y*p)+r.width*o+M),H=Math.ceil(Math.max(c,c+$*p)+r.height*o+M),w=Math.max(0,v),A=Math.max(0,h),O=Math.min(i,g)-w,E=Math.min(n,H)-A;b>.01?(Fn(b,s.taper,c,d,m,k,x),bt.putImageData(Ct,0,0,w,A,O,E)):(bt.setTransform(1,0,0,1,0,0),bt.clearRect(0,0,i,n),bt.drawImage(vt,c,c,r.width*o,r.height*o));const z=Oa,S=qa;if(z.setTransform(1,0,0,1,0,0),z.clearRect(0,0,i,n),z.globalAlpha=1,z.globalCompositeOperation="source-over",z.drawImage(pt,0,0),p>.5){const Y=c+r.width*o*.42,D=c+r.height*o*.5,P=X/2,L=S.createLinearGradient(Y-y*P,D-$*P,Y+y*P,D+$*P);L.addColorStop(0,"rgba(0,0,0,0)"),L.addColorStop(1,"rgba(0,0,0,1)");for(let j=to;j>=1;j--){const T=j/to;S.setTransform(1,0,0,1,0,0),S.globalCompositeOperation="source-over",S.globalAlpha=1,S.clearRect(w,A,O,E),S.drawImage(pt,w,A,O,E,w+y*p*T,A+$*p*T,O,E),S.globalCompositeOperation="destination-in",S.fillStyle=L,S.fillRect(w,A,O,E),z.globalCompositeOperation="destination-over",z.globalAlpha=Math.pow(1-T,1.6)*.9,s.blur>0&&(z.filter=`blur(${(s.blur*Math.sqrt(T)*o).toFixed(2)}px)`),z.drawImage(At,w,A,O,E,w,A,O,E)}z.filter="none",z.globalAlpha=1,z.globalCompositeOperation="source-over"}Ee.style.transform=`translate3d(${(sr-r.hotX-dt).toFixed(2)}px,${(nr-r.hotY-dt).toFixed(2)}px,0)`,Lt||(Ee.style.display="",Lt=!0)}function lr(t){if(at=0,!Tt)return;const e=performance.now();try{Rn(t)}catch(r){aa=!0,ar=`disabled after an error (${r instanceof Error?r.message:String(r)})`,yt(),ve=null,typeof console<"u"&&console.warn("thinking-orbs: gravity disabled after error",r);return}const a=performance.now()-e;a>12?++rr>=30&&!aa&&(aa=!0,ar=`disabled after slow frames (~${Math.round(a)}ms each)`,yt()):rr=0}function Rn(t){const e=Math.min(.05,Math.max(.001,(t-or)/1e3));or=t,ir++;let a=null,r=0;if(!Number.isNaN(Xe)&&kn()){let n=Number.POSITIVE_INFINITY;for(const l of Ft){if(!l.el.isConnected)continue;const f=l.el.getBoundingClientRect();if(f.width<=0)continue;const p=f.left+f.width/2,b=f.top+f.height/2,c=Math.min(f.width,f.height)/2,d=Ha(l).reach;if(Xe<p-c-d||Xe>p+c+d||ut<b-c-d||ut>b+c+d)continue;const m=Math.hypot(Xe-p,ut-b)-c;m<=d&&m<n&&(n=m,a=l,xt.cx=p,xt.cy=b,xt.r=c)}if(a){const l=1-Math.max(0,n)/Ha(a).reach;r=l*l*(3-2*l),eo=t}}const s=ve??a,o=s?Ha(s).fadeMs:ze.fadeMs,i=1-Math.exp(-(e*1e3)/(o/3));if(Ze+=(r-Ze)*i,a&&a!==ve&&(ve=a),!a&&Ze<.002){if(Ze=0,ve&&ia&&!ca&&Wa&&!ra&&!Number.isNaN(Xe)){if(t-eo<An){Qr(Xe,ut)?oo(ve,0,e):oa(),at=requestAnimationFrame(lr);return}if(Lt){mr(),ca=!0,ve=null;return}}ve=null,yt();return}ve&&(Ze>.002&&Wa&&!ra&&!Number.isNaN(Xe)&&Hn()&&Qr(Xe,ut)?gr===ur&&ir-To<2&&!Lt?oa():oo(ve,Ze,e):Ze>.002&&!Number.isNaN(Xe)&&Wa&&!ra?oa():yt(),at=requestAnimationFrame(lr))}function Cn(t){if(!t)return;const e=t.trim().match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);if(e){let r=e[1];r.length===3&&(r=r.replace(/./g,o=>o+o));const s=parseInt(r,16);return{r:s>>16&255,g:s>>8&255,b:s&255}}const a=t.trim().match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/i);if(a)return{r:Number(a[1]),g:Number(a[2]),b:Number(a[3])}}const jn={working:"Working…",searching:"Searching…",solving:"Solving…",listening:"Listening…",connecting:"Connecting…",weaving:"Weaving…",composing:"Composing…",breathing:"Thinking…",shaping:"Shaping…"};function En({state:t="working",size:e=64,theme:a="auto",speed:r=1,paused:s=!1,color:o,dots:i=1,dotSize:n=1,opts:l,frame:f,gravity:p,style:b,"aria-label":c,...d}){const m=C.useRef(null),k=l?JSON.stringify(l):"",x=vn(a,m),W=p?JSON.stringify(p):"";C.useEffect(()=>{const $=m.current;if(!(!$||!p))return Mn($,p===!0?!0:p)},[W]);const y=yn();return C.useEffect(()=>{const $=m.current;if(!$)return;const X=Math.min(2,typeof devicePixelRatio<"u"&&devicePixelRatio||1);$.width=Math.round(e*X),$.height=Math.round(e*X);const M=$.getContext("2d");if(!M)return;const{mode:v,speed:h,opts:g}=mn(t,e);let H=i!==1?Ao(g,Math.max(.1,i)):g;n!==1&&(H=Oo(H,Math.max(.1,n))),l&&(H={...H,...l});const w=f??Co[v],A=Cn(o),O=h*r,E=R=>{M.setTransform(X,0,0,X,0,0),M.clearRect(0,0,e,e),Yo(M,w(e,R,H),x,A)};if(y){E(.6);return}let z=0,S=!1;const Y=()=>{E(performance.now()/1e3*O),S&&(z=requestAnimationFrame(Y))},D=()=>{S||s||(S=!0,z=requestAnimationFrame(Y))},P=()=>{S=!1,cancelAnimationFrame(z)};E(performance.now()/1e3*O);let L=!0;const j=typeof IntersectionObserver<"u"?new IntersectionObserver(([R])=>{L=R.isIntersecting,L&&document.visibilityState!=="hidden"?D():P()}):null;j==null||j.observe($);const T=()=>{document.visibilityState==="hidden"?P():L&&D()};return document.addEventListener("visibilitychange",T),j||D(),()=>{P(),j==null||j.disconnect(),document.removeEventListener("visibilitychange",T)}},[t,e,x,r,s,y,o,i,n,k,f]),u.jsx("canvas",{ref:m,role:"img","aria-label":c??jn[t],style:{width:e,height:e,display:"block",...b},...d})}function Lo(t){const e=t.trim(),a=e.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);if(a){const s=a[1].length===3?a[1].split("").map(o=>o+o).join(""):a[1];return[parseInt(s.slice(0,2),16),parseInt(s.slice(2,4),16),parseInt(s.slice(4,6),16)]}const r=e.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/i);return r?[Math.round(+r[1]),Math.round(+r[2]),Math.round(+r[3])]:null}function Pn(t){const e=Lo(t);return e?`rgb(${e[0]}, ${e[1]}, ${e[2]})`:null}function ya(t){const e=Lo(t);return e?`${e[0]}, ${e[1]}, ${e[2]}`:null}const Tn={dark:{strokeOpacity:1.16,innerOpacity:.47,bloomOpacity:.89,innerShadow:"rgba(255, 255, 255, 0.1)",saturation:1.2,brightness:1.1},light:{strokeOpacity:1.2,innerOpacity:.85,bloomOpacity:.5,innerShadow:"rgba(0, 0, 0, 0.08)",saturation:1.6,brightness:.95,hueRange:40,hueDuration:8.5,hueBase:5,strength:.8,bandStrength:1.7}},Bt=[{x:0,w:74,h:46,band:0},{x:-36,w:54,h:40,band:1},{x:36,w:54,h:40,band:1},{x:-72,w:48,h:32,band:2},{x:72,w:48,h:32,band:2},{x:-108,w:42,h:26,band:1},{x:108,w:42,h:26,band:1}],Ln=36,Bn=Ln*Bt.length,Dn={colorful:{dark:["rgb(255, 70, 120)","rgb(60, 190, 255)","rgb(175, 70, 255)","rgb(60, 220, 130)","rgb(255, 150, 40)","rgb(90, 100, 255)","rgb(40, 200, 190)"],light:["rgb(255, 201, 21)","rgb(126, 196, 255)","rgb(180, 40, 230)","rgb(235, 100, 160)","rgb(255, 176, 122)","rgb(154, 160, 255)","rgb(127, 217, 238)"]},mono:{dark:["rgb(215, 215, 215)","rgb(180, 180, 180)","rgb(190, 190, 190)","rgb(160, 160, 160)","rgb(170, 170, 170)","rgb(150, 150, 150)","rgb(155, 155, 155)"],light:["rgb(60, 60, 60)","rgb(90, 90, 90)","rgb(85, 85, 85)","rgb(110, 110, 110)","rgb(105, 105, 105)","rgb(125, 125, 125)","rgb(120, 120, 120)"]},ocean:{dark:["rgb(80, 140, 255)","rgb(40, 200, 230)","rgb(120, 90, 255)","rgb(30, 170, 210)","rgb(160, 80, 240)","rgb(60, 110, 255)","rgb(40, 190, 180)"],light:["rgb(40, 100, 240)","rgb(20, 160, 200)","rgb(90, 60, 230)","rgb(20, 130, 180)","rgb(130, 50, 220)","rgb(40, 80, 230)","rgb(20, 150, 150)"]},sunset:{dark:["rgb(255, 110, 60)","rgb(255, 180, 40)","rgb(255, 60, 90)","rgb(255, 210, 80)","rgb(240, 70, 140)","rgb(255, 140, 50)","rgb(230, 50, 110)"],light:["rgb(235, 80, 30)","rgb(230, 150, 10)","rgb(230, 30, 70)","rgb(225, 175, 30)","rgb(215, 40, 110)","rgb(235, 110, 20)","rgb(205, 30, 90)"]},forest:{dark:["rgb(70, 220, 120)","rgb(40, 200, 180)","rgb(140, 230, 80)","rgb(30, 170, 140)","rgb(190, 235, 70)","rgb(50, 190, 110)","rgb(30, 150, 120)"],light:["rgb(30, 170, 80)","rgb(20, 150, 130)","rgb(90, 180, 30)","rgb(20, 130, 100)","rgb(130, 180, 20)","rgb(30, 150, 80)","rgb(20, 120, 90)"]},candy:{dark:["rgb(255, 90, 170)","rgb(255, 120, 220)","rgb(210, 80, 255)","rgb(255, 150, 190)","rgb(180, 110, 255)","rgb(255, 70, 140)","rgb(230, 100, 240)"],light:["rgb(235, 40, 140)","rgb(230, 70, 190)","rgb(180, 40, 230)","rgb(235, 100, 160)","rgb(150, 70, 230)","rgb(230, 30, 110)","rgb(200, 60, 210)"]},ice:{dark:["rgb(150, 230, 255)","rgb(90, 200, 255)","rgb(190, 240, 255)","rgb(120, 190, 255)","rgb(160, 220, 250)","rgb(80, 170, 255)","rgb(200, 235, 255)"],light:["rgb(30, 160, 220)","rgb(20, 130, 210)","rgb(60, 180, 230)","rgb(40, 120, 220)","rgb(50, 160, 220)","rgb(20, 110, 220)","rgb(70, 170, 230)"]},gold:{dark:["rgb(255, 200, 70)","rgb(255, 170, 40)","rgb(255, 220, 110)","rgb(240, 150, 30)","rgb(255, 235, 140)","rgb(230, 160, 40)","rgb(250, 210, 90)"],light:["rgb(200, 140, 10)","rgb(190, 120, 0)","rgb(210, 160, 30)","rgb(180, 110, 0)","rgb(205, 170, 40)","rgb(175, 115, 5)","rgb(195, 150, 20)"]}};function Nn(t,e){const a=t.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return a?`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${e.toFixed(2)})`:t}function Ga(t,e=1){return Math.max(.5,Math.round(t*e*100)/100)}function In(t,e){return`calc(50% + (var(--vb-cx-${e}) + var(--vb-x${t}-${e})) * var(--vb-w-${e}) * var(--vb-z-${e}, 1))`}function Va({id:t,colors:e,alpha:a,sw:r,sh:s,y:o,fade:i,count:n}){return(n?Bt.slice(0,n):Bt).map((l,f)=>{const p=a>=1?e[f%e.length]:Nn(e[f%e.length],a),b=`calc(${Math.round(l.w*r)}px * var(--vb-w-${t}) * var(--vb-z-${t}, 1))`,c=`calc(${Math.round(l.h*s)}px * var(--vb-h-${t}) * var(--vb-l${f}-${t}) * var(--vb-z-${t}, 1))`,d=`calc(100% + (${o}px + var(--vb-y${f}-${t})) * var(--vb-z-${t}, 1))`;return`radial-gradient(ellipse ${b} ${c} at ${In(f,t)} ${d}, ${p} 0%, transparent ${i}%)`}).join(`,
    `)}function qn(t){const{id:e,borderRadius:a,borderWidth:r,strokeOpacity:s,innerOpacity:o,bloomOpacity:i,innerShadow:n,colorVariant:l,colors:f,brightness:p,saturation:b,theme:c,hueBase:d=0,glowSize:m=1,glowWidth:k=1,glowHeight:x=1,strokeScale:W=1,innerScale:y=1,innerHeight:$=1,bloomScale:X=1,bloomHeight:M=1,coreSize:v=1,coreLight:h=0,coreLightWidth:g=1,coreLightHeight:H=1,rangeWidth:w=1,rangeHeight:A=1,softness:O=1,distortion:E=!1,scale:z=1}=t,S=Math.round(28*z*10)/10,Y=Math.round(9*z*10)/10,D=Math.max(0,a-r),P=Math.round(Math.max(40,Math.min(95,70*O))),L=ee=>k*ee,j=ee=>x*ee,T=ee=>Math.round(ee*10)/10,R=`var(--vb-z-${e}, 1)`,I=ee=>`calc(${T(ee)}px * ${R})`,_=c==="dark",V=Dn[l][_?"dark":"light"].map((ee,re)=>{const be=f==null?void 0:f[re];return be&&Pn(be)||ee}),G=l==="mono"?.6:1,ae=(s*G).toFixed(2),Q=(o*G).toFixed(2),fe=(i*G).toFixed(2),q=p.toFixed(2),ie=b.toFixed(2),de=`hue-rotate(calc(var(--voice-hue-base, ${d}deg) + var(--vb-hue-${e})))`,Z=E?` url(#vb-distort-${e})`:"",oe=`filter: ${de} brightness(${q}) saturate(${ie});`,me=`filter: ${de} brightness(${q}) saturate(${ie})${Z};`,he=`filter: blur(${I(Ga(10,m))}) ${de} brightness(${q}) saturate(${ie});`,ue=`filter: blur(${I(Ga(10,m))}) ${de} brightness(${q}) saturate(${ie})${Z};`,le=`calc(50% + var(--vb-cx-${e}) * var(--vb-w-${e}) * ${R})`,Pe=`calc(100% + (2px + var(--vb-cy-${e})) * ${R})`,Te=_?`radial-gradient(ellipse calc(${T(30*v)}px * var(--vb-w-${e}) * ${R}) calc(${T(30*v)}px * var(--vb-h-${e}) * ${R}) at ${le} ${Pe}, rgba(255, 255, 255, 0.45) 0%, rgba(255, 255, 255, 0.14) 30%, transparent 65%)`:`radial-gradient(ellipse calc(${T(40*v)}px * var(--vb-w-${e}) * ${R}) calc(${T(30*v)}px * var(--vb-h-${e}) * ${R}) at ${le} ${Pe}, rgba(0, 0, 0, 0.55) 0%, rgba(0, 0, 0, 0.22) 35%, transparent 70%)`,Le=Va({id:e,colors:V,alpha:1,sw:L(W),sh:j(W),y:2,fade:P}),Ae=Va({id:e,colors:V,alpha:.46,sw:L(.9*y),sh:j(.9*y*$),y:0,fade:P}),ye=Va({id:e,colors:V,alpha:_?.9:.7,sw:L(1.15*X),sh:j(1.5*X*M),y:0,fade:Math.min(95,P+2)}),xe=(ee,re,be,$e=0)=>`radial-gradient(ellipse calc(${T(ee*w)}px * var(--vb-w-${e}) * var(--vb-mw-${e}) * ${R}) calc((${T(re*A)}px * var(--vb-h-${e}) + var(--vb-bh-${e})) * ${R}) at ${le} calc(100% + var(--vb-cy-${e}) * ${R}), white 0%, rgba(255, 255, 255, 0.5) ${be}%${$e>0?`, rgba(255, 255, 255, ${$e}) 85%`:""}, transparent 100%)`,We=(ee,re)=>`opacity: calc(var(--vb-opacity-${e}, 1) * var(--vb-glow-${e}) * ${re} * var(--voice-${ee}-opacity, 1) * var(--voice-strength, 1));`,Oe=(ee,re,be,$e)=>`${ee} {
  ${re}
  position: absolute;
  inset: 0;
  border-radius: ${I(a)};
  background: ${Ae};
  box-shadow: inset 0 0 ${I(Y)} 1px ${n};
  -webkit-mask-image:
    ${xe(170,64,45,.3)},
    linear-gradient(white, transparent ${I(S)}, transparent calc(100% - ${S}px * ${R}), white),
    linear-gradient(to right, white, transparent ${I(S)}, transparent calc(100% - ${S}px * ${R}), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    ${xe(170,64,45,.3)},
    linear-gradient(white, transparent ${I(S)}, transparent calc(100% - ${S}px * ${R}), white),
    linear-gradient(to right, white, transparent ${I(S)}, transparent calc(100% - ${S}px * ${R}), white);
  mask-composite: intersect, add;
  pointer-events: none;
  /* Its own compositing layer: WebKit otherwise re-rasterizes the
     filtered layer into the parent every frame on the CPU (a phone-sized
     host runs at a sixth of the frame rate without this). */
  will-change: transform;
  z-index: 1;
  ${be}
  ${We("inner",Q)}
  ${$e}
}`;return`
@property --vb-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-voice-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
  --vb-h-${e}: 0.8;
  --vb-w-${e}: 1;
${Bt.map((ee,re)=>`  --vb-x${re}-${e}: ${ee.x}px;
  --vb-l${re}-${e}: 1;
  --vb-y${re}-${e}: 0px;`).join(`
`)}
  --vb-glow-${e}: 0.4;
  --vb-z-${e}: 1;
  --vb-cx-${e}: 0px;
  --vb-cy-${e}: 0px;
  --vb-bh-${e}: 0px;
  --vb-bendA-${e}: 0;
  --vb-mw-${e}: 1;
  --vb-hue-${e}: 0deg;
  --vb-level-${e}: 0;
}

[data-voice-beam="${e}"][data-active] {
  animation: vb-fade-in-${e} 0.6s ease forwards;
}

[data-voice-beam="${e}"][data-fading] {
  animation: vb-fade-out-${e} 0.5s ease forwards;
}

/* Stroke — the colours painted into the 1px edge ring, masked to the centred ellipse. */
[data-voice-beam="${e}"][data-active]::after,
[data-voice-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${I(D)};
  padding: ${I(r)};
  clip-path: inset(0 round ${I(a)});
  background:
    ${Te},
    ${Le};
  -webkit-mask:
    ${xe(170,64,45)},
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    ${xe(170,64,45)},
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  /* Its own compositing layer: WebKit otherwise re-rasterizes the
     filtered layer into the parent every frame on the CPU (a phone-sized
     host runs at a sixth of the frame rate without this). */
  will-change: transform;
  z-index: 2;
  ${We("stroke",ae)}
  ${oe}
}

/* Inner glow — soft light inside the element, faded off at the corners.
   With distortion on, this copy is clipped to ABOVE the band line (the
   polygon the driver writes each frame) and a mirror layer below carries
   the displacement filter, so only the glow under the line warps. */
${Oe(`[data-voice-beam="${e}"][data-active]::before,
[data-voice-beam="${e}"][data-fading]::before`,'content: "";',E?`clip-path: var(--vb-clip-above-${e}, inset(0 round ${a}px));`:`clip-path: inset(0 round ${a}px);`,oe)}
${E?Oe(`[data-voice-beam="${e}"][data-active] [data-voice-beam-warp="inner"],
[data-voice-beam="${e}"][data-fading] [data-voice-beam-warp="inner"]`,"display: block;",`clip-path: var(--vb-clip-below-${e}, inset(0 round ${a}px));`,me):""}

/* Bloom — the blurred halo, tallest of the three, above the content. */
[data-voice-beam="${e}"] [data-voice-beam-bloom],
[data-voice-beam="${e}"] [data-voice-beam-warp] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${I(D)};
  pointer-events: none;
  /* Its own compositing layer: WebKit otherwise re-rasterizes the
     filtered layer into the parent every frame on the CPU (a phone-sized
     host runs at a sixth of the frame rate without this). */
  will-change: transform;
  opacity: 0;
}

[data-voice-beam="${e}"] [data-voice-beam-bloom],
[data-voice-beam="${e}"] [data-voice-beam-warp="bloom"] {
  -webkit-mask: ${xe(200,130,35)};
  mask: ${xe(200,130,35)};
  background: ${ye};
  z-index: 3;
}

[data-voice-beam="${e}"][data-active] [data-voice-beam-bloom],
[data-voice-beam="${e}"][data-fading] [data-voice-beam-bloom] {
  display: block;
  clip-path: ${E?`var(--vb-clip-above-${e}, inset(0 round ${a}px))`:`inset(0 round ${a}px)`};
  ${We("bloom",fe)}
  ${he}
}
${E?`
[data-voice-beam="${e}"][data-active] [data-voice-beam-warp="bloom"],
[data-voice-beam="${e}"][data-fading] [data-voice-beam-warp="bloom"] {
  display: block;
  clip-path: var(--vb-clip-below-${e}, inset(0 round ${a}px));
  ${We("bloom",fe)}
  ${ue}
}

/* Processing drops the distortion: the driver marks the wrapper once the
   warp has faded out, the warp layers leave the paint and the base layers
   give up their split at the band line. */
[data-voice-beam="${e}"][data-voice-warp="off"]::before,
[data-voice-beam="${e}"][data-voice-warp="off"] [data-voice-beam-bloom] {
  clip-path: inset(0 round ${a}px);
}

[data-voice-beam="${e}"][data-voice-warp="off"] [data-voice-beam-warp] {
  display: none;
}`:""}

/* Epicentre — a soft white wash at the source, under the band line (the
   driver's clip; unclipped when no line is drawn), sitting above every
   glow layer and the band's halo so the centre reads lighter than the
   band (same z as the band canvases, painted after them). Sized by the voice like the
   other layers; off unless \`coreLight\` is set (the light theme sets it).
   Up to 1 it is the wash's opacity; past 1 the solid white core widens
   too, for a centre that stays lighter than a strong band. It follows the
   glow's presence but not \`strength\`, which would only dim it. */
${h>0?(()=>{const ee=Math.max(0,Math.min(2,h-1)),re=Math.min(1,ee),be=Math.max(0,ee-1),$e=1+.3*ee,Ge=T(45*re+27*be),Ve=T(40+25*re+15*be),Fe=Math.min(1,.55+.35*re+.1*be).toFixed(2),Dt=T(72+14*re+8*be);return`[data-voice-beam="${e}"] [data-voice-beam-core] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${I(D)};
  overflow: hidden;
  pointer-events: none;
  /* Its own compositing layer: WebKit otherwise re-rasterizes the
     filtered layer into the parent every frame on the CPU (a phone-sized
     host runs at a sixth of the frame rate without this). */
  will-change: transform;
  /* The blur sits on this wrapper and the band-line clip on the child,
     so the cut edge is blurred too rather than left hard. */
  filter: blur(${I(Ga(8,m))});
  z-index: 4;
}

[data-voice-beam="${e}"] [data-voice-beam-core] > div {
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse calc(${T(120*g*$e*z)}px * var(--vb-w-${e}) * ${R}) calc((${T(70*H*$e*z)}px * var(--vb-h-${e}) + var(--vb-bh-${e})) * ${R}) at ${le} calc(100% + var(--vb-cy-${e}) * ${R}), white 0%, white ${Ge}%, rgba(255, 255, 255, ${Fe}) ${Ve}%, transparent ${Dt}%);
  clip-path: var(--vb-clip-below-${e}, none);
}

[data-voice-beam="${e}"][data-active] [data-voice-beam-core],
[data-voice-beam="${e}"][data-fading] [data-voice-beam-core] {
  display: block;
  opacity: calc(var(--vb-opacity-${e}, 1) * min(1, var(--vb-glow-${e}) * ${Math.min(1,h).toFixed(2)} * ${(1.6+1.4*ee).toFixed(2)}) * var(--voice-core-light-opacity, 1));
}
`})():""}
/* Band — the canvas the driver draws the bend's contour on: an organic
   bell with chromatic fringes. Fades with the root, follows the strength
   and turns with the hue drift like the other layers. */
[data-voice-beam="${e}"] [data-voice-beam-band],
[data-voice-beam="${e}"] [data-voice-beam-band-halo] {
  display: none;
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  /* Its own compositing layer: WebKit otherwise re-rasterizes the
     filtered layer into the parent every frame on the CPU (a phone-sized
     host runs at a sixth of the frame rate without this). */
  will-change: transform;
  z-index: 4;
}

[data-voice-beam="${e}"][data-active] [data-voice-beam-band],
[data-voice-beam="${e}"][data-fading] [data-voice-beam-band],
[data-voice-beam="${e}"][data-active] [data-voice-beam-band-halo],
[data-voice-beam="${e}"][data-fading] [data-voice-beam-band-halo] {
  display: block;
  opacity: calc(var(--vb-opacity-${e}, 1) * var(--voice-band-opacity, 1) * var(--voice-strength, 1));
  /* The blur vars are 0 where the canvas blurs its own strokes; where the
     2D context has no filter (WebKit) the driver sets them and the layers
     are blurred here instead — the ridge on the band canvas, its wider
     halo on the canvas beneath. */
  filter: blur(var(--vb-band-blur-${e}, 0px)) ${de} brightness(${q}) saturate(${ie});
}

[data-voice-beam="${e}"][data-active] [data-voice-beam-band-halo],
[data-voice-beam="${e}"][data-fading] [data-voice-beam-band-halo] {
  filter: blur(var(--vb-band-halo-blur-${e}, 0px)) ${de} brightness(${q}) saturate(${ie});
}

/* Resolution. The soft layers — inner light and its warp mirror, bloom and
   its mirror, the epicentre — are rastered at half size and scaled back
   up by the compositor: the box is halved, every length inside rides the
   layer's factor \`--vb-z\` at 0.5 (the driver also writes the band-line
   clips at half scale), and the will-change transform is rastered
   pre-scale where the engine does that (Chromium, Safari 18). For blurred
   gradients that is the same picture at a quarter of the raster and
   filter work, which is what a phone at 3x runs out of. The 1px stroke
   stays full-res on every screen: at half size it is half a CSS pixel,
   which a 3x phone rasters into a faint smear instead of the hairline,
   and the layer is cheap (no blur). The component sets
   \`data-voice-halfres\`. */
[data-voice-beam="${e}"][data-voice-halfres]::before,
[data-voice-beam="${e}"][data-voice-halfres] [data-voice-beam-warp],
[data-voice-beam="${e}"][data-voice-halfres] [data-voice-beam-bloom],
[data-voice-beam="${e}"][data-voice-halfres] [data-voice-beam-core] {
  --vb-z-${e}: 0.5;
  inset: auto;
  left: 0;
  top: 0;
  width: 50%;
  height: 50%;
  transform: translateZ(0) scale(2);
  transform-origin: 0 0;
}
${E?`[data-voice-beam="${e}"][data-voice-halfres][data-active]::before,
[data-voice-beam="${e}"][data-voice-halfres][data-fading]::before,
[data-voice-beam="${e}"][data-voice-halfres][data-active] [data-voice-beam-bloom],
[data-voice-beam="${e}"][data-voice-halfres][data-fading] [data-voice-beam-bloom] {
  clip-path: var(--vb-clip-above-z-${e}, inset(0 round ${I(a)}));
}
[data-voice-beam="${e}"][data-voice-halfres][data-active] [data-voice-beam-warp],
[data-voice-beam="${e}"][data-voice-halfres][data-fading] [data-voice-beam-warp] {
  clip-path: var(--vb-clip-below-z-${e}, inset(0 round ${I(a)}));
}
/* Processing (warp off): the mirrors are gone, so the base layers paint
   the whole box again — this must outweigh the split above. */
[data-voice-beam="${e}"][data-voice-halfres][data-voice-warp="off"]::before,
[data-voice-beam="${e}"][data-voice-halfres][data-voice-warp="off"] [data-voice-beam-bloom] {
  clip-path: inset(0 round ${I(a)});
}`:`[data-voice-beam="${e}"][data-voice-halfres][data-active]::before,
[data-voice-beam="${e}"][data-voice-halfres][data-fading]::before,
[data-voice-beam="${e}"][data-voice-halfres][data-active] [data-voice-beam-bloom],
[data-voice-beam="${e}"][data-voice-halfres][data-fading] [data-voice-beam-bloom] {
  clip-path: inset(0 round ${I(a)});
}`}
[data-voice-beam="${e}"][data-voice-halfres] [data-voice-beam-core] > div {
  clip-path: var(--vb-clip-below-z-${e}, none);
}
@keyframes vb-fade-in-${e} {
  to { --vb-opacity-${e}: 1; }
}

@keyframes vb-fade-out-${e} {
  from { --vb-opacity-${e}: 1; }
  to { --vb-opacity-${e}: 0; }
}

[data-voice-beam="${e}"][data-paused],
[data-voice-beam="${e}"][data-paused]::after,
[data-voice-beam="${e}"][data-paused]::before,
[data-voice-beam="${e}"][data-paused] [data-voice-beam-bloom] {
  animation-play-state: paused !important;
}
`}let Jt=null;function Gn(){if(typeof window>"u")return null;const t=window;return t.AudioContext??t.webkitAudioContext??null}function Vn(){const t=Gn();return t?(Jt||(Jt=new t),Jt.state==="suspended"&&Jt.resume().catch(()=>{}),Jt):null}const Ua=new WeakMap;function Un(t){const e=Vn();if(!e||t.getAudioTracks().length===0)return null;let a=Ua.get(t);a||(a={node:e.createMediaStreamSource(t),refs:0},Ua.set(t,a)),a.refs+=1;const r=e.createAnalyser();r.fftSize=1024,r.smoothingTimeConstant=.5,a.node.connect(r);let s=!1;return{analyser:r,release:()=>{if(!s){s=!0;try{a.node.disconnect(r)}catch{}if(a.refs-=1,a.refs<=0){try{a.node.disconnect()}catch{}Ua.delete(t)}}}}}const so=new WeakMap;function Kn(t){let e=so.get(t);return e||(e={level:0,bands:[0,0,0],phase:0,scanA:0,scanT:0,t:0,lastTs:0,warp:1},so.set(t,e)),e}const Fa=new Set;let Pt=null,fr=0;const _n=1e3/60-2,Jn=22,Zn=500,Qn=4e3;let Xa=0,Ka=!1,wa=!1,Ot=0,no=0;const Bo=Math.PI*2,ei=5,ti=1.7,ai=[[80,300],[300,2e3],[2e3,6e3]];function Do(t){return t<0?0:t>1?1:t}function ri(t,e){const a=e/2;return((t+a)%e+e)%e-a}function oi(t,e){const a=t/(e/2+4);return Math.max(0,1-a*a)}function io(t,e){if(t<=e)return 0;const a=(t-e)/Math.max(.001,1-e);return Do((1-Math.exp(-3*a))/(1-Math.exp(-3)))}function Ma(t,e,a,r,s){const o=e>t?r:s,i=1-Math.exp(-a/Math.max(.001,o));return t+(e-t)*i}const si=2,ni=.06,ii=.35,ci=.03,li=!(typeof navigator<"u"&&/AppleWebKit/.test(navigator.userAgent)&&!/Chrome\/|Chromium\/|Edg\/|OPR\//.test(navigator.userAgent)),co=.05,fi=6,di=12,pi=.1,lo=.1,bi=170,hi=64,fo=56;function ui(t,e,a,r){const s=t<0?1-r:1+r,o=Math.max(.05,a*s),i=Math.exp(-Math.pow(Math.abs(t)/o,e)),n=Math.exp(-Math.pow(1/o,e));return Math.max(0,(i-n)/(1-n))}function gi(t,e,a,r,s){if(a<=0||e<=0)return 0;const o=e*Math.max(0,Math.min(.98,r));if(t<=o)return 0;const i=Math.min(1,(t-o)/Math.max(1,e-o));return a*Math.pow(i,Math.max(.5,s))}function No(t,e,a){return Math.max(0,Math.min(t,e/2,a/2))}function dr(t,e,a,r=0){if(a<=0)return 0;const s=Math.min(t,e-t)-r;if(s>=a)return 0;if(s<=0)return a;const o=a-s;return a-Math.sqrt(Math.max(0,a*a-o*o))}function mi(t,e,a,r){const s=a/2+e.cx*e.w,o=bi*t.rangeWidth*e.w*e.mw,i=r*.82*Math.min(1,t.scale),n=Math.min(i,(hi*t.rangeHeight*e.h+e.lift)*t.bandPosition),l=r-t.bandOffset,f=Math.min(1,e.corner*4),p=t.bandTail*(1-f*f*(3-2*f)),b=p>.001,c=b?t.bandTailOverflow:0,d=b?-c:s-o,m=b?a+c:s+o,k=[];for(let x=0;x<=fo;x++){const W=d+(m-d)*x/fo,y=Math.max(-1,Math.min(1,(W-s)/Math.max(1,o))),$=(W<s?s:a-s)+c,X=ui(y,t.bandCurve,t.bandSpread,t.bandSkew)+gi(Math.abs(W-s),$,p,t.bandTailPosition,t.bandTailCurve),M=e.corner>0?dr(W,a,No(t.radius,a,r))*e.corner:0;k.push([W,l-n*X-M])}return k}function xi(t,e,a,r,s){for(const[o,i]of[["",1],["-z",.5]]){const n=b=>(b*i).toFixed(1)+"px",l=a.map(([b,c])=>`${n(b)} ${n(c)}`),f=`polygon(0 ${n(s)}, ${l.join(", ")}, ${n(r)} ${n(s)})`,p=`polygon(0 0, ${n(r)} 0, ${n(r)} ${n(s)}, ${l.slice().reverse().join(", ")}, 0 ${n(s)})`;t.style.setProperty(`--vb-clip-below${o}-${e}`,f),t.style.setProperty(`--vb-clip-above${o}-${e}`,p)}}function $i(t,e,a){let r=a;for(let n=0;n<e.length;n++)e[n][1]<r&&(r=e[n][1]);const s=Math.max(0,Math.min(.9,Math.floor((r-fi)/a/co)*co));if(s===t.filterTop)return;t.filterTop=s;const o=1+Math.max(pi,di/a),i=t.filter;i.setAttribute("x",`${-lo*100}%`),i.setAttribute("width",`${(1+2*lo)*100}%`),i.setAttribute("y",`${(s*100).toFixed(0)}%`),i.setAttribute("height",`${((o-s)*100).toFixed(1)}%`)}function vi(t,e,a){const{canvas:r,ctx:s,el:o,config:i}=t;if(!r||!s)return;const n=o.clientWidth,l=o.clientHeight;if(!n||!l)return;const f=Math.min(si,typeof window<"u"&&window.devicePixelRatio||1),p=Math.round(n*f),b=Math.round(l*f);(r.width!==p||r.height!==b)&&(r.width=p,r.height=b),s.setTransform(f,0,0,f,0,0),s.clearRect(0,0,n,l);const c=t.haloCanvas,d=t.haloCtx;c&&d&&((c.width!==p||c.height!==b)&&(c.width=p,c.height=b),d.setTransform(f,0,0,f,0,0),d.clearRect(0,0,n,l));const m=Math.min(1,.6*i.bandStrength*e.strength);if(m<.005||i.bandWidth<=0)return;const k=i.theme==="dark",x=i.bandWidth*(1+.35*e.level),W=i.bandAberration*(.35+.65*e.level),y=(4+12*W)*i.scale,$=4*W*i.scale,X=(P,L)=>{s.beginPath(),s.moveTo(a[0][0]+P,a[0][1]+L);for(let j=1;j<a.length;j++)s.lineTo(a[j][0]+P,a[j][1]+L)},M={r:i.bandColors.above,g:i.bandColors.mid,c:i.bandColors.core,b:i.bandColors.below},v=(k?.42:.4)*m,h=14*x,g=3.5*i.bandWidth/2,H=g*f,w=typeof s.filter=="string",A=w?"0px":`${g.toFixed(2)}px`;t.cssBlur!==A&&(o.style.setProperty(`--vb-band-blur-${i.id}`,A),o.style.setProperty(`--vb-band-halo-blur-${i.id}`,w?"0px":`${(g*3).toFixed(2)}px`),t.cssBlur=A);const O=[[1,.16],[.72,.2],[.46,.26],[.22,.34]],E=[{rgb:M.r,a:1,ox:$,oy:-y},{rgb:M.g,a:.55,ox:$*.35,oy:-y*.35},{rgb:M.b,a:1,ox:-$,oy:y},{rgb:M.c,a:.9,ox:0,oy:0}];s.lineCap="round",s.lineJoin="round",s.globalCompositeOperation="source-over";const z=a[0][0],S=a[a.length-1][0],Y=(P,L)=>{const j=s.createLinearGradient(z,0,S,0),T=i.bandTail>0?.015:.18;return j.addColorStop(0,`rgba(${P}, 0)`),j.addColorStop(T,`rgba(${P}, ${L.toFixed(3)})`),j.addColorStop(1-T,`rgba(${P}, ${L.toFixed(3)})`),j.addColorStop(1,`rgba(${P}, 0)`),j},D=!w&&d?d:s;w&&(s.filter=`blur(${(H*3).toFixed(1)}px)`),D.lineCap="round",D.lineJoin="round",D.strokeStyle=Y(M.c,v*.3),D.lineWidth=h*2.2,D.beginPath(),D.moveTo(a[0][0],a[0][1]);for(let P=1;P<a.length;P++)D.lineTo(a[P][0],a[P][1]);D.stroke(),w&&(s.filter=`blur(${H.toFixed(1)}px)`);for(const P of E)for(const[L,j]of O)s.strokeStyle=Y(P.rgb,v*P.a*j),s.lineWidth=Math.max(.6,h*L),X(P.ox,P.oy),s.stroke();w&&(s.filter="none"),s.globalCompositeOperation="source-over"}function yi(t){return(1-Math.cos(Bo*t))/2}function wi(t,e){const a=t.analyser,r=t.time,s=t.freq;a.getFloatTimeDomainData(r);let o=0;for(let n=0;n<r.length;n++)o+=r[n]*r[n];e.level=Math.sqrt(o/r.length)*ei*t.config.sensitivity,a.getByteFrequencyData(s);const i=a.context.sampleRate/a.fftSize;for(let n=0;n<3;n++){const[l,f]=ai[n],p=Math.max(0,Math.floor(l/i)),b=Math.min(s.length-1,Math.ceil(f/i));let c=0;for(let m=p;m<=b;m++)c+=s[m];const d=b>=p?c/(b-p+1)/255:0;e.bands[n]=d*ti*t.config.sensitivity}}const ht={level:0,bands:[0,0,0]};function Io(t){Pt=requestAnimationFrame(Io);const e=Xa?t-Xa:0;if(Xa=t,Ka){if(wa=!wa,wa)return;t>=no&&(Ka=!1,Ot=0)}else e>Jn?Ot?t-Ot>Zn&&(Ka=!0,wa=!1,no=t+Qn):Ot=t:Ot=0;t-fr<_n||(fr=t,Fa.forEach(a=>{var r;const{el:s,config:o,source:i,s:n}=a,l=o.paused;if(l&&a.paintedConfig===o)return;const f=l?0:n.lastTs?Math.min(.05,(t-n.lastTs)/1e3):1/60;n.lastTs=t,n.t+=f;const p=n.t;if(!l)if(a.analyser)wi(a,ht);else{const q=i.getLevel?Do(i.getLevel()):0;ht.level=q,ht.bands[0]=q,ht.bands[1]=q*(.72+.28*Math.sin(p*9.1)),ht.bands[2]=q*(.6+.4*Math.sin(p*13.7+2))}const b=io(ht.level,o.threshold);n.level=Ma(n.level,b,f,o.attack,o.release);for(let q=0;q<3;q++){const ie=io(ht.bands[q],o.threshold*.6);n.bands[q]=Ma(n.bands[q],ie,f,o.attack,o.release*1.15)}const c=Bn*o.lobeSpacing;o.processing&&n.scanA<.001&&n.scanT===0&&(n.scanT=Math.max(.05,o.processingDuration)/2);const d=Math.max(.05,o.processingEase);n.scanA=Ma(n.scanA,o.processing?1:0,f,d*.9,d*.8),o.processing?n.scanT+=f:n.scanA<.001&&(n.scanT=0);const m=n.scanA*n.scanA*(3-2*n.scanA),k=s.clientWidth,x=s.clientHeight,W=c/2*o.processingTravel,y=n.scanT/Math.max(.05,o.processingDuration),$=Math.floor(y),X=y-$,M=Math.max(1,o.processingCurve),v=X<.5?.5*Math.pow(2*X,M):1-.5*Math.pow(2-2*X,M),h=o.reducedMotion?0:$%2===0?2*v-1:1-2*v,g=m*W*h,H=1-m*.6,w=1-m*.45,A=1+m*.3*(1-h*h),O=o.reducedMotion?.5:.5+.5*Math.sin(Bo*p/o.breatheDuration),E=n.level+(1-n.level)*o.idle*O,z=Math.max(0,Math.min(1,(m-.25)/.75)),S=z*z*(3-2*z),Y=Math.max(E,o.processingLevel*S),D=.15+.85*Y,P=.5+o.reach*Y,L=(.85+o.spread*Y)*A;o.flow!==0&&!o.reducedMotion&&(n.phase=((n.phase+o.flow*Y*f)%c+c)%c),s.style.setProperty(`--vb-level-${o.id}`,n.level.toFixed(3)),s.style.setProperty(`--vb-cx-${o.id}`,`${g.toFixed(1)}px`),s.style.setProperty(`--vb-mw-${o.id}`,w.toFixed(3));const j=o.bend*Y;s.style.setProperty(`--vb-bh-${o.id}`,`${Math.max(0,j).toFixed(1)}px`);const T=o.bend>0?Math.min(1,j/o.bend):0;s.style.setProperty(`--vb-bendA-${o.id}`,T.toFixed(3));const R={cx:g,w:L,h:P,mw:w,lift:j,strength:T,level:n.level,corner:m},I=k/2+g*L,_=30*o.scale*L,V=No(o.radius,k,x),G=m*o.cornerFollow;s.style.setProperty(`--vb-cy-${o.id}`,`${(-dr(I,k,V,_*1.4)*G).toFixed(1)}px`),n.warp=Ma(n.warp,o.processing?0:1,f,ii,ni);const ae=n.warp,Q=a.displace!=null&&ae<ci;if(Q!==a.warpOff&&(a.warpOff=Q,Q?s.setAttribute("data-voice-warp","off"):s.removeAttribute("data-voice-warp")),k&&x&&(a.ctx||a.displace)){const q=mi(o,R,k,x);(a.displace&&!Q||o.coreLight>0)&&xi(s,o.id,q,k,x),a.filter&&!Q&&li&&$i(a,q,x),a.ctx&&vi(a,R,q)}if(a.displace&&!Q){const q=o.reducedMotion?0:o.distortion*120*o.scale*(.15+.85*Y)*ae;a.displace.scale.baseVal=q,a.noiseShift&&(a.noiseShift.dx.baseVal=8*o.scale*Math.sin(p*.9),a.noiseShift.dy.baseVal=4*o.scale*Math.sin(p*.6+1.3))}s.style.setProperty(`--vb-glow-${o.id}`,D.toFixed(3)),s.style.setProperty(`--vb-h-${o.id}`,P.toFixed(3)),s.style.setProperty(`--vb-w-${o.id}`,L.toFixed(3));for(let q=0;q<Bt.length;q++){const ie=Bt[q],de=ri(ie.x*o.lobeSpacing+n.phase,c),Z=o.bands?.6+.7*n.bands[ie.band]:1;s.style.setProperty(`--vb-x${q}-${o.id}`,`${(de*H).toFixed(1)}px`),s.style.setProperty(`--vb-l${q}-${o.id}`,(Z*oi(de,c)).toFixed(3));const oe=k/2+(g+de*H)*L;s.style.setProperty(`--vb-y${q}-${o.id}`,`${(-dr(oe,k,V,_)*G).toFixed(1)}px`)}const fe=o.staticColors||o.reducedMotion||o.hueRange===0?0:-o.hueRange+2*o.hueRange*yi(p/o.hueDuration);s.style.setProperty(`--vb-hue-${o.id}`,`${fe.toFixed(2)}deg`),(r=a.onLevel)==null||r.call(a,n.level),a.paintedConfig=o}))}function Mi(){Pt==null&&(fr=0,Xa=0,Ot=0,Pt=requestAnimationFrame(Io))}function zi(){Fa.size===0&&Pt!=null&&(cancelAnimationFrame(Pt),Pt=null)}function ki(t,e,a,r){const s={el:t,config:e,source:a,onLevel:r,analyser:null,releaseAnalyser:null,time:null,freq:null,canvas:null,ctx:null,haloCanvas:null,haloCtx:null,displace:null,noiseShift:null,filter:null,filterTop:-1,s:Kn(t),paintedConfig:null,cssBlur:null,warpOff:t.hasAttribute("data-voice-warp")};e.distortion>0&&(s.displace=t.querySelector(":scope > svg feDisplacementMap"),s.noiseShift=t.querySelector(":scope > svg feOffset"),s.filter=t.querySelector(":scope > svg filter"));const o=t.querySelector(":scope > [data-voice-beam-band]");if(o){s.canvas=o,s.ctx=o.getContext("2d");const i=t.querySelector(":scope > [data-voice-beam-band-halo]");i&&(s.haloCanvas=i,s.haloCtx=i.getContext("2d"))}if(s.s.lastTs=0,a.stream){const i=Un(a.stream);i&&(s.analyser=i.analyser,s.releaseAnalyser=i.release,s.time=new Float32Array(i.analyser.fftSize),s.freq=new Uint8Array(i.analyser.frequencyBinCount))}return Fa.add(s),Mi(),()=>{var i;Fa.delete(s),(i=s.releaseAnalyser)==null||i.call(s),zi()}}const Si={scale:1,glowSize:1,processingDuration:1.1,processingLevel:.55,processingTravel:1.55,processingCurve:2.1,cornerFollow:.45,strokeOpacity:1,innerOpacity:1,bloomOpacity:1,idle:.18,reach:1.2,spread:1.05,flow:48,bend:60,bandStrength:1.55,bandWidth:2.15,bandPosition:.35,bandCurve:1.75,bandSpread:.87,bandSkew:.12,bandOffset:-27,bandTail:.59,bandTailPosition:.67,bandTailCurve:2.4,bandTailOverflow:15,bandAberration:.89,distortion:.62,distortionDetail:2.3,glowWidth:.65,glowHeight:1.25,lobeSpacing:.85,rangeWidth:.75,rangeHeight:1,softness:1.07,coreSize:1,coreLight:0,coreLightWidth:1,coreLightHeight:1,strokeScale:1,innerScale:1,innerHeight:1,bloomScale:1,bloomHeight:1},Wi={default:{},pill:{scale:.45,glowSize:.95,strokeOpacity:1.2,innerOpacity:.85,reach:1.35,spread:1.1,flow:0,bend:23,bandStrength:1.55,bandWidth:1.85,bandCurve:1.95,bandSpread:.38,bandOffset:-16,bandTail:0,processingTravel:2,cornerFollow:0,distortion:.45,distortionDetail:3,glowWidth:.65,glowHeight:.95,lobeSpacing:.45,rangeWidth:.8,rangeHeight:.7,softness:.88,coreSize:.25,strokeScale:1.25,innerScale:.95,bloomScale:1.05,bloomHeight:2.25},mobile:{scale:1.25,spread:.45,reach:3,flow:60,bend:70,bandWidth:2.4,bandCurve:1.55,bandSpread:.9,bandOffset:-50,bandTail:.62,bandTailPosition:.42,bandTailCurve:2.7,bandTailOverflow:22,processingDuration:1.05,processingLevel:.35,processingTravel:1,cornerFollow:.4,bandStrength:1.8,distortionDetail:2,glowWidth:1.15,glowHeight:2.1,lobeSpacing:1.35,rangeWidth:1.25,rangeHeight:1.2,softness:1.1}},Hi={default:{brightness:1.15},pill:{brightness:1.35,saturation:1.5},mobile:{strength:1,brightness:1.2,saturation:1.5}},Xi={default:{},pill:{},mobile:{strength:1}};function Yi(t="default",e="dark"){return(e==="light"?Xi[t]:void 0)??Hi[t]}const Ai={default:{bandStrength:1.7},pill:{bandStrength:2},mobile:{bandStrength:1.7}};function Oi(t="default",e="dark"){const a=Wi[t],r={};return e==="light"&&(a.reach===void 0&&(r.reach=1.8),a.spread===void 0&&(r.spread=.8),a.coreLight===void 0&&(r.coreLight=1.8)),{...Si,...r,...a,...e==="light"?Ai[t]:void 0}}const za={dark:{core:"255, 255, 255",above:"255, 70, 80",mid:"90, 255, 150",below:"80, 140, 255"},light:{core:"197, 139, 255",above:"255, 122, 182",mid:"126, 196, 255",below:"45, 255, 171"}},Fi=1,Ri=16,Ci=6e4,po=typeof navigator<"u"&&/AppleWebKit/.test(navigator.userAgent)&&!/Chrome\/|Chromium\/|Edg\/|OPR\//.test(navigator.userAgent),ji=(()=>{if(typeof document>"u")return!0;const t=document.createElement("canvas").getContext("2d");return!!t&&typeof t.filter=="string"})();function Ei(){const[t,e]=C.useState(()=>typeof window>"u"||window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");return C.useEffect(()=>{if(typeof window>"u")return;const a=window.matchMedia("(prefers-color-scheme: dark)"),r=s=>e(s.matches?"dark":"light");return a.addEventListener("change",r),()=>a.removeEventListener("change",r)},[]),t}function Pi(){const[t,e]=C.useState(()=>typeof window>"u"||!window.matchMedia?!1:window.matchMedia("(prefers-reduced-motion: reduce)").matches);return C.useEffect(()=>{if(typeof window>"u"||!window.matchMedia)return;const a=window.matchMedia("(prefers-reduced-motion: reduce)"),r=s=>e(s.matches);return a.addEventListener("change",r),()=>a.removeEventListener("change",r)},[]),t}function Ti(t,e){return t==="auto"?e:t}const Li=C.forwardRef(function({children:t,type:e="default",scale:a,stream:r=null,level:s=0,sensitivity:o=3.1,threshold:i=.015,attack:n=.325,release:l=.86,idle:f,breatheDuration:p=5.2,reach:b,spread:c,bands:d=!0,flow:m,processing:k=!1,processingDuration:x,processingLevel:W,processingTravel:y,processingCurve:$,cornerFollow:X,processingEase:M=.6,colorVariant:v="colorful",colors:h,bandColors:g,theme:H="dark",staticColors:w=!1,hueRange:A,hueDuration:O,active:E=!0,paused:z=!1,borderRadius:S,brightness:Y,saturation:D,glowSize:P,strokeOpacity:L,innerOpacity:j,bloomOpacity:T,bend:R,bandStrength:I,bandWidth:_,bandPosition:V,bandCurve:G,bandSpread:ae,bandSkew:Q,bandOffset:fe,bandTail:q,bandTailPosition:ie,bandTailCurve:de,bandTailOverflow:Z,bandAberration:oe,distortion:me,distortionDetail:he,glowWidth:ue,glowHeight:le,lobeSpacing:Pe,rangeWidth:Te,rangeHeight:Le,softness:Ae,coreSize:ye,coreLight:xe,coreLightWidth:We,coreLightHeight:Oe,strokeScale:ee,innerScale:re,innerHeight:be,bloomScale:$e,bloomHeight:Ge,strength:Ve,className:Fe,style:Dt,css:fa,onLevel:Nt,onActivate:kt,onDeactivate:ot,onAnimationEnd:St,...Ea},Be){const De=C.useId().replace(/:/g,"-"),F=Ei(),B=Ti(H,F),U=h?h.join("|"):"",J=g?[g.core,g.above,g.mid,g.below].join("|"):"",N=Oi(e,B),te=Math.max(.05,a??N.scale),ge=P??N.glowSize,Wt=L??N.strokeOpacity,Re=j??N.innerOpacity,Ce=T??N.bloomOpacity,Ue=x??N.processingDuration,Ht=W??N.processingLevel,Xt=y??N.processingTravel,st=$??N.processingCurve,nt=X??N.cornerFollow,it=f??N.idle,Ke=b??N.reach,_e=c??N.spread,ct=(m??N.flow)*te,da=(R??N.bend)*te,Ne=I??N.bandStrength,ne=(_??N.bandWidth)*te,we=V??N.bandPosition,Me=G??N.bandCurve,It=ae??N.bandSpread,qt=Q??N.bandSkew,Gt=(fe??N.bandOffset)*te,Vt=q??N.bandTail,Ut=ie??N.bandTailPosition,pa=de??N.bandTailCurve,ba=(Z??N.bandTailOverflow)*te,ha=oe??N.bandAberration,Jo=me??N.distortion,yr=(he??N.distortionDetail)/te,wr=(ue??N.glowWidth)*te,Mr=(le??N.glowHeight)*te,zr=(Pe??N.lobeSpacing)*te,ua=(Te??N.rangeWidth)*te,ga=(Le??N.rangeHeight)*te,kr=Ae??N.softness,Sr=(ye??N.coreSize)*te,Kt=Math.max(0,Math.min(3,xe??N.coreLight)),Wr=We??N.coreLightWidth,Hr=Oe??N.coreLightHeight,Xr=ee??N.strokeScale,Yr=re??N.innerScale,Ar=be??N.innerHeight,Or=$e??N.bloomScale,Fr=Ge??N.bloomHeight,Rr=Pi(),_t=C.useRef(null),[lt,Cr]=C.useState(E),[Je,jr]=C.useState(!1),[Pa,Zo]=C.useState(!0),[Qo,es]=C.useState(null),[ts,as]=C.useState(0);C.useEffect(()=>{if(!po)return;const ce=_t.current;if(!ce)return;const pe=()=>as(ce.clientWidth*ce.clientHeight);if(pe(),typeof ResizeObserver>"u")return;const je=new ResizeObserver(pe);return je.observe(ce),()=>je.disconnect()},[]);const Yt=po&&ts>Ci?0:Jo;C.useEffect(()=>{if(S!=null)return;const ce=_t.current;if(!ce)return;const pe=()=>{const xa=ce.firstElementChild;if(!xa)return;const is=getComputedStyle(xa),Ba=parseFloat(is.borderTopLeftRadius);!isNaN(Ba)&&Ba>0&&es(Ba)};pe();const je=new MutationObserver(pe);return je.observe(ce,{childList:!0,subtree:!1}),()=>je.disconnect()},[S,t]),C.useEffect(()=>{E&&!lt&&!Je?Cr(!0):!E&&lt&&!Je&&jr(!0)},[E,lt,Je]),C.useEffect(()=>{const ce=_t.current;if(!ce||typeof IntersectionObserver>"u")return;const pe=new IntersectionObserver(je=>{for(const xa of je)Zo(xa.isIntersecting)},{rootMargin:"256px"});return pe.observe(ce),()=>pe.disconnect()},[]);const rs=C.useCallback(ce=>{const pe=ce.animationName;pe.includes("fade-out")?(Cr(!1),jr(!1),ot==null||ot()):pe.includes("fade-in")&&(kt==null||kt()),St==null||St(ce)},[kt,ot,St]),He=Tn[B],ma=S??Qo??Ri,Ta=Yi(e,B),os=Ve??Ta.strength??He.strength??1,Er=A??He.hueRange??24,Pr=O??He.hueDuration??12,Tr=Y??Ta.brightness??He.brightness,Lr=D??Ta.saturation??He.saturation,Br=C.useMemo(()=>qn({id:De,borderRadius:ma,borderWidth:Fi,strokeOpacity:He.strokeOpacity*Wt,innerOpacity:He.innerOpacity*Re,bloomOpacity:He.bloomOpacity*Ce,innerShadow:He.innerShadow,colorVariant:v,colors:h,brightness:Tr,saturation:Lr,theme:B,hueBase:He.hueBase??0,glowSize:ge*te,glowWidth:wr,glowHeight:Mr,strokeScale:Xr,innerScale:Yr,innerHeight:Ar,bloomScale:Or,bloomHeight:Fr,coreSize:Sr,coreLight:Kt,coreLightWidth:Wr,coreLightHeight:Hr,rangeWidth:ua,rangeHeight:ga,softness:kr,distortion:Yt>0,scale:te}),[De,ma,He,v,U,Tr,Lr,B,N,ge,Wt,Re,Ce,te,wr,Mr,Xr,Yr,Ar,Or,Fr,Sr,Kt,Wr,Hr,ua,ga,kr,Yt>0]),Dr=C.useMemo(()=>({id:De,sensitivity:Math.max(0,o),threshold:Math.max(0,Math.min(.95,i)),attack:Math.max(0,n),release:Math.max(0,l),idle:Math.max(0,Math.min(1,it)),breatheDuration:Math.max(.2,p),reach:Math.max(0,Ke),spread:Math.max(0,_e),bands:d,flow:ct,lobeSpacing:Math.max(.1,zr),bend:Math.max(0,da),bandStrength:Math.max(0,Ne),bandWidth:Math.max(0,ne),bandPosition:Math.max(0,we),bandCurve:Math.max(.3,Me),bandSpread:Math.max(.05,It),bandSkew:Math.max(-.9,Math.min(.9,qt)),bandOffset:Gt,bandTail:Math.max(0,Math.min(1.5,Vt)),bandTailPosition:Math.max(0,Math.min(.98,Ut)),bandTailCurve:Math.max(.5,pa),bandTailOverflow:Math.max(0,ba),bandAberration:Math.max(0,Math.min(1,ha)),rangeWidth:ua,rangeHeight:ga,theme:B,bandColors:{core:(g==null?void 0:g.core)&&ya(g.core)||za[B].core,above:(g==null?void 0:g.above)&&ya(g.above)||za[B].above,mid:(g==null?void 0:g.mid)&&ya(g.mid)||za[B].mid,below:(g==null?void 0:g.below)&&ya(g.below)||za[B].below},distortion:Math.max(0,Math.min(1,Yt)),coreLight:Kt,scale:te,radius:ma,processing:k,processingDuration:Math.max(.05,Ue),processingLevel:Math.max(0,Math.min(1,Ht)),processingEase:Math.max(.05,M),processingTravel:Math.max(0,Xt),processingCurve:Math.max(1,st),cornerFollow:Math.max(0,Math.min(1,nt)),hueRange:Math.max(0,Er),hueDuration:Math.max(.5,Pr),staticColors:v==="mono"?!0:w,reducedMotion:Rr,paused:z}),[De,o,i,n,l,it,p,Ke,_e,d,ct,zr,da,Ne,ne,we,Me,It,qt,Gt,Vt,Ut,pa,ba,ha,ua,ga,B,J,Yt,Kt,te,ma,k,Ue,Ht,M,Xt,st,nt,Er,Pr,w,v,Rr,z]),Nr=C.useRef(s);Nr.current=s;const La=C.useRef(Nt);La.current=Nt,C.useEffect(()=>{if(!(lt||Je)||!Pa)return;const ce=_t.current;return ce?ki(ce,Dr,{stream:r,getLevel:()=>{const pe=Nr.current;return typeof pe=="function"?pe():pe}},pe=>{var je;return(je=La.current)==null?void 0:je.call(La,pe)}):void 0},[Dr,r,lt,Je,Pa]);const ss=C.useCallback(ce=>{_t.current=ce,typeof Be=="function"?Be(ce):Be&&(Be.current=ce)},[Be]),ns={...Dt??{},"--voice-strength":Math.max(0,Math.min(1,os))};return u.jsxs(u.Fragment,{children:[u.jsx("style",{children:fa?`${Br}
${fa.split("{id}").join(De)}`:Br}),u.jsxs("div",{...Ea,ref:ss,"data-voice-beam":De,"data-voice-type":e,"data-voice-halfres":"","data-active":lt&&!Je?"":void 0,"data-fading":Je?"":void 0,"data-paused":lt&&!Je&&(!Pa||z)?"":void 0,"data-listening":r?"":void 0,"data-processing":k?"":void 0,className:Fe,style:ns,onAnimationEnd:rs,children:[t,u.jsx("div",{"data-voice-beam-bloom":!0}),Yt>0&&u.jsxs(u.Fragment,{children:[u.jsx("div",{"data-voice-beam-warp":"inner"}),u.jsx("div",{"data-voice-beam-warp":"bloom"})]}),!ji&&u.jsx("canvas",{"data-voice-beam-band-halo":!0,"aria-hidden":"true"}),u.jsx("canvas",{"data-voice-beam-band":!0,"aria-hidden":"true"}),Kt>0&&u.jsx("div",{"data-voice-beam-core":!0,children:u.jsx("div",{})}),Yt>0&&u.jsx("svg",{"aria-hidden":"true",width:"0",height:"0",style:{position:"absolute",pointerEvents:"none"},children:u.jsxs("filter",{id:`vb-distort-${De}`,x:"-20%",y:"-20%",width:"140%",height:"140%",colorInterpolationFilters:"sRGB",children:[u.jsx("feTurbulence",{type:"fractalNoise",baseFrequency:`${(.012*yr).toFixed(4)} ${(.05*yr).toFixed(4)}`,numOctaves:2,seed:7,result:"noise"}),u.jsx("feOffset",{in:"noise",dx:"0",dy:"0",result:"moved"}),u.jsx("feColorMatrix",{in:"moved",type:"matrix",values:"1 0 0 0 0  0 0 0 0 0.5  0 0 0 0 0  0 0 0 0 1",result:"map"}),u.jsx("feDisplacementMap",{in:"SourceGraphic",in2:"map",scale:0,xChannelSelector:"R",yChannelSelector:"G"})]})})]})]})});var qo=C.createContext(null);function xr(){const t=C.useContext(qo);if(!t)throw new Error("<Gooey.Item> must be rendered inside a <Gooey> group.");return t}var Bi="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 60 -29.5";function Di({i:t,s:e}){const a=[];let r="bin";return e.spread!==0&&(a.push(u.jsx("feMorphology",{in:r,operator:e.spread>0?"erode":"dilate",radius:Math.abs(e.spread),result:`s${t}-er`},"er")),r=`s${t}-er`),(e.x!==0||e.y!==0)&&(a.push(u.jsx("feOffset",{in:r,dx:e.x,dy:e.y,result:`s${t}-o`},"o")),r=`s${t}-o`),e.blur>0&&(a.push(u.jsx("feGaussianBlur",{in:r,stdDeviation:e.blur/2,result:`s${t}-b`},"b")),r=`s${t}-b`),a.push(u.jsx("feComposite",{in:"bin",in2:r,operator:"out",result:`s${t}-band`},"band"),u.jsx("feFlood",{floodColor:e.color,result:`s${t}-c`},"c"),u.jsx("feComposite",{in:`s${t}-c`,in2:`s${t}-band`,operator:"in",result:`s${t}`},"f")),u.jsx(u.Fragment,{children:a})}function Ni({i:t,s:e}){const a=[];let r="shape";return e.spread!==0&&(a.push(u.jsx("feMorphology",{in:"bin",operator:e.spread>0?"dilate":"erode",radius:Math.abs(e.spread),result:`s${t}-sp`},"sp")),r=`s${t}-sp`),e.blur>0&&(a.push(u.jsx("feGaussianBlur",{in:r,stdDeviation:e.blur/2,result:`s${t}-b`},"b")),r=`s${t}-b`),(e.x!==0||e.y!==0)&&(a.push(u.jsx("feOffset",{in:r,dx:e.x,dy:e.y,result:`s${t}-o`},"o")),r=`s${t}-o`),a.push(u.jsx("feFlood",{floodColor:e.color,result:`s${t}-c`},"c"),u.jsx("feComposite",{in:`s${t}-c`,in2:r,operator:"in",result:`s${t}`},"f")),u.jsx(u.Fragment,{children:a})}function Ii({blur:t,contrast:e,shadows:a,waviness:r=0,wavinessFreq:s=.018}){const o=r>0,i=Math.round((.5-e*(5/12))*100)/100;return u.jsxs(u.Fragment,{children:[u.jsx("feGaussianBlur",{in:"SourceGraphic",stdDeviation:t,result:"blur"}),u.jsx("feColorMatrix",{in:"blur",type:"matrix",values:`1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 ${e} ${i}`,result:"goo"}),u.jsx("feComposite",{in:"SourceGraphic",in2:"goo",operator:"atop",result:o?"shape-raw":"shape"}),o&&u.jsxs(u.Fragment,{children:[u.jsx("feTurbulence",{type:"fractalNoise",baseFrequency:s,numOctaves:2,seed:"7",result:"wave-noise"}),u.jsx("feDisplacementMap",{in:"shape-raw",in2:"wave-noise",scale:r*2,xChannelSelector:"R",yChannelSelector:"G",result:"shape"})]}),a.some(n=>n.inset||n.spread!==0)&&u.jsx("feColorMatrix",{in:"shape",type:"matrix",values:Bi,result:"bin"}),a.map((n,l)=>n.inset?u.jsx(Di,{i:l,s:n},l):u.jsx(Ni,{i:l,s:n},l)),a.length>0&&u.jsxs("feMerge",{children:[a.map((n,l)=>n.inset?-1:l).filter(n=>n>=0).reverse().map(n=>u.jsx("feMergeNode",{in:`s${n}`},n)),u.jsx("feMergeNode",{in:"shape"}),a.map((n,l)=>n.inset?u.jsx("feMergeNode",{in:`s${l}`},l):null)]})]})}var qi={blur:7,contrast:40,reach:.8,fade:17,warp:0,mix:1,mixBlur:8,gravity:1.9,waviness:12};function Gi(){const t=new Set,e=new Set,a=()=>e.forEach(r=>r());return{register(r){return t.add(r),a(),()=>{t.delete(r),a()}},subscribe(r){return e.add(r),()=>e.delete(r)},entries:()=>[...t]}}function bo(t,e){const a=t.getBoundingClientRect(),r=e.getBoundingClientRect(),s=getComputedStyle(e),o=parseFloat(s.borderTopLeftRadius)||0;return{x:r.left-a.left,y:r.top-a.top,w:r.width,h:r.height,r:Math.min(o,r.width/2,r.height/2)}}var ho=t=>`${Math.round(t.x*2)},${Math.round(t.y*2)},${Math.round(t.w)},${Math.round(t.h)},${Math.round(t.r)}`;function Vi(t,e=14){const[a,r]=C.useState(t),s=C.useRef({value:t,target:t,raf:0,last:0});return C.useEffect(()=>{const o=s.current;if(o.target=t,o.raf)return;o.last=performance.now();const i=n=>{const l=Math.min(.05,(n-o.last)/1e3);o.last=n;const f=1-Math.exp(-e*l);o.value+=(o.target-o.value)*f,Math.abs(o.value-o.target)<.004&&(o.value=o.target),r(o.value),o.raf=o.value===o.target?0:requestAnimationFrame(i)};return o.raf=requestAnimationFrame(i),()=>{o.raf&&cancelAnimationFrame(o.raf),o.raf=0}},[t,e]),a}function Ui({a:t,b:e,srcA:a,srcB:r,opts:s,width:o,height:i}){const n=`lgm-${C.useId().replace(/[^a-zA-Z0-9_-]/g,"")}`,{blur:l,contrast:f,reach:p,fade:b,warp:c,mix:d,mixBlur:m,gravity:k,waviness:x}=s,W={x:t.x+t.w/2,y:t.y+t.h/2},y={x:e.x+e.w/2,y:e.y+e.h/2},$=Math.max(0,Math.hypot(Math.max(Math.abs(W.x-y.x)-(t.w+e.w)/2,0),Math.max(Math.abs(W.y-y.y)-(t.h+e.h)/2,0))),X=Math.max(0,Math.min(1,1-$/Math.max(8,l*2.6))),M=X*X*(3-2*X),v=Vi(M),h=Math.round((.5-f*(5/12))*100)/100,g=Math.hypot(t.w,t.h)/2*p*v,H=Math.hypot(e.w,e.h)/2*p*v,w={x:(W.x+y.x)/2,y:(W.y+y.y)/2},A=y.x-W.x,O=y.y-W.y,E=Math.max(.001,Math.hypot(A,O)),z=-O/E,S=A/E,Y=Math.max(0,(t.w+e.w)/2-Math.abs(A)),D=Math.max(0,(t.h+e.h)/2-Math.abs(O)),P=.5*(Y*Math.abs(z)+D*Math.abs(S))*v,L=Math.round(Math.atan2(S,z)*180/Math.PI),j=Math.round(d*v*100)/100,T=Math.round((2+(l-2)*v)*10)/10,R=Math.round(c*v*10)/10,I=Math.round(T*2.5*10)/10,_=Math.round((.4+(2+l*.8)*v)*10)/10,V=`translate(${t.x}, ${t.y})`,G=`translate(${e.x}, ${e.y})`;return u.jsxs("svg",{"aria-hidden":"true",focusable:"false","data-gooey-imagemelt":"",width:o,height:i,viewBox:`0 0 ${o} ${i}`,style:{position:"absolute",inset:0,overflow:"visible",pointerEvents:"none"},children:[u.jsxs("defs",{children:[u.jsx("pattern",{id:`${n}-pa`,patternUnits:"userSpaceOnUse",width:t.w,height:t.h,children:u.jsx("image",{href:a,width:t.w,height:t.h,preserveAspectRatio:"xMidYMid slice"})}),u.jsx("pattern",{id:`${n}-pb`,patternUnits:"userSpaceOnUse",width:e.w,height:e.h,children:u.jsx("image",{href:r,width:e.w,height:e.h,preserveAspectRatio:"xMidYMid slice"})}),u.jsxs("filter",{id:`${n}-goo`,x:"-15%",y:"-15%",width:"130%",height:"130%",colorInterpolationFilters:"sRGB",children:[u.jsx("feGaussianBlur",{in:"SourceGraphic",stdDeviation:T,result:"b"}),u.jsx("feColorMatrix",{in:"b",type:"matrix",values:`1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 ${f} ${h}`,result:"goo"}),u.jsx("feGaussianBlur",{in:"SourceGraphic",stdDeviation:I,result:"bc"}),u.jsx("feComposite",{in:"bc",in2:"goo",operator:"in",result:"mix"}),u.jsx("feTurbulence",{type:"fractalNoise",baseFrequency:(2+x*1.2)/1e3,numOctaves:"2",seed:"4",result:"wn"}),u.jsx("feDisplacementMap",{in:"mix",in2:"wn",scale:R,xChannelSelector:"R",yChannelSelector:"G",result:"warped"}),u.jsx("feComposite",{in:"warped",in2:"warped",operator:"over",result:"s1"}),u.jsx("feComposite",{in:"s1",in2:"s1",operator:"over",result:"s2"}),u.jsx("feComposite",{in:"s2",in2:"s2",operator:"over",result:"solid"}),u.jsx("feGaussianBlur",{in:"solid",stdDeviation:"0.6"})]}),u.jsx("filter",{id:`${n}-soft`,x:"-60%",y:"-60%",width:"220%",height:"220%",children:u.jsx("feGaussianBlur",{stdDeviation:b})}),j>.01&&u.jsxs("filter",{id:`${n}-marble`,x:"-25%",y:"-25%",width:"150%",height:"150%",colorInterpolationFilters:"sRGB",children:[u.jsx("feGaussianBlur",{in:"SourceGraphic",stdDeviation:m,result:"c"}),u.jsx("feTurbulence",{type:"fractalNoise",baseFrequency:"0.011",numOctaves:"2",seed:"5",result:"n1"}),u.jsx("feDisplacementMap",{in:"c",in2:"n1",scale:j*90,xChannelSelector:"R",yChannelSelector:"G",result:"d1"}),u.jsx("feTurbulence",{type:"fractalNoise",baseFrequency:"0.019",numOctaves:"2",seed:"11",result:"n2"}),u.jsx("feDisplacementMap",{in:"d1",in2:"n2",scale:j*50,xChannelSelector:"R",yChannelSelector:"G",result:"d2"}),u.jsx("feComposite",{in:"d2",in2:"d2",operator:"over",result:"m1"}),u.jsx("feComposite",{in:"m1",in2:"m1",operator:"over",result:"m2"}),u.jsx("feGaussianBlur",{in:"m2",stdDeviation:"0.6",result:"marble"}),u.jsx("feGaussianBlur",{in:"SourceGraphic",stdDeviation:T,result:"mb"}),u.jsx("feColorMatrix",{in:"mb",type:"matrix",values:`1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 ${f} ${h}`,result:"mg"}),u.jsx("feTurbulence",{type:"fractalNoise",baseFrequency:(2+x*1.2)/1e3,numOctaves:"2",seed:"4",result:"mwn"}),u.jsx("feDisplacementMap",{in:"mg",in2:"mwn",scale:R,xChannelSelector:"R",yChannelSelector:"G",result:"mshape"}),u.jsx("feComposite",{in:"marble",in2:"mshape",operator:"in"})]}),j>.01&&u.jsx("mask",{id:`${n}-marblemask`,maskUnits:"userSpaceOnUse",x:"0",y:"0",width:o,height:i,children:u.jsx("g",{filter:`url(#${n}-soft)`,children:u.jsx("ellipse",{cx:w.x,cy:w.y,rx:(g+H)/2+P,ry:(g+H)/2*k,transform:`rotate(${L}, ${w.x}, ${w.y})`,fill:"#fff"})})}),u.jsx("filter",{id:`${n}-edge`,x:"-40%",y:"-40%",width:"180%",height:"180%",children:u.jsx("feGaussianBlur",{stdDeviation:_})}),u.jsxs("mask",{id:`${n}-ma`,maskUnits:"userSpaceOnUse",x:"0",y:"0",width:o,height:i,children:[u.jsx("g",{filter:`url(#${n}-edge)`,children:u.jsx("g",{transform:V,children:u.jsx("rect",{width:t.w,height:t.h,rx:t.r,fill:"#fff"})})}),u.jsx("g",{filter:`url(#${n}-soft)`,children:u.jsx("ellipse",{cx:w.x,cy:w.y,rx:H+P,ry:H,transform:`rotate(${L}, ${w.x}, ${w.y})`,fill:"#000"})})]}),u.jsxs("mask",{id:`${n}-mb`,maskUnits:"userSpaceOnUse",x:"0",y:"0",width:o,height:i,children:[u.jsx("g",{filter:`url(#${n}-edge)`,children:u.jsx("g",{transform:G,children:u.jsx("rect",{width:e.w,height:e.h,rx:e.r,fill:"#fff"})})}),u.jsx("g",{filter:`url(#${n}-soft)`,children:u.jsx("ellipse",{cx:w.x,cy:w.y,rx:g+P,ry:g,transform:`rotate(${L}, ${w.x}, ${w.y})`,fill:"#000"})})]})]}),u.jsxs("g",{filter:`url(#${n}-goo)`,children:[u.jsx("g",{transform:V,children:u.jsx("rect",{width:t.w,height:t.h,rx:t.r,fill:`url(#${n}-pa)`})}),u.jsx("g",{transform:G,children:u.jsx("rect",{width:e.w,height:e.h,rx:e.r,fill:`url(#${n}-pb)`})})]}),j>.01&&u.jsx("g",{mask:`url(#${n}-marblemask)`,children:u.jsxs("g",{filter:`url(#${n}-marble)`,children:[u.jsx("g",{transform:V,children:u.jsx("rect",{width:t.w,height:t.h,rx:t.r,fill:`url(#${n}-pa)`})}),u.jsx("g",{transform:G,children:u.jsx("rect",{width:e.w,height:e.h,rx:e.r,fill:`url(#${n}-pb)`})})]})}),u.jsx("g",{mask:`url(#${n}-ma)`,children:u.jsx("g",{transform:V,children:u.jsx("rect",{width:t.w,height:t.h,rx:t.r,fill:`url(#${n}-pa)`})})}),u.jsx("g",{mask:`url(#${n}-mb)`,children:u.jsx("g",{transform:G,children:u.jsx("rect",{width:e.w,height:e.h,rx:e.r,fill:`url(#${n}-pb)`})})})]})}function Ki({registry:t}){var b,c;const{getGroup:e}=xr(),[,a]=C.useState(0),[r,s]=C.useState(null),o=C.useRef("");C.useEffect(()=>t.subscribe(()=>a(d=>d+1)),[t]);const i=t.entries().slice(0,2),n=i.length===2;if(C.useEffect(()=>{if(!n){s(null),o.current="";return}let d=0;const m=()=>{const k=e();if(k){const x=bo(k,i[0].el),W=bo(k,i[1].el),y=ho(x)+"|"+ho(W);y!==o.current&&(o.current=y,s({a:x,b:W}))}d=requestAnimationFrame(m)};return d=requestAnimationFrame(m),()=>cancelAnimationFrame(d)},[n,(b=i[0])==null?void 0:b.el,(c=i[1])==null?void 0:c.el,e]),!n||!r)return null;const l=e(),f=(l==null?void 0:l.offsetWidth)??0,p=(l==null?void 0:l.offsetHeight)??0;return u.jsx(Ui,{a:r.a,b:r.b,srcA:i[0].src,srcB:i[1].src,opts:i[0].opts,width:f,height:p})}function _i({src:t,opts:e,registry:a,children:r}){const s=C.useRef(null);return C.useEffect(()=>{var p;const o=s.current,i=o==null?void 0:o.firstElementChild;if(!i)return;const n=t??((p=i.querySelector("img"))==null?void 0:p.src)??i.src;if(!n)return;const l=i.style.opacity;i.style.opacity="0";const f=a.register({el:i,src:n,opts:e});return()=>{i.style.opacity=l,f()}},[t,e,a]),u.jsx("span",{ref:s,style:{display:"contents"},children:r})}var Ra=typeof window<"u"?C.useLayoutEffect:C.useEffect;function Ji(){const[t,e]=C.useState(!1);return C.useEffect(()=>{const a=window.matchMedia("(prefers-reduced-motion: reduce)");e(a.matches);const r=s=>e(s.matches);return a.addEventListener("change",r),()=>a.removeEventListener("change",r)},[]),t}function Zi(t,e){let a=0,r=0,s=t;for(;s&&s!==e&&e.contains(s);)a+=s.offsetLeft,r+=s.offsetTop,s=s.offsetParent;return{x:a,y:r}}function ea(t,e,a){const r=getComputedStyle(t),s=o=>{const i=o.split(" ")[0];return i.endsWith("%")?(parseFloat(i)||0)/100*Math.min(e,a):parseFloat(i)||0};return[s(r.borderTopLeftRadius),s(r.borderTopRightRadius),s(r.borderBottomRightRadius),s(r.borderBottomLeftRadius)]}function Go(t){return typeof t=="number"?[t,t,t,t]:t}function Qi(t,e,a,r,s){let[o,i,n,l]=s.map(p=>Math.max(0,p));const f=Math.min(1,a/Math.max(1e-6,o+i),a/Math.max(1e-6,l+n),r/Math.max(1e-6,o+l),r/Math.max(1e-6,i+n));return o*=f,i*=f,n*=f,l*=f,`M ${t+o} ${e} H ${t+a-i} A ${i} ${i} 0 0 1 ${t+a} ${e+i} V ${e+r-n} A ${n} ${n} 0 0 1 ${t+a-n} ${e+r} H ${t+l} A ${l} ${l} 0 0 1 ${t} ${e+r-l} V ${e+o} A ${o} ${o} 0 0 1 ${t+o} ${e} Z`}var ke={massStiffness:320,massDamping:17,sizeStiffness:170,sizeDamping:11.5,radiusStiffness:900,radiusDamping:60,contentBlur:7,roundness:1,cornerDuration:460,cornerDelay:0,cornerEase:"cubic-bezier(0.3, 1.05, 0.4, 1)",anticipation:90,travel:32},uo=new Map;function Vo(t){let e=uo.get(t);if(e)return e;const a=/cubic-bezier\(([^)]+)\)/.exec(t);if(a){const[r,s,o,i]=a[1].split(",").map(Number);e=n=>{if(n<=0)return 0;if(n>=1)return 1;let l=0,f=1;for(let b=0;b<24;b++){const c=(l+f)/2;3*c*(1-c)*(1-c)*r+3*c*c*(1-c)*o+c**3<n?l=c:f=c}const p=(l+f)/2;return 3*p*(1-p)*(1-p)*s+3*p*p*(1-p)*i+p**3}}else t==="ease-in-out"?e=Vo("cubic-bezier(0.42, 0, 0.58, 1)"):e=r=>Math.min(1,Math.max(0,r));return uo.set(t,e),e}var et={stiffness:380,damping:18,stretch:.18,tail:.46,force:.5,bend:0,bendX:0},e0=3;function go(t){return Math.max(0,t.cornerDelay)+Math.max(1,t.cornerDuration)}function ka(t,e,a){return Math.max(0,Math.min(t,Math.min(e,a)/2))}function t0(t,e,a,r,s,o){const i=r*(a-t)-s*e,n=e+i*o;return[t+n*o,n]}function Ie(t,e,a,r,s,o){let i=Math.max(1,Math.ceil(o*60));const n=o/i;let l=t,f=e;for(;i-- >0;){const p=t0(l,f,a,r,s,n);l=p[0],f=p[1]}return[l,f]}function se(t,e){return Math.round(t/e)*e}var a0="http://www.w3.org/2000/svg",mo=0;function Zt(t){const e=Math.min(1,Math.max(0,t));return e*e*(3-2*e)}function K(t,e){const a=document.createElementNS(a0,t);for(const[r,s]of Object.entries(e))a.setAttribute(r,s);return a}function r0(t){try{if(!t.complete||!t.naturalWidth)return null;const e=Math.max(2,Math.min(t.naturalWidth,Math.round((t.offsetWidth||40)*3))),a=Math.max(2,Math.min(t.naturalHeight,Math.round((t.offsetHeight||40)*3)));if(t.naturalWidth<=e*1.5)return null;const r=document.createElement("canvas");r.width=e,r.height=a;const s=r.getContext("2d");if(!s)return null;const o=Math.max(e/t.naturalWidth,a/t.naturalHeight),i=e/o,n=a/o;return s.drawImage(t,(t.naturalWidth-i)/2,(t.naturalHeight-n)/2,i,n,0,0,e,a),r.toDataURL()}catch{return null}}var o0=class{constructor(t){this.getGroup=t,this.gooBlur=6,this.items=new Set,this.awake=!1,this.clean=0,this.raf=0,this.sourcesReady=!1,this.mo=null,this.interval=null,this.removeListeners=[],this.wake=()=>{this.clean=0,!(this.awake||this.items.size===0)&&(this.awake=!0,this.raf=requestAnimationFrame(this.loop))},this.lastNow=0,this.frameEma=17,this.loop=e=>{if(this.items.size===0){this.awake=!1,this.lastNow=0;return}const a=this.lastNow?Math.min(.25,Math.max(1/240,(e-this.lastNow)/1e3)):1/60;if(this.lastNow&&(this.frameEma+=(Math.min(e-this.lastNow,80)-this.frameEma)*.12),this.lastNow=e,this.measureAll(a)?this.clean=0:this.clean++,this.clean>30){this.awake=!1,this.lastNow=0;return}this.raf=requestAnimationFrame(this.loop)}}add(t){var a,r,s,o,i;const e={...t,baseW:t.target.offsetWidth||1,baseH:t.target.offsetHeight||1,radiusPx:this.resolveRadius(t),last:null,frame:null,lastBlend:null,melt:null,sim:null,motionEnv:0,tPrev:null,tvx:0,tvy:0,lead01:0,cornerT0:0,lastTargetMoveT:0,lastTargetSize:null,morphActive:!1,round01:0,tailEl:null,tailMidA:null,tailMidB:null,tailPhase:0,bendCur:0,bendCurX:0,bendPathEl:null,lastBendD:null,lastBendVars:null,tailX:0,tailY:0,tailVx:0,tailVy:0,tailR:0,contentBlurred:!1,lastPaint:null,lastTail:null,lastBi:t.blobInset??0,biSmooth:null,meltFade:0,meltRel:null,meltOp:1,meltPhase:0,meltPrev:null,meltGeom:null,meltWroteAt:0,meltAxis:null,meltHostLast:null,ro:new ResizeObserver(()=>{e.baseW=t.target.offsetWidth||1,e.baseH=t.target.offsetHeight||1,e.radiusPx=this.resolveRadius(t),this.syncMelt(e),this.wake()})};if(e.ro.observe(t.target),this.items.add(e),this.refreshMelt(e),(a=t.dynamics)!=null&&a.move){const n=K("circle",{cx:"0",cy:"0",r:"0"}),l=K("circle",{cx:"0",cy:"0",r:"0"}),f=K("circle",{cx:"0",cy:"0",r:"0"});(r=t.blob.parentNode)==null||r.insertBefore(n,t.blob),(s=t.blob.parentNode)==null||s.insertBefore(l,t.blob),(o=t.blob.parentNode)==null||o.insertBefore(f,t.blob),e.tailEl=n,e.tailMidA=l,e.tailMidB=f;const p=K("path",{d:""});(i=t.blob.parentNode)==null||i.insertBefore(p,t.blob),e.bendPathEl=p}return this.ensureSources(),this.measureAll(),this.wake(),()=>{var n,l,f,p;e.ro.disconnect(),this.items.delete(e),this.clearBlend(e),e.contentBlurred&&e.target.style.removeProperty("filter"),(n=e.tailEl)==null||n.remove(),(l=e.tailMidA)==null||l.remove(),(f=e.tailMidB)==null||f.remove(),(p=e.bendPathEl)==null||p.remove()}}dispose(){var t;cancelAnimationFrame(this.raf),(t=this.mo)==null||t.disconnect(),this.removeListeners.forEach(e=>e()),this.removeListeners=[],this.interval&&clearInterval(this.interval),this.items.forEach(e=>e.ro.disconnect()),this.items.clear(),this.awake=!1,this.sourcesReady=!1}resolveRadius(t){return t.radius!=null?t.radius:ea(t.target,t.target.offsetWidth,t.target.offsetHeight)[0]}syncMelt(t){if(!t.blend)return;const e=t.melt,a=t.target,r=a instanceof HTMLImageElement?[a]:Array.from(a.querySelectorAll("img"));if(!(!!e&&e.entries.length===r.length&&e.entries.every((o,i)=>o.el===r[i]))){this.refreshMelt(t);return}for(const o of e.entries)o.radiusPx=ea(o.el,o.el.offsetWidth,o.el.offsetHeight)[0],o.lastGeom=null}refreshMelt(t){const e=t.blend;if(!e)return;const a=e.host;for(;a.firstChild;)a.removeChild(a.firstChild);const r=t.target,s=r instanceof HTMLImageElement?[r]:Array.from(r.querySelectorAll("img")),o=`gooey-melt-${++mo}`,i=String(mo*7%100),n=e.zone??this.gooBlur*2.2+4,l=Math.max(.2,e.warpFreq??1),f=Math.min(.3,Math.max(.01,l/(n*1.1))).toFixed(4),p=String(Math.max(1,Math.round(e.detail??2))),b=e.warpStyle??"fractalNoise",c=K("defs",{}),d=K("radialGradient",{id:`${o}-g`});d.append(K("stop",{offset:"0%","stop-color":"#fff"}),K("stop",{offset:"55%","stop-color":"#fff"}),K("stop",{offset:"78%","stop-color":"#fff","stop-opacity":"0.55"}),K("stop",{offset:"100%","stop-color":"#fff","stop-opacity":"0"})),c.append(d);const m=y=>{const $=K("filter",{id:`${o}-f${y}`,filterUnits:"userSpaceOnUse",x:"0",y:"0",width:"0",height:"0","color-interpolation-filters":"sRGB"}),X=K("feTurbulence",{type:b,baseFrequency:f,numOctaves:p,seed:i,result:"noise0"});$.append(X);const M=K("feOffset",{in:"noise0",dx:"0",dy:"0",result:"noise"}),v=K("feDisplacementMap",{in:"SourceGraphic",in2:"noise",scale:"0",xChannelSelector:"R",yChannelSelector:"G",result:"disp"});$.append(M);const h=K("feGaussianBlur",{in:"disp",stdDeviation:"0",result:"soft"}),g=K("feColorMatrix",{in:"soft",type:"saturate",values:"1.2",result:"col"}),H=K("feColorMatrix",{in:"noise",type:"matrix",values:"0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0 1",result:"erode"}),w=K("feComposite",{in:"col",in2:"erode",operator:"in"});$.append(v,h,g,H,w);const A=K("mask",{id:`${o}-m${y}`,maskUnits:"userSpaceOnUse",x:"-10000",y:"-10000",width:"20000",height:"20000"}),O=K("circle",{cx:"0",cy:"0",r:"0",fill:`url(#${o}-g)`});A.append(O),c.append($,A);const E=K("g",{});E.setAttribute("mask",`url(#${o}-m${y})`),E.setAttribute("opacity","0");const z=K("g",{});z.setAttribute("filter",`url(#${o}-f${y})`);const S=K("g",{});return z.append(S),E.append(z),{filter:$,disp:v,blurEl:h,erode:H,turb:X,noiseOffset:M,circle:O,gl:E,shift:S}},k=Array.from({length:e0},(y,$)=>m(`l${$}`));a.append(c,...k.map(y=>y.gl));let x=null;if((e.seamBlur??1)>0){const y=K("filter",{id:`${o}-fs`,filterUnits:"userSpaceOnUse",x:"0",y:"0",width:"0",height:"0","color-interpolation-filters":"sRGB"}),$=K("feGaussianBlur",{in:"SourceGraphic",stdDeviation:"0"});y.append($);const X=K("mask",{id:`${o}-ms`,maskUnits:"userSpaceOnUse",x:"-10000",y:"-10000",width:"20000",height:"20000"}),M=K("circle",{cx:"0",cy:"0",r:"0",fill:`url(#${o}-g)`});X.append(M),c.append(y,X);const v=K("g",{});v.setAttribute("mask",`url(#${o}-ms)`),v.setAttribute("opacity","0");const h=K("g",{});h.setAttribute("filter",`url(#${o}-fs)`),v.append(h),a.insertBefore(v,c.nextSibling),x={gl:v,filter:y,blurEl:$,circle:M}}const W=s.map((y,$)=>{const X=K("pattern",{id:`${o}-p${$}`,patternUnits:"userSpaceOnUse",x:"0",y:"0",width:"1",height:"1"}),M=K("image",{width:"1",height:"1",preserveAspectRatio:"xMidYMid slice"});M.setAttribute("href",y.currentSrc||y.src),X.append(M),c.append(X);const v=k.map(g=>{const H=K("rect",{x:"0",y:"0",width:"0",height:"0",fill:`url(#${o}-p${$})`});return g.shift.append(H),H});if(x){const g=K("rect",{x:"0",y:"0",width:"0",height:"0",fill:`url(#${o}-p${$})`});x.gl.firstElementChild.append(g),v.push(g)}const h=ea(y,y.offsetWidth,y.offsetHeight)[0];return{el:y,rects:v,pattern:X,image:M,radiusPx:h,lowRes:!1,measured:null,lastGeom:null,lastHole:null}});if(a.setAttribute("opacity","0"),t.melt={layers:k,entries:W,seam:x},e.surface==="image"&&s[0]){const y=K("pattern",{id:`${o}-bp`,patternUnits:"objectBoundingBox",patternContentUnits:"objectBoundingBox",width:"1",height:"1"}),$=K("image",{width:"1",height:"1",preserveAspectRatio:"xMidYMid slice"});$.setAttribute("href",s[0].currentSrc||s[0].src),y.append($),c.append(y),t.blob.setAttribute("fill",`url(#${o}-bp)`)}else t.blob.removeAttribute("fill")}clearBlend(t){var e,a,r,s;(e=t.blend)==null||e.host.setAttribute("opacity","0"),t.meltHostLast=null,t.meltWroteAt=0,t.meltAxis=null;for(const o of((a=t.melt)==null?void 0:a.layers)??[])o.last=void 0;(r=t.melt)!=null&&r.seam&&(t.melt.seam.last=void 0,t.melt.seam.gl.setAttribute("opacity","0"));for(const o of((s=t.melt)==null?void 0:s.entries)??[])o.el.style.removeProperty("mask-image"),o.el.style.removeProperty("-webkit-mask-image"),o.el.style.removeProperty("mask-composite"),o.el.style.removeProperty("-webkit-mask-composite"),o.lastHole=null,o.lastGeom=null}measureAll(t=1/60){const e=this.getGroup();if(!e||this.items.size===0)return!1;const a=e.getBoundingClientRect();let r=!1;for(const s of this.items){const o=s.target.getBoundingClientRect();s.frame={x:o.left-a.left,y:o.top-a.top,w:o.width,h:o.height}}for(const s of this.items)if(!(!s.blend||!s.melt))for(const o of s.melt.entries){const i=o.el.getBoundingClientRect();o.measured={x:i.left-a.left,y:i.top-a.top,w:i.width,h:i.height,ow:o.el.offsetWidth,oh:o.el.offsetHeight}}for(const s of this.items)this.writeBlob(s,t)&&(r=!0);for(const s of this.items)s.blend&&this.writeBlend(s,t)&&(r=!0);return r}effectiveInset(t,e){let a=t.blobInset??0;const r=t.bridgeGrow??0;if(r>0&&t.frame){const s=t.frame,o=Math.max(14,this.gooBlur*3);let i=1/0;for(const n of this.items){if(n===t||!n.frame)continue;const l=n.frame,f=Math.max(l.x-(s.x+s.w),s.x-(l.x+l.w),0),p=Math.max(l.y-(s.y+s.h),s.y-(l.y+l.h),0),b=Math.hypot(f,p);b<i&&(i=b)}i<o&&(a-=r*Zt(1-i/o))}return r<=0?(t.biSmooth=a,a):(t.biSmooth===null?t.biSmooth=a:t.biSmooth+=(a-t.biSmooth)*Math.min(1,e*18),t.biSmooth)}writeBlob(t,e){var M,v;const a=t.frame,r=t.dynamics;if(!r||!r.evolve&&!r.move){const h=this.effectiveInset(t,e),g=t.last,H=!g||Math.abs(g.x-a.x)>=.05||Math.abs(g.y-a.y)>=.05||Math.abs(g.w-a.w)>=.05||Math.abs(g.h-a.h)>=.05,w=Math.abs(h-t.lastBi)>=.05;if(!H&&!w)return!1;if(t.blob.style.transform=`translate(${a.x+h}px, ${a.y+h}px)`,H||w){const A=Math.max(0,a.w-h*2),O=Math.max(0,a.h-h*2);t.blob.setAttribute("width",String(A)),t.blob.setAttribute("height",String(O));const E=t.baseW>0?a.w/t.baseW:1;t.blob.setAttribute("rx",String(ka(t.radiusPx*E-h,A,O)))}return t.lastPaint=null,t.last=a,t.lastBi=h,!0}const s=a.x+a.w/2,o=a.y+a.h/2;let i;if(r.evolve){const h=t.target.offsetWidth,g=t.target.offsetHeight;i=ea(t.target,h,g)[0]}else i=t.radiusPx*(t.baseW>0?a.w/t.baseW:1);t.sim||(t.sim={cx:s,cy:o,w:a.w,h:a.h,r:i,vcx:0,vcy:0,vw:0,vh:0,vr:0});const n=t.sim;if(r.move){const h=r.moveOpts??et;[n.cx,n.vcx]=Ie(n.cx,n.vcx,s,h.stiffness,h.damping,e),[n.cy,n.vcy]=Ie(n.cy,n.vcy,o,h.stiffness,h.damping,e)}else if(r.evolve){const h=r.evolveOpts??ke,g=t.tPrev?(s-t.tPrev.cx)/e:0,H=t.tPrev?(o-t.tPrev.cy)/e:0;t.tvx=t.tvx*.7+g*.3,t.tvy=t.tvy*.7+H*.3,t.tPrev={cx:s,cy:o};const w=s-n.cx,A=o-n.cy,O=Math.hypot(w,A),E=Math.hypot(t.tvx,t.tvy);let z=0,S=0;E>.001?(z=t.tvx/E,S=t.tvy/E):O>.001&&(z=w/O,S=A/O);const Y=Math.max(0,h.anticipation)/1e3,D=Y>0?1-Math.exp(-e/Y):1;t.lead01+=((O>.5?1:0)-t.lead01)*D;const P=Math.min(Math.max(0,h.travel)*t.lead01,O),L=z*P,j=S*P;[n.cx,n.vcx]=Ie(n.cx,n.vcx,s+L,h.massStiffness,h.massDamping,e),[n.cy,n.vcy]=Ie(n.cy,n.vcy,o+j,h.massStiffness,h.massDamping,e)}else n.cx=s,n.cy=o,n.vcx=0,n.vcy=0;if(r.evolve){const h=r.evolveOpts??ke;[n.w,n.vw]=Ie(n.w,n.vw,a.w,h.sizeStiffness,h.sizeDamping,e),[n.h,n.vh]=Ie(n.h,n.vh,a.h,h.sizeStiffness,h.sizeDamping,e),[n.r,n.vr]=Ie(n.r,n.vr,i,h.radiusStiffness,h.radiusDamping,e)}else n.w=a.w,n.h=a.h,n.r=i,n.vw=0,n.vh=0,n.vr=0;let l="";const f=Math.hypot(n.vcx,n.vcy);if(r.move&&f>2){const h=Math.min((r.moveOpts??et).stretch,f*6e-4),g=Math.round(Math.atan2(n.vcy,n.vcx)*100)/100;l+=` rotate(${g}rad) scale(${(1+h).toFixed(3)}, ${(1/(1+h*.65)).toFixed(3)}) rotate(${-g}rad)`}if(r.move&&t.tailEl){const h=R=>Math.round(R*10)/10;t.tailR===0&&Math.abs(t.tailX)<.001&&Math.abs(t.tailY)<.001&&(t.tailX=n.cx,t.tailY=n.cy),[t.tailX,t.tailVx]=Ie(t.tailX,t.tailVx,n.cx,170,22,e),[t.tailY,t.tailVy]=Ie(t.tailY,t.tailVy,n.cy,170,22,e);const g=t.blobInset??0,H=f>.001?n.vcx/f:1,w=f>.001?n.vcy/f:0,A=Math.max(4,Math.abs(H)*n.h+Math.abs(w)*n.w-g*2),O=(Math.abs(H)*n.w+Math.abs(w)*n.h)/2,E=A/2,z=t.tailX-n.cx,S=t.tailY-n.cy,Y=Math.hypot(z,S),D=r.moveOpts??et,P=O+E*(.2+D.force*1.6);Y>P&&(t.tailX=n.cx+z/Y*P,t.tailY=n.cy+S/Y*P);const L=D.tail,j=Math.max(0,Math.min(1,(f-20)/120)),T=E*L*j;if(t.tailR+=(T-t.tailR)*Math.min(1,e*10),t.tailR<.3)t.lastTail!=="hidden"&&(t.tailEl.setAttribute("r","0"),(M=t.tailMidA)==null||M.setAttribute("r","0"),(v=t.tailMidB)==null||v.setAttribute("r","0"),t.lastTail="hidden");else{t.tailPhase+=f*e*.045;const R=t.tailR*.16,I=-w,_=H,V=Math.sin(t.tailPhase)*R,G=Math.sin(t.tailPhase+2.4)*-R,ae=n.cx+z*.45+I*V,Q=n.cy+S*.45+_*V,fe=n.cx+z*.75+I*G,q=n.cy+S*.75+_*G,ie=`${h(t.tailX)},${h(t.tailY)},${h(t.tailR)},${h(ae)},${h(Q)},${h(fe)},${h(q)}`;ie!==t.lastTail&&(t.tailEl.setAttribute("cx",String(h(t.tailX))),t.tailEl.setAttribute("cy",String(h(t.tailY))),t.tailEl.setAttribute("r",String(h(t.tailR))),t.tailMidA&&(t.tailMidA.setAttribute("cx",String(h(ae))),t.tailMidA.setAttribute("cy",String(h(Q))),t.tailMidA.setAttribute("r",String(h(t.tailR*.62)))),t.tailMidB&&(t.tailMidB.setAttribute("cx",String(h(fe))),t.tailMidB.setAttribute("cy",String(h(q))),t.tailMidB.setAttribute("r",String(h(t.tailR*.4)))),t.lastTail=ie)}}let p=Math.max(0,n.r),b=!1;if(r.evolve){const h=r.evolveOpts??ke,g=performance.now(),H=t.lastTargetSize;(H?Math.abs(a.w-H.w)+Math.abs(a.h-H.h):0)>.5?(t.morphActive||(t.cornerT0=g,t.morphActive=!0),t.lastTargetMoveT=g):t.morphActive&&g-t.lastTargetMoveT>150&&g-t.cornerT0>go(h)&&(t.morphActive=!1),t.lastTargetSize={w:a.w,h:a.h};const A=go(h);let O=0;if(t.cornerT0>0&&h.roundness>0&&g-t.cornerT0<A){const D=Math.min(1,Math.max(0,(g-t.cornerT0-Math.max(0,h.cornerDelay))/Math.max(1,h.cornerDuration))),P=Vo(h.cornerEase)(D);O=Math.min(1,Math.max(0,(1-P)*h.roundness))}const E=e*8;if(t.round01+=Math.max(-E,Math.min(E,O-t.round01)),b=t.cornerT0>0&&g-t.cornerT0<A+80||Math.abs(O-t.round01)>.004||t.round01>.004,t.round01>.001){const D=Math.max(Math.min(n.w,n.h)/2,p);p=p+(D-p)*t.round01,p=Math.max(p,i)}const z=Math.min(1,(Math.hypot(n.vcx,n.vcy)+Math.abs(n.vw)+Math.abs(n.vh))/420);t.motionEnv=Math.max(z,t.motionEnv-e*1.9);const S=t.motionEnv,Y=S*S*Math.max(0,h.contentBlur);Y>.3?(t.target.style.filter=`blur(${Y.toFixed(1)}px)`,t.contentBlurred=!0):t.contentBlurred&&(t.target.style.removeProperty("filter"),t.contentBlurred=!1)}const c=t.blobInset??0,d=Math.max(0,n.w-c*2),m=Math.max(0,n.h-c*2),k=ka(p-c,d,m);let x="";if(r.move&&t.bendPathEl){const h=r.moveOpts??et,g=Math.min(d,m)*.5,H=Math.max(-g,Math.min(g,n.vcy*.05))*h.bend,w=Math.min(d,m)*.9,A=Math.max(-w,Math.min(w,n.vcx*.09))*h.bendX;t.bendCur+=(H-t.bendCur)*Math.min(1,e*9),t.bendCurX+=(A-t.bendCurX)*Math.min(1,e*9);const O=Math.round(t.bendCurX*10)/10,E=Math.round(t.bendCur*10)/10,z=`${O},${E}`;if(z!==t.lastBendVars&&(t.target.style.setProperty("--lg-bend-x",`${O}px`),t.target.style.setProperty("--lg-bend-y",`${E}px`),t.target.style.setProperty("--lg-bend-xn",String(O)),t.target.style.setProperty("--lg-bend-yn",String(E)),t.lastBendVars=z),(Math.abs(t.bendCur)>.5||Math.abs(t.bendCurX)>.5)&&d>1&&m>1){const Y=Math.min(k,d/2,m/2),D=Math.round(t.bendCur*2*10)/10,P=t.bendCurX,L=Math.max(Y*.2,Math.min(Y*3,P>0?Y-.8*P:Y+1.6*-P)),j=Math.max(Y*.2,Math.min(Y*3,P>0?Y+1.6*P:Y-.8*-P)),T=.5523,R=I=>Math.round(I*10)/10;x=`M ${R(j)} 0 Q ${R(d/2)} ${D} ${R(d-L)} 0 C ${R(d-L+T*L)} 0 ${R(d)} ${R(Y-T*Y)} ${R(d)} ${R(Y)} L ${R(d)} ${R(m-Y)} C ${R(d)} ${R(m-Y+T*Y)} ${R(d-L+T*L)} ${R(m)} ${R(d-L)} ${R(m)} Q ${R(d/2)} ${R(m+t.bendCur*2)} ${R(j)} ${R(m)} C ${R(j-T*j)} ${R(m)} 0 ${R(m-Y+T*Y)} 0 ${R(m-Y)} L 0 ${R(Y)} C 0 ${R(Y-T*Y)} ${R(j-T*j)} 0 ${R(j)} 0 Z`}}const W=x!=="",y={t:`translate(${n.cx-n.w/2+c}px, ${n.cy-n.h/2+c}px)`+l,w:W?"0":String(d),h:String(m),rx:String(k)},$=t.lastPaint;return(!$||$.t!==y.t)&&(t.blob.style.transform=y.t),(!$||$.w!==y.w)&&t.blob.setAttribute("width",y.w),(!$||$.h!==y.h)&&t.blob.setAttribute("height",y.h),(!$||$.rx!==y.rx)&&t.blob.setAttribute("rx",y.rx),t.lastPaint=y,t.bendPathEl&&(x!==(t.lastBendD??"")&&(t.bendPathEl.setAttribute("d",x),t.lastBendD=x),W&&(t.bendPathEl.style.transform=y.t)),t.last=a,!(Math.abs(n.cx-s)<.05&&Math.abs(n.cy-o)<.05&&Math.abs(n.w-a.w)<.05&&Math.abs(n.h-a.h)<.05&&Math.abs(n.r-i)<.05&&f<1&&Math.abs(n.vw)+Math.abs(n.vh)+Math.abs(n.vr)<1&&t.motionEnv<.01&&t.tailR<.3&&!b)}writeBlend(t,e){const a=t.frame,r=t.blend,s=t.melt;if(!s)return!1;const o=r.range??Math.max(10,this.gooBlur*2.5);let i=1/0,n=null;for(const F of this.items){if(F===t||!F.frame)continue;const B=F.frame,U=Math.max(B.x-(a.x+a.w),a.x-(B.x+B.w),0),J=Math.max(B.y-(a.y+a.h),a.y-(B.y+B.h),0),N=Math.hypot(U,J);N<i&&(i=N,n=B)}let l=0,f=0;if(n&&i===0){const F=n,B=Math.min(a.x+a.w,F.x+F.w)-Math.max(a.x,F.x),U=Math.min(a.y+a.h,F.y+F.h)-Math.max(a.y,F.y),J=Math.max(1,Math.min(a.w,a.h,F.w,F.h));l=Math.max(0,Math.min(B,U))/J,f=Math.max(0,Math.max(B,U))}let p=0;if(n&&i<o&&r.active!==!1){const F=Zt(Math.min(1,(1-i/o)/.65)),B=Math.max(0,Math.min(1,r.strength??1)),U=Math.max(.01,r.sink??.45),J=Zt(Math.max(0,Math.min(1,(l-U*.2)/Math.max(.01,U*.8))));p=Math.pow(F,1.25)*B*(1-J)}if(p>=t.meltFade)t.meltFade+=(p-t.meltFade)*Math.min(1,e*16),t.meltRel=null;else if(p>.02)t.meltFade+=(p-t.meltFade)*Math.min(1,e*6),t.meltRel=null;else{const F=Math.max(40,Math.max(r.releaseMs??240,r.fadeMs??r.releaseMs??240));t.meltRel||(t.meltRel={from:t.meltFade,t:0});const B=t.meltRel;B.t+=e*1e3;const U=Math.min(1,B.t/F);t.meltFade=p+(B.from-p)*(1-U)*(1-U)}p===0&&t.meltFade<.001&&(t.meltFade=0);const b=t.meltFade;if(b<=.001)return t.lastBlend&&t.lastBlend.s!==0?(this.clearBlend(t),t.lastBlend={cx:0,cy:0,s:0,d:0,pk:""},!0):!1;let c=n;if((!c||i>=o)&&t.meltGeom&&(c=t.meltGeom.o),!c)return!1;const d=a.x+a.w<c.x?(a.x+a.w+c.x)/2:c.x+c.w<a.x?(c.x+c.w+a.x)/2:(Math.max(a.x,c.x)+Math.min(a.x+a.w,c.x+c.w))/2,m=a.y+a.h<c.y?(a.y+a.h+c.y)/2:c.y+c.h<a.y?(c.y+c.h+a.y)/2:(Math.max(a.y,c.y)+Math.min(a.y+a.h,c.y+c.h))/2;t.meltGeom={o:{...c}};const k=t.meltRel,x=Math.max(40,r.fadeMs??r.releaseMs??240),W=k?Math.min(1,k.t/x):0,y=k?(1-W)*(1-W):1,$=k?Math.min(1,k.from*(.55+.45*(1-W))):b,X=$*$*(3-2*$);t.meltOp=y<t.meltOp?y:t.meltOp+(y-t.meltOp)*Math.min(1,e*16);const M=r.zone??this.gooBlur*2.2+4,v=Math.min(Math.min(a.w,a.h)*.9,M*(.7+.6*$)),h=Math.max(0,r.flowSpeed??26),g=t.meltPrev,H=g?Math.hypot(a.x-g.x,a.y-g.y)/Math.max(.001,e):0;t.meltPrev={x:a.x,y:a.y};const w=Math.min(e,1/24)*h*.12*Math.min(1,H/40);t.meltPhase+=w;const A=t.lastBlend,O=`${r.seamBlur??""}/${r.strength??""}/${r.warp}/${r.blur}/${r.mix??""}/${r.gravity??""}`;if(w<1e-4&&A&&A.pk===O&&Math.abs(A.cx-d)<.05&&Math.abs(A.cy-m)<.05&&Math.abs(A.s-b)<.005&&Math.abs(A.d-v)<.05)return!1;const E=performance.now();if(this.frameEma>20&&E-t.meltWroteAt<35)return!0;t.meltWroteAt=E;const z=F=>Math.round(F*10)/10,S=r.host,Y=s.layers.length,D=c.x+c.w/2,P=c.y+c.h/2,L=D-d,j=P-m,T=Math.hypot(L,j)||1,R=L/T,I=j/T,_=Math.max(0,r.gravity??25)*X,V=z(Math.atan2(I,R)*180/Math.PI),G=F=>Math.round(F*1e3)/1e3,ae=Math.max(0,Math.min(1,r.taper??.65)),Q=Math.max(.2,r.warpFreq??1),fe=r.zone??this.gooBlur*2.2+4,q=Math.min(.3,Math.max(.01,Q/(fe*1.1))),ie=(q*.35).toFixed(4),de=(q*1.6).toFixed(4),Z=Math.abs(R),oe=Math.abs(I),me=t.meltAxis==="x"?oe>Z*1.25?"y":"x":t.meltAxis==="y"?Z>oe*1.25?"x":"y":Z>=oe?"x":"y";t.meltAxis=me;const he=me==="x"?`${ie} ${de}`:`${de} ${ie}`,ue=d+R*v*.05,le=m+I*v*.05,Pe=s.layers.map((F,B)=>{const U=Y>1?B/(Y-1):1,J=.15+.85*Math.pow(U,1.4),N=.45+.55*U,te=.7+.45*U,ge=6*Math.sin(t.meltPhase*te),Wt=2*Math.sin(t.meltPhase*te*1.31+1.7);return[String(se(r.warp*N*X,.25)),String(se(r.blur*J*X,.25)),String(se(R*ge-I*Wt,.5)),String(se(I*ge+R*Wt,.5)),String(se(ue,.5)),String(se(le,.5)),String(se(v*(.95-.55*U),.5)),String(se(Math.min(1,X*(.75+.25*U)),.02))]}),Te=d-R*v,Le=m-I*v,Ae=1-.45*Zt(Math.min(1,l*2.2)),ye=Math.min(2.2,(_+i)/Math.max(8,2*v))*(.5+ae)*Ae,xe=F=>{const B=G(1+ye*F),U=G(1/(1+ye*.35*F));return`translate(${z(Te)}, ${z(Le)}) rotate(${V}) scale(${B}, ${U}) rotate(${-V}) translate(${z(-Te)}, ${z(-Le)})`},We=Math.max(0,Math.min(1,r.mix??0))*X,Oe=F=>{if(F<.002)return"0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0 1";const B=G(1+4*F),U=G(1-B*(.38+.12*F));return`0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  ${B} 0 0 0 ${U}`},ee=se(1+Math.min(1.8,i/Math.max(8,2*v)),.05),re=ee>1.001?`translate(${z(ue)}, ${z(le)}) rotate(${V}) scale(${G(ee)}, 1) rotate(${-V}) translate(${z(-ue)}, ${z(-le)})`:"",be=r.blur*2.5+r.warp+_*.5+ye*v+8,$e=se(v*1.15*ee+be,8),Ge=String(se(ue-$e,8)),Ve=String(se(le-$e,8)),Fe=String(se($e*2,8));if(s.layers.forEach((F,B)=>{const U=Y>1?B/(Y-1):1,J=Pe[B],N=xe(.4+.6*U),te=Oe(se(We*(.15+.85*U),.01)),ge=J.join(",")+"|"+he+"|"+N+"|"+te+"|"+re+"|"+Ge+","+Ve+","+Fe;F.last!==ge&&(F.last=ge,F.filter.setAttribute("x",Ge),F.filter.setAttribute("y",Ve),F.filter.setAttribute("width",Fe),F.filter.setAttribute("height",Fe),F.disp.setAttribute("scale",J[0]),F.blurEl.setAttribute("stdDeviation",J[1]),F.turb.getAttribute("baseFrequency")!==he&&F.turb.setAttribute("baseFrequency",he),F.noiseOffset.setAttribute("dx",J[2]),F.noiseOffset.setAttribute("dy",J[3]),F.circle.setAttribute("cx",J[4]),F.circle.setAttribute("cy",J[5]),F.circle.setAttribute("r",J[6]),re?F.circle.setAttribute("transform",re):F.circle.removeAttribute("transform"),F.gl.setAttribute("opacity",J[7]),F.shift.setAttribute("transform",N),F.erode.setAttribute("values",te))}),s.seam){const F=s.seam,B=se((r.seamBlur??r.blur*1.6)*X,.25),U=se(Math.min(1,X*1.2)*.55,.02),J=se(v*1.25,.5),N=`${B}|${U}|${se(ue,.5)},${se(le,.5)},${J}|${re}|${Ge},${Ve},${Fe}`;F.last!==N&&(F.last=N,F.filter.setAttribute("x",Ge),F.filter.setAttribute("y",Ve),F.filter.setAttribute("width",Fe),F.filter.setAttribute("height",Fe),F.blurEl.setAttribute("stdDeviation",String(B)),F.circle.setAttribute("cx",String(se(ue,.5))),F.circle.setAttribute("cy",String(se(le,.5))),F.circle.setAttribute("r",String(J)),re?F.circle.setAttribute("transform",re):F.circle.removeAttribute("transform"),F.gl.setAttribute("opacity",String(U)))}const Dt=a.x+a.w/2,fa=a.y+a.h/2,Nt=Math.atan2(m-fa,d-Dt),kt=r.pull*$,ot=G(t.meltOp).toString()+`|translate(${z(Math.cos(Nt)*kt)}px, ${z(Math.sin(Nt)*kt)}px)`;if(ot!==t.meltHostLast){t.meltHostLast=ot;const F=ot.split("|");S.setAttribute("opacity",F[0]),S.style.transform=F[1]}const St=Math.max(10,this.gooBlur*2.5),Ea=n?i<St?Zt(1-i/St):0:b,Be=se(Math.max(0,1-Math.min(b,Ea)*2.2),.05).toFixed(2),De=(Math.round((1+2*Number(Be))/3*20)/20).toFixed(2);for(const F of s.entries){if(!F.lowRes){const ne=r0(F.el);ne?(F.image.setAttribute("href",ne),F.lowRes=!0):F.el.complete&&F.el.naturalWidth&&(F.lowRes=!0)}const B=F.measured;if(!B||B.w<1||B.h<1)continue;const U=B.x,J=B.y,N=(B.ow||B.w)/B.w,te=`${z(U)},${z(J)},${z(B.w)},${z(B.h)},${z(ka(F.radiusPx/(N||1),B.w,B.h))}`;if(te!==F.lastGeom){F.lastGeom=te;for(const ne of F.rects)ne.setAttribute("x",String(z(U))),ne.setAttribute("y",String(z(J))),ne.setAttribute("width",String(z(B.w))),ne.setAttribute("height",String(z(B.h))),ne.setAttribute("rx",String(z(ka(F.radiusPx/(N||1),B.w,B.h))));F.pattern.setAttribute("x",String(z(U))),F.pattern.setAttribute("y",String(z(J))),F.pattern.setAttribute("width",String(z(B.w))),F.pattern.setAttribute("height",String(z(B.h))),F.image.setAttribute("width",String(z(B.w))),F.image.setAttribute("height",String(z(B.h)))}const ge=(B.oh||B.h)/B.h;if(Math.hypot(Math.max(U-d,d-(U+B.w),0),Math.max(J-m,m-(J+B.h),0))>v){F.lastHole!==null&&(F.lastHole=null,F.el.style.removeProperty("mask-image"),F.el.style.removeProperty("-webkit-mask-image"),F.el.style.removeProperty("mask-composite"),F.el.style.removeProperty("-webkit-mask-composite"));continue}const Re=B.ow||B.w,Ce=B.oh||B.h,Ue=Math.min(Re,Ce)/2;let Ht=(d-U)*N,Xt=(m-J)*ge,st=Ht-Re/2,nt=Xt-Ce/2;const it=Math.hypot(st,nt);it<Ue&&(it<.001?(st=R,nt=I):(st/=it,nt/=it),Ht=Re/2+st*Ue,Xt=Ce/2+nt*Ue);const Ke=Math.round(Ht),_e=Math.round(Xt),ct=se(Math.min(Math.max(v,f*.75)*Math.min(N,ge),Ue),1),da=z(Math.max(Math.hypot(Ke,_e),Math.hypot(Ke-Re,_e),Math.hypot(Ke,_e-Ce),Math.hypot(Ke-Re,_e-Ce)))+2;let Ne;if(i===0&&f>4&&n){const ne=n,we=(ne.x+ne.w/2-U)*N,Me=(ne.y+ne.h/2-J)*ge,It=(Math.max(a.x,ne.x)-U)*N,qt=(Math.max(a.y,ne.y)-J)*ge,Gt=(Math.min(a.x+a.w,ne.x+ne.w)-U)*N,Vt=(Math.min(a.y+a.h,ne.y+ne.h)-J)*ge,Ut=Math.round(Math.max(Math.hypot(It-we,qt-Me),Math.hypot(Gt-we,qt-Me),Math.hypot(It-we,Vt-Me),Math.hypot(Gt-we,Vt-Me))+3),pa=Math.round(Math.min(Ue*2.6,Math.max(ct,(r.seamBlur??r.blur*1.6)*3.2))),ba=Math.max(0,Ut-pa),ha=Math.round(Math.max(Math.hypot(we,Me),Math.hypot(we-Re,Me),Math.hypot(we,Me-Ce),Math.hypot(we-Re,Me-Ce)))+2;Ne=`radial-gradient(circle at ${Math.round(we)}px ${Math.round(Me)}px, rgba(255,255,255,${Be}) ${ba}px, #fff ${Ut}px, #fff ${ha}px)`}else Ne=`radial-gradient(circle at ${Ke}px ${_e}px, rgba(255,255,255,${Be}) ${z(ct*.2)}px, rgba(255,255,255,${De}) ${z(ct*.45)}px, #fff ${z(ct*.78)}px, #fff ${da}px)`;Ne!==F.lastHole&&(F.lastHole=Ne,F.el.style.setProperty("mask-image",Ne),F.el.style.setProperty("-webkit-mask-image",Ne),F.el.style.removeProperty("mask-composite"),F.el.style.removeProperty("-webkit-mask-composite"))}return t.lastBlend={cx:d,cy:m,s:b,d:v,pk:O},!0}ensureSources(){if(this.sourcesReady)return;const t=this.getGroup();if(!t)return;this.sourcesReady=!0,this.mo=new MutationObserver(a=>{for(const r of a){const s=r.target;if(!(s instanceof Element)||!s.closest("[data-gooey-svg], [data-gooey-overlay]")){this.wake();return}}}),this.mo.observe(t,{attributes:!0,childList:!0,subtree:!0,attributeFilter:["style","class"]});const e=()=>this.wake();for(const a of["transitionrun","animationstart","pointerdown"])t.addEventListener(a,e,!0),this.removeListeners.push(()=>t.removeEventListener(a,e,!0));window.addEventListener("scroll",e,{capture:!0,passive:!0}),this.removeListeners.push(()=>window.removeEventListener("scroll",e,!0)),this.interval=setInterval(()=>{!this.awake&&this.measureAll()&&this.wake()},300)}};function xo(t,e){const a=[];let r=0,s="";for(const o of t)o==="("?r++:o===")"&&r--,r===0&&(e===","?o===",":/\s/.test(o))?(s.trim()&&a.push(s.trim()),s=""):s+=o;return s.trim()&&a.push(s.trim()),a}var s0=/^[+-]?(\d+\.?\d*|\.\d+)(px)?$/;function n0(t){if(!t||t.trim()===""||t.trim()==="none")return[];const e=[];for(const a of xo(t,",")){const r=xo(a," ");if(r.length===0)continue;const s=r.includes("inset"),o=[],i=[];for(const b of r)b!=="inset"&&(o.length<4&&s0.test(b)?o.push(parseFloat(b)):i.push(b));const[n=0,l=0,f=0,p=0]=o;e.push({x:n,y:l,blur:f,spread:p,color:i.join(" ")||"rgba(0, 0, 0, 0.35)",inset:s})}return e}var i0=C.forwardRef(function({blur:e=6,contrast:a=18,fill:r="#fff",shadow:s,filterPadding:o=24,waviness:i=0,wavinessFreq:n=.018,filter:l,className:f,style:p,children:b,...c},d){const m=C.useRef(null),[k,x]=C.useState(null),[W,y]=C.useState(null),[$,X]=C.useState({w:0,h:0}),M=C.useCallback(S=>{m.current=S,typeof d=="function"?d(S):d&&(d.current=S)},[d]),v=`gooey-${C.useId().replace(/[^a-zA-Z0-9_-]/g,"")}`,h=C.useMemo(()=>n0(s),[s]);Ra(()=>{const S=m.current;if(!S)return;const Y=()=>X(P=>P.w===S.offsetWidth&&P.h===S.offsetHeight?P:{w:S.offsetWidth,h:S.offsetHeight});Y();const D=new ResizeObserver(Y);return D.observe(S),()=>D.disconnect()},[]);const g=C.useMemo(()=>new o0(()=>m.current),[]),H=C.useMemo(()=>Gi(),[]);C.useEffect(()=>()=>g.dispose(),[g]),C.useEffect(()=>{g.gooBlur=e},[g,e]);const w=C.useMemo(()=>({portal:k,meltPortal:W,fill:r,getGroup:()=>m.current,engine:g,imageMelt:H}),[k,W,r,g,H]),A=h.filter(S=>S.inset||S.spread!==0),O=h.filter(S=>!S.inset&&S.spread===0).map(S=>`drop-shadow(${S.x}px ${S.y}px ${S.blur}px ${S.color})`).join(" "),E=A.reduce((S,Y)=>Math.max(S,Math.max(Math.abs(Y.x),Math.abs(Y.y))+Y.blur*1.5+Math.max(0,Y.spread)),0),z=Math.ceil(e*3+E+o);return u.jsxs("div",{...c,ref:M,className:f,style:{position:"relative",isolation:"isolate",...p},children:[u.jsxs("svg",{"aria-hidden":"true",focusable:"false","data-gooey-svg":"",style:{position:"absolute",inset:0,width:"100%",height:"100%",overflow:"visible",pointerEvents:"none",zIndex:-1,filter:O||void 0,willChange:"filter, transform"},children:[u.jsx("defs",{children:l?u.jsx("filter",{id:v,filterUnits:"userSpaceOnUse",x:-z,y:-z,width:$.w+z*2,height:$.h+z*2,colorInterpolationFilters:"sRGB",dangerouslySetInnerHTML:{__html:l}}):u.jsx("filter",{id:v,filterUnits:"userSpaceOnUse",x:-z,y:-z,width:$.w+z*2,height:$.h+z*2,colorInterpolationFilters:"sRGB",children:u.jsx(Ii,{blur:e,contrast:a,shadows:A,waviness:i,wavinessFreq:n})})}),u.jsx("g",{id:`${v}-sil`,ref:x,filter:`url(#${v})`,style:{fill:r}})]}),u.jsxs("svg",{"aria-hidden":"true",focusable:"false","data-gooey-overlay":"",style:{position:"absolute",inset:0,width:"100%",height:"100%",overflow:"visible",pointerEvents:"none",zIndex:9999},children:[u.jsx("defs",{children:u.jsx("mask",{id:`${v}-meltmask`,maskUnits:"userSpaceOnUse",x:-z,y:-z,width:$.w+z*2,height:$.h+z*2,children:u.jsx("use",{href:`#${v}-sil`})})}),u.jsx("g",{mask:`url(#${v}-meltmask)`,children:u.jsx("g",{ref:y})})]}),u.jsxs(qo.Provider,{value:w,children:[b,u.jsx(Ki,{registry:H})]})]})}),c0={snappy:{stiffness:480,damping:34,mass:1},smooth:{stiffness:190,damping:26,mass:1},bouncy:{stiffness:320,damping:17,mass:1}},Sa=1/240;function l0(t){let e=0,a=0,r=0,s=-1,o=0;const i=[0];for(;r<10;){const b=(-t.stiffness*(e-1)-t.damping*a)/t.mass;if(a+=b*Sa,e+=a*Sa,r+=Sa,i.push(e),e>o&&(o=e),Math.abs(e-1)<.001&&Math.abs(a)<.02){if(s<0&&(s=r),r-s>=.064)break}else s=-1}const n=s>0?s:r,l=Math.round(Math.min(120,Math.max(24,n*90))),f=Math.min(i.length-1,n/Sa),p=[];for(let b=0;b<=l;b++){const c=Math.min(i.length-1,Math.round(b/l*f));p.push(Math.round(i[c]*1e4)/1e4)}return p[p.length-1]=1,{duration:n,values:p,overshoots:o>1.001}}var _a=null;function $o(){return _a==null&&(_a=typeof CSS<"u"&&typeof CSS.supports=="function"&&CSS.supports("transition-timing-function","linear(0, 1)")),_a}var vo=new Map,yo=new Map;function ta(t){let e=yo.get(t);if(e)return e;const a=/^linear\(([^)]+)\)$/.exec(t.trim()),r=/^cubic-bezier\(([^)]+)\)$/.exec(t.trim());if(a){const s=a[1].split(",").map(Number);e=o=>{if(o<=0)return s[0];if(o>=1)return s[s.length-1];const i=o*(s.length-1),n=Math.floor(i);return s[n]+(s[n+1]-s[n])*(i-n)}}else if(r){const[s,o,i,n]=r[1].split(",").map(Number);e=l=>{if(l<=0)return 0;if(l>=1)return 1;let f=0,p=1;for(let c=0;c<24;c++){const d=(f+p)/2;3*d*(1-d)*(1-d)*s+3*d*d*(1-d)*i+d**3<l?f=d:p=d}const b=(f+p)/2;return 3*b*(1-b)*(1-b)*o+3*b*b*(1-b)*n+b**3}}else t==="ease"?e=ta("cubic-bezier(0.25, 0.1, 0.25, 1)"):t==="ease-in"?e=ta("cubic-bezier(0.42, 0, 1, 1)"):t==="ease-out"?e=ta("cubic-bezier(0, 0, 0.58, 1)"):t==="ease-in-out"?e=ta("cubic-bezier(0.42, 0, 0.58, 1)"):e=s=>Math.min(1,Math.max(0,s));return yo.set(t,e),e}function f0(t,e=!1){if(e)return{duration:0,easing:"linear"};const a=t??"smooth";if(typeof a=="object"&&"duration"in a)return{duration:a.duration,easing:a.ease??"cubic-bezier(0.22, 1, 0.36, 1)"};const r=typeof a=="string"?c0[a]:{stiffness:300,damping:24,mass:1,...a},s=`${r.stiffness}/${r.damping}/${r.mass}/${$o()}`;let o=vo.get(s);if(!o){const i=l0(r);o={duration:Math.round(i.duration*1e3),easing:$o()?`linear(${i.values.join(", ")})`:i.overshoots?"cubic-bezier(0.34, 1.56, 0.64, 1)":"cubic-bezier(0.22, 1, 0.36, 1)"},vo.set(s,o)}return o}function Uo(t){return Array.isArray(t)?t:t?[t]:[]}function Ja(t){const e=xr();return t.observe||Uo(t.effect).some(r=>r!=="morph")?u.jsx(u0,{...t,ctx:e}):u.jsx(b0,{...t,ctx:e})}function d0(t){return typeof t=="string"?t:JSON.stringify(t??null)}function p0(t,e){return!!t&&t.x===e.x&&t.y===e.y&&t.w===e.w&&t.h===e.h&&t.r.every((a,r)=>a===e.r[r])}function b0({x:t=0,y:e=0,scale:a=1,transition:r="smooth",delay:s=0,radius:o,className:i,style:n,children:l,ctx:f}){const p=C.useRef(null),b=C.useRef(null),[c,d]=C.useState(null),m=Ji(),k=d0(r),{duration:x,easing:W}=C.useMemo(()=>f0(r,m),[k,m]),y=o==null?"":JSON.stringify(o);Ra(()=>{const M=p.current,v=f.getGroup();if(!M||!v)return;const h=()=>{const H=Zi(M,v),w=M.offsetWidth,A=M.offsetHeight,O=M.firstElementChild??M,E=o!=null?Go(o):ea(O,w,A),z={x:H.x,y:H.y,w,h:A,r:E};d(S=>p0(S,z)?S:z)};h();const g=new ResizeObserver(h);return g.observe(M),g.observe(v),()=>g.disconnect()},[f,y]);const $=C.useRef(null),X=(M,v,h)=>{const g=`translate(${M}px, ${v}px)`+(h!==1?` scale(${h})`:"");p.current&&(p.current.style.transform=g),b.current&&(b.current.style.transform=g)};return Ra(()=>{const M=$.current;if(!M||x<=0||M.x===t&&M.y===e&&M.s===a){$.current={x:t,y:e,s:a},X(t,e,a);return}const v={...M},h=ta(W),g=performance.now()+s;let H=0;const w=A=>{const O=Math.min(1,Math.max(0,(A-g)/x)),E=h(O),z=v.x+(t-v.x)*E,S=v.y+(e-v.y)*E,Y=v.s+(a-v.s)*E;$.current={x:z,y:S,s:Y},X(z,S,Y),O<1&&(H=requestAnimationFrame(w))};return H=requestAnimationFrame(w),()=>cancelAnimationFrame(H)},[t,e,a,x,W,s]),u.jsxs(u.Fragment,{children:[u.jsx("div",{ref:p,className:i,style:{display:"inline-block",...n,willChange:"transform"},children:l}),f.portal&&c&&Qa.createPortal(h0(c,{transformBox:"fill-box",transformOrigin:"center",willChange:"transform"},M=>{if(b.current=M,M){const v=$.current??{x:t,y:e,s:a};M.style.transform=`translate(${v.x}px, ${v.y}px)`+(v.s!==1?` scale(${v.s})`:"")}}),f.portal)]})}function h0(t,e,a){const[r,s,o,i]=t.r;if(r===s&&s===o&&o===i){const l=Math.max(0,Math.min(r,Math.min(t.w,t.h)/2));return u.jsx("rect",{ref:a,x:t.x,y:t.y,width:t.w,height:t.h,rx:l,style:e})}return u.jsx("path",{ref:a,d:Qi(t.x,t.y,t.w,t.h,t.r),style:e})}function u0({radius:t,blobInset:e,bridgeGrow:a,contactBlur:r,effect:s,evolve:o,move:i,className:n,style:l,children:f,ctx:p}){const b=C.useRef(null),c=C.useRef(null),d=C.useRef(null),m=C.useRef(null),k=typeof r=="object"?r:{},x=k.blur??8,W=k.warp??26,y=k.pull??4,$=k.range,X=k.zone,M=k.mix??0,v=k.gravity??60,h=k.taper??1,g=k.warpFreq??1.7,H=k.flowSpeed??22,w=k.warpStyle??"fractalNoise",A=k.detail??2,O=k.active!==!1,E=k.releaseMs??240,z=k.fadeMs,S=k.strength??1,Y=k.sink,D=k.surface,P=k.seamBlur,L=Uo(s),j={evolve:L.includes("evolve"),move:L.includes("move"),evolveOpts:{...ke,...o},moveOpts:{...et,...i}},T=j.evolve||j.move,R=t==null?"":JSON.stringify(t),I=r?`${x}/${W}/${y}/${$??"auto"}/${X??"auto"}/${M}/${v}/${h}/${g}/${H}/${w}/${A}/${D??"liquid"}/${(P??1)>0?"seam":"noseam"}`:"",_=L.join(",")+(j.evolve?JSON.stringify(j.evolveOpts):"")+(j.move?JSON.stringify(j.moveOpts):"");return Ra(()=>{const V=b.current,G=c.current,ae=(V==null?void 0:V.firstElementChild)??null;if(!ae||!G)return;const Q=r&&d.current?{host:d.current,blur:x,warp:W,pull:y,range:$,zone:X,mix:M,gravity:v,taper:h,warpFreq:g,flowSpeed:H,warpStyle:w,detail:A,active:O,releaseMs:E,fadeMs:z,strength:S,sink:Y,surface:D,seamBlur:P}:void 0;return m.current=Q??null,p.engine.add({target:ae,blob:G,radius:t==null?void 0:Go(t)[0],blobInset:e,bridgeGrow:a,blend:Q,dynamics:T?j:void 0})},[p,R,I,_,e,a]),C.useEffect(()=>{m.current&&(m.current.active=O,m.current.releaseMs=E,m.current.fadeMs=z,m.current.strength=S,m.current.sink=Y,m.current.seamBlur=P,p.engine.wake())},[p,O,E,z,S,Y,P]),u.jsxs(u.Fragment,{children:[u.jsx("span",{ref:b,className:n,style:{display:"contents",...l},children:f}),p.portal&&Qa.createPortal(u.jsx("rect",{ref:c,x:0,y:0,width:0,height:0,style:{willChange:"transform",transformBox:"fill-box",transformOrigin:"center"}}),p.portal),r!==void 0&&r!==!1&&p.meltPortal&&Qa.createPortal(u.jsx("g",{ref:d,opacity:0}),p.meltPortal)]})}function Ca(t){return Math.max(.12,1-1.1*Math.min(1,Math.max(0,t)))}function g0(t){const e=Math.max(.25,(t==null?void 0:t.speed)??1),a=Ca((t==null?void 0:t.bounce)??.5)/Ca(.5);return{massStiffness:ke.massStiffness*e*e,massDamping:ke.massDamping*e*a,sizeStiffness:ke.sizeStiffness*e*e,sizeDamping:ke.sizeDamping*e*a,radiusStiffness:ke.radiusStiffness*e*e,radiusDamping:ke.radiusDamping*e,cornerDuration:ke.cornerDuration/e,contentBlur:(t==null?void 0:t.contentBlur)??ke.contentBlur}}function wo(t){return{warp:26,blur:8,mix:.7,gravity:60,taper:1,warpFreq:1.7,flowSpeed:22,detail:2,zone:18,range:49,releaseMs:110,strength:typeof t=="number"?Math.min(1,Math.max(0,t)):1}}function Ko(t){const e=Math.min(1,Math.max(0,(t==null?void 0:t.springiness)??.5)),a=et.stiffness*Math.pow(10,e-.5),r=et.damping*Math.sqrt(a/et.stiffness)*(Ca((t==null?void 0:t.wobble)??.5)/Ca(.5));return{stiffness:a,damping:r,stretch:.5*Math.min(1,Math.max(0,(t==null?void 0:t.stretch)??.36)),tail:.8*Math.min(1,Math.max(0,(t==null?void 0:t.trail)??.575)),...t==null?void 0:t.advanced}}function m0(t){return{...Ko({springiness:1,stretch:0,trail:0}),bend:Math.min(1,Math.max(0,(t==null?void 0:t.vertical)??.6)),bendX:Math.min(1,Math.max(0,(t==null?void 0:t.horizontal)??.35)),...t==null?void 0:t.advanced}}function x0({melt:t,children:e}){const{imageMelt:a}=xr(),{src:r,...s}=t??{};return u.jsx(_i,{src:r,opts:{...qi,...s},registry:a,children:e})}function $0(t){const{effect:e="morph",morph:a,move:r,bend:s,melt:o,dissolve:i,observe:n,...l}=t;if(e==="melt")return u.jsx(x0,{melt:o,children:l.children});if(e==="bend")return u.jsx(Ja,{...l,observe:!0,effect:"move",move:m0(s)});if(e==="move")return u.jsx(Ja,{...l,observe:!0,effect:"move",move:Ko(r)});const f=a==null?void 0:a.advanced,p=!!(a!=null&&a.shape),c=i!==void 0&&i!==!1?typeof i=="object"?{...wo(!0),...i}:wo(i):void 0,d=p?{...g0(a),...f==null?void 0:f.evolve}:void 0;return u.jsx(Ja,{...l,observe:n||p||!!c||void 0,effect:p?"evolve":void 0,evolve:d,contactBlur:c,blobInset:f==null?void 0:f.blobInset,bridgeGrow:f==null?void 0:f.bridgeGrow})}var Za=Object.assign(i0,{Item:$0});function $r(){const[t,e]=C.useState(()=>typeof window<"u"&&window.matchMedia?window.matchMedia("(prefers-reduced-motion: reduce)").matches:!1);return C.useEffect(()=>{if(!window.matchMedia)return;const a=window.matchMedia("(prefers-reduced-motion: reduce)"),r=()=>e(a.matches);return a.addEventListener("change",r),()=>a.removeEventListener("change",r)},[]),t}function vr(){return cs().scheme}function _o(){const t=Ir(r=>r.theme),e=Ir(r=>r.mode),a=ls(t,e);return a==="cute"?"candy":a==="night"?"colorful":"ocean"}function y0({children:t,active:e=!0,size:a="md",className:r,strength:s=.9}){const o=$r(),i=vr(),n=_o(),l=a==="md"||a==="sm"||a==="line";return u.jsx(Is,{size:a,theme:i,colorVariant:n,active:e&&!(o&&l),strength:s,className:r,children:t})}function w0({state:t="working",size:e=20,label:a}){const r=$r(),s=vr();return u.jsx(En,{state:t,size:e,theme:s,paused:r,"aria-label":a,role:"img"})}function M0({stream:t,processing:e,children:a,className:r}){const s=vr(),o=_o();return u.jsx(Li,{stream:t,processing:e,theme:s,colorVariant:o,strength:.9,className:r,children:a})}function z0(t,e="0 0 0"){return`rgb(${(getComputedStyle(document.documentElement).getPropertyValue(`--${t}`).trim()||e).split(/\s+/).join(",")})`}function k0({left:t,right:e,merged:a,fill:r}){const s=$r(),o=a?34:70;return u.jsxs("div",{className:"relative mx-auto h-36 w-72 [&>div:first-child>div]:[grid-area:1/1] [&>div:first-child]:grid [&>div:first-child]:h-full [&>div:first-child]:place-items-center",children:[u.jsxs(Za,{fill:r,blur:10,contrast:20,children:[u.jsx(Za.Item,{x:-o,transition:s?{duration:0,ease:"linear"}:"bouncy",children:u.jsx("div",{className:"h-28 w-28 rounded-full"})}),u.jsx(Za.Item,{x:o,transition:s?{duration:0,ease:"linear"}:"bouncy",delay:80,children:u.jsx("div",{className:"h-28 w-28 rounded-full"})})]}),u.jsx("div",{className:"absolute left-1/2 top-1/2 h-24 w-24 -translate-y-1/2 overflow-hidden rounded-full ring-4 ring-surface transition-transform duration-700",style:{transform:`translate(calc(-50% - ${o}px), -50%)`},children:t}),u.jsx("div",{className:"absolute left-1/2 top-1/2 h-24 w-24 -translate-y-1/2 overflow-hidden rounded-full ring-4 ring-surface transition-transform duration-700",style:{transform:`translate(calc(-50% + ${o}px), -50%)`},children:e})]})}export{y0 as B,k0 as M,w0 as T,M0 as V,vr as a,z0 as c,$r as u};
