import{r as z,j as se,dy as pr}from"./index-ChaQPnFI.js";import{u as gr,a as xr}from"./Fx-B0XWxfuT.js";function Jt(e){let t=e.replace("#","");(t.length===3||t.length===4)&&(t=t.split("").map(n=>n+n).join(""));const r=t.length>=8?parseInt(t.slice(6,8),16)/255:1;return[parseInt(t.slice(0,2),16)/255,parseInt(t.slice(2,4),16)/255,parseInt(t.slice(4,6),16)/255,r]}function Io(e,t,r){e/=255,t/=255,r/=255;const n=Math.max(e,t,r),o=Math.min(e,t,r),i=n-o;let a=0;const l=n===0?0:i/n;return i!==0&&(n===e?a=((t-r)/i+6)%6:n===t?a=(r-e)/i+2:a=(e-t)/i+4,a/=6),[a,l,n]}function Fo(e,t,r){const n=Math.floor(e*6),o=e*6-n,i=r*(1-t),a=r*(1-o*t),l=r*(1-(1-o)*t);let s=0,c=0,u=0;switch(n%6){case 0:s=r,c=l,u=i;break;case 1:s=a,c=r,u=i;break;case 2:s=i,c=r,u=l;break;case 3:s=i,c=a,u=r;break;case 4:s=l,c=i,u=r;break;case 5:s=r,c=i,u=a;break}return[Math.round(s*255),Math.round(c*255),Math.round(u*255)]}const vr=66,wr=66,br=1500,yr=1,Kt=16,Mr=96,_r=2,Rr=0,Cr=1,Ve={colorBack:"#00000000",speed:1,repetition:1.5,softness:.05,shiftRed:.3,shiftBlue:.3,distortion:.1,contour:.4,angle:90,shape:Rr,scale:1,rotation:0,offsetX:0,offsetY:0,originX:.5,originY:.5,worldWidth:0,worldHeight:0,fit:Cr},Sr={name:"chromatic",modes:{dark:{...Ve,colorTint:"#88ccff2e",shiftRed:.75,shiftBlue:.75,repetition:2,softness:.09,shaderOpacity:1},light:{...Ve,colorTint:"#66b0ff99",shiftRed:.6,shiftBlue:.6,shaderOpacity:1}}},kr={name:"silver",modes:{dark:{...Ve,colorTint:"#ffffff66",shaderOpacity:.88},light:{...Ve,colorTint:"#ffffff40",shaderOpacity:1}}},Tr={name:"gold",modes:{dark:{...Ve,colorTint:"#ffcc55cc",speed:.85,shaderOpacity:.92},light:{...Ve,colorTint:"#f7d488aa",shaderOpacity:1}}},Gt={chromatic:Sr,silver:kr,gold:Tr},Er=`
#define TWO_PI 6.28318530718
#define PI 3.14159265358979323846
`,Br=`
vec2 rotate(vec2 uv, float th) {
  return mat2(cos(th), sin(th), -sin(th), cos(th)) * uv;
}
`,Or=`
  color += 1. / 256. * (fract(sin(dot(.014 * gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453123) - .5);
`,Ar=`
vec3 permute(vec3 x) { return mod(((x * 34.0) + 1.0) * x, 289.0); }
float snoise(vec2 v) {
  const vec4 C = vec4(0.211324865405187, 0.366025403784439,
    -0.577350269189626, 0.024390243902439);
  vec2 i = floor(v + dot(v, C.yy));
  vec2 x0 = v - i + dot(i, C.xx);
  vec2 i1;
  i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec4 x12 = x0.xyxy + C.xxzz;
  x12.xy -= i1;
  i = mod(i, 289.0);
  vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0))
    + i.x + vec3(0.0, i1.x, 1.0));
  vec3 m = max(0.5 - vec3(dot(x0, x0), dot(x12.xy, x12.xy),
      dot(x12.zw, x12.zw)), 0.0);
  m = m * m;
  m = m * m;
  vec3 x = 2.0 * fract(p * C.www) - 1.0;
  vec3 h = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.79284291400159 - 0.85373472095314 * (a0 * a0 + h * h);
  vec3 g;
  g.x = a0.x * x0.x + h.x * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}
`,Ir=`#version 300 es
precision mediump float;

uniform sampler2D u_image;
uniform float u_imageAspectRatio;

uniform vec2 u_resolution;
uniform float u_time;

uniform vec4 u_colorBack;
uniform vec4 u_colorTint;

uniform float u_softness;
uniform float u_repetition;
uniform float u_shiftRed;
uniform float u_shiftBlue;
uniform float u_distortion;
uniform float u_contour;
uniform float u_angle;

uniform float u_shape;
uniform bool u_isImage;

in vec2 v_objectUV;
in vec2 v_responsiveUV;
in vec2 v_responsiveBoxGivenSize;
in vec2 v_imageUV;

out vec4 fragColor;

${Er}
${Br}
${Ar}

float getColorChanges(float c1, float c2, float stripe_p, vec3 w, float blur, float bump, float tint) {

  float ch = mix(c2, c1, smoothstep(.0, 2. * blur, stripe_p));

  float border = w[0];
  ch = mix(ch, c2, smoothstep(border, border + 2. * blur, stripe_p));

  if (u_isImage == true) {
    bump = smoothstep(.2, .8, bump);
  }
  border = w[0] + .4 * (1. - bump) * w[1];
  ch = mix(ch, c1, smoothstep(border, border + 2. * blur, stripe_p));

  border = w[0] + .5 * (1. - bump) * w[1];
  ch = mix(ch, c2, smoothstep(border, border + 2. * blur, stripe_p));

  border = w[0] + w[1];
  ch = mix(ch, c1, smoothstep(border, border + 2. * blur, stripe_p));

  float gradient_t = (stripe_p - w[0] - w[1]) / w[2];
  float gradient = mix(c1, c2, smoothstep(0., 1., gradient_t));
  ch = mix(ch, gradient, smoothstep(border, border + .5 * blur, stripe_p));

  // Tint color is applied with color burn blending
  ch = mix(ch, 1. - min(1., (1. - ch) / max(tint, 0.0001)), u_colorTint.a);
  return ch;
}

float getImgFrame(vec2 uv, float th) {
  float frame = 1.;
  frame *= smoothstep(0., th, uv.y);
  frame *= 1.0 - smoothstep(1. - th, 1., uv.y);
  frame *= smoothstep(0., th, uv.x);
  frame *= 1.0 - smoothstep(1. - th, 1., uv.x);
  return frame;
}

float blurEdge3x3(sampler2D tex, vec2 uv, vec2 dudx, vec2 dudy, float radius, float centerSample) {
  vec2 texel = 1.0 / vec2(textureSize(tex, 0));
  vec2 r = radius * texel;

  float w1 = 1.0, w2 = 2.0, w4 = 4.0;
  float norm = 16.0;
  float sum = w4 * centerSample;

  sum += w2 * textureGrad(tex, uv + vec2(0.0, -r.y), dudx, dudy).r;
  sum += w2 * textureGrad(tex, uv + vec2(0.0, r.y), dudx, dudy).r;
  sum += w2 * textureGrad(tex, uv + vec2(-r.x, 0.0), dudx, dudy).r;
  sum += w2 * textureGrad(tex, uv + vec2(r.x, 0.0), dudx, dudy).r;

  sum += w1 * textureGrad(tex, uv + vec2(-r.x, -r.y), dudx, dudy).r;
  sum += w1 * textureGrad(tex, uv + vec2(r.x, -r.y), dudx, dudy).r;
  sum += w1 * textureGrad(tex, uv + vec2(-r.x, r.y), dudx, dudy).r;
  sum += w1 * textureGrad(tex, uv + vec2(r.x, r.y), dudx, dudy).r;

  return sum / norm;
}

float lst(float edge0, float edge1, float x) {
  return clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
}

void main() {

  const float firstFrameOffset = 2.8;
  float t = .3 * (u_time + firstFrameOffset);

  vec2 uv = v_imageUV;
  vec2 dudx = dFdx(v_imageUV);
  vec2 dudy = dFdy(v_imageUV);
  vec4 img = textureGrad(u_image, uv, dudx, dudy);

  if (u_isImage == false) {
    uv = v_objectUV + .5;
    uv.y = 1. - uv.y;
  }

  float cycleWidth = u_repetition;
  float edge = 0.;
  float contOffset = 1.;

  vec2 rotatedUV = uv - vec2(.5);
  float angle = (-u_angle + 70.) * PI / 180.;
  float cosA = cos(angle);
  float sinA = sin(angle);
  rotatedUV = vec2(
  rotatedUV.x * cosA - rotatedUV.y * sinA,
  rotatedUV.x * sinA + rotatedUV.y * cosA
  ) + vec2(.5);

  if (u_isImage == true) {
    float edgeRaw = img.r;
    edge = blurEdge3x3(u_image, uv, dudx, dudy, 6., edgeRaw);
    edge = pow(edge, 1.6);
    edge *= mix(0.0, 1.0, smoothstep(0.0, 0.4, u_contour));
  } else {
    if (u_shape < 1.) {
      // full-fill on canvas
      vec2 borderUV = v_responsiveUV + .5;
      float ratio = v_responsiveBoxGivenSize.x / v_responsiveBoxGivenSize.y;
      vec2 mask = min(borderUV, 1. - borderUV);
      vec2 pixel_thickness = min(250. / v_responsiveBoxGivenSize, vec2(.5));
      float maskX = smoothstep(0.0, pixel_thickness.x, mask.x);
      float maskY = smoothstep(0.0, pixel_thickness.y, mask.y);
      maskX = pow(maskX, .25);
      maskY = pow(maskY, .25);
      edge = clamp(1. - maskX * maskY, 0., 1.);

      uv = v_responsiveUV;
      if (ratio > 1.) {
        uv.y /= ratio;
      } else {
        uv.x *= ratio;
      }
      uv += .5;
      uv.y = 1. - uv.y;

      cycleWidth *= 2.;
      contOffset = 1.5;

    } else if (u_shape < 2.) {
      // circle
      vec2 shapeUV = uv - .5;
      shapeUV *= .67;
      edge = pow(clamp(3. * length(shapeUV), 0., 1.), 18.);
    } else if (u_shape < 3.) {
      // daisy
      vec2 shapeUV = uv - .5;
      shapeUV *= 1.68;

      float r = length(shapeUV) * 2.;
      float a = atan(shapeUV.y, shapeUV.x) + .2;
      r *= (1. + .05 * sin(3. * a + 2. * t));
      float f = abs(cos(a * 3.));
      edge = smoothstep(f, f + .7, r);
      edge *= edge;

      uv *= .8;
      cycleWidth *= 1.6;

    } else if (u_shape < 4.) {
      // diamond
      vec2 shapeUV = uv - .5;
      shapeUV = rotate(shapeUV, .25 * PI);
      shapeUV *= 1.42;
      shapeUV += .5;
      vec2 mask = min(shapeUV, 1. - shapeUV);
      vec2 pixel_thickness = vec2(.15);
      float maskX = smoothstep(0.0, pixel_thickness.x, mask.x);
      float maskY = smoothstep(0.0, pixel_thickness.y, mask.y);
      maskX = pow(maskX, .25);
      maskY = pow(maskY, .25);
      edge = clamp(1. - maskX * maskY, 0., 1.);
    } else if (u_shape < 5.) {
      // metaballs
      vec2 shapeUV = uv - .5;
      shapeUV *= 1.3;
      edge = 0.;
      for (int i = 0; i < 5; i++) {
        float fi = float(i);
        float speed = 1.5 + 2./3. * sin(fi * 12.345);
        float angle = -fi * 1.5;
        vec2 dir1 = vec2(cos(angle), sin(angle));
        vec2 dir2 = vec2(cos(angle + 1.57), sin(angle + 1.));
        vec2 traj = .4 * (dir1 * sin(t * speed + fi * 1.23) + dir2 * cos(t * (speed * 0.7) + fi * 2.17));
        float d = length(shapeUV + traj);
        edge += pow(1.0 - clamp(d, 0.0, 1.0), 4.0);
      }
      edge = 1. - smoothstep(.65, .9, edge);
      edge = pow(edge, 4.);
    }

    edge = mix(smoothstep(.9 - 2. * fwidth(edge), .9, edge), edge, smoothstep(0.0, 0.4, u_contour));

  }

  float opacity = 0.;
  if (u_isImage == true) {
    opacity = img.g;
    float frame = getImgFrame(v_imageUV, 0.);
    opacity *= frame;
  } else {
    opacity = 1. - smoothstep(.9 - 2. * fwidth(edge), .9, edge);
    if (u_shape < 2.) {
      edge = 1.2 * edge;
    } else if (u_shape < 5.) {
      edge = 1.8 * pow(edge, 1.5);
    }
  }

  float diagBLtoTR = rotatedUV.x - rotatedUV.y;
  float diagTLtoBR = rotatedUV.x + rotatedUV.y;

  vec3 color = vec3(0.);
  vec3 color1 = vec3(.98, 0.98, 1.);
  vec3 color2 = vec3(.1, .1, .1 + .1 * smoothstep(.7, 1.3, diagTLtoBR));

  vec2 grad_uv = uv - .5;

  float dist = length(grad_uv + vec2(0., .2 * diagBLtoTR));
  grad_uv = rotate(grad_uv, (.25 - .2 * diagBLtoTR) * PI);
  float direction = grad_uv.x;

  float bump = pow(1.8 * dist, 1.2);
  bump = 1. - bump;
  bump *= pow(uv.y, .3);


  float thin_strip_1_ratio = .12 / cycleWidth * (1. - .4 * bump);
  float thin_strip_2_ratio = .07 / cycleWidth * (1. + .4 * bump);
  float wide_strip_ratio = (1. - thin_strip_1_ratio - thin_strip_2_ratio);

  float thin_strip_1_width = cycleWidth * thin_strip_1_ratio;
  float thin_strip_2_width = cycleWidth * thin_strip_2_ratio;

  float noise = snoise(uv - t);

  edge += (1. - edge) * u_distortion * noise;

  direction += diagBLtoTR;
  float contour = 0.;
  direction -= 2. * noise * diagBLtoTR * (smoothstep(0., 1., edge) * (1.0 - smoothstep(0., 1., edge)));
  direction *= mix(1., 1. - edge, smoothstep(.5, 1., u_contour));
  direction -= 1.7 * edge * smoothstep(.5, 1., u_contour);
  direction += .2 * pow(u_contour, 4.) * (1.0 - smoothstep(0., 1., edge));

  bump *= clamp(pow(uv.y, .1), .3, 1.);
  direction *= (.1 + (1.1 - edge) * bump);

  direction *= (.4 + .6 * (1.0 - smoothstep(.5, 1., edge)));
  direction += .18 * (smoothstep(.1, .2, uv.y) * (1.0 - smoothstep(.2, .4, uv.y)));
  direction += .03 * (smoothstep(.1, .2, 1. - uv.y) * (1.0 - smoothstep(.2, .4, 1. - uv.y)));

  direction *= (.5 + .5 * pow(uv.y, 2.));
  direction *= cycleWidth;
  direction -= t;


  float colorDispersion = (1. - bump);
  colorDispersion = clamp(colorDispersion, 0., 1.);
  float dispersionRed = colorDispersion;
  dispersionRed += .03 * bump * noise;
  dispersionRed += 5. * (smoothstep(-.1, .2, uv.y) * (1.0 - smoothstep(.1, .5, uv.y))) * (smoothstep(.4, .6, bump) * (1.0 - smoothstep(.4, 1., bump)));
  dispersionRed -= diagBLtoTR;

  float dispersionBlue = colorDispersion;
  dispersionBlue *= 1.3;
  dispersionBlue += (smoothstep(0., .4, uv.y) * (1.0 - smoothstep(.1, .8, uv.y))) * (smoothstep(.4, .6, bump) * (1.0 - smoothstep(.4, .8, bump)));
  dispersionBlue -= .2 * edge;

  dispersionRed *= (u_shiftRed / 20.);
  dispersionBlue *= (u_shiftBlue / 20.);

  float blur = 0.;
  float rExtraBlur = 0.;
  float gExtraBlur = 0.;
  if (u_isImage == true) {
    float softness = 0.05 * u_softness;
    blur = softness + .5 * smoothstep(1., 10., u_repetition) * smoothstep(.0, 1., edge);
    float smallCanvasT = 1.0 - smoothstep(100., 500., min(u_resolution.x, u_resolution.y));
    blur += smallCanvasT * smoothstep(.0, 1., edge);
    rExtraBlur = softness * (0.05 + .1 * (u_shiftRed / 20.) * bump);
    gExtraBlur = softness * 0.05 / max(0.001, abs(1. - diagBLtoTR));
  } else {
    blur = u_softness / 15. + .3 * contour;
  }

  vec3 w = vec3(thin_strip_1_width, thin_strip_2_width, wide_strip_ratio);
  w[1] -= .02 * smoothstep(.0, 1., edge + bump);
  float stripe_r = fract(direction + dispersionRed);
  float r = getColorChanges(color1.r, color2.r, stripe_r, w, blur + fwidth(stripe_r) + rExtraBlur, bump, u_colorTint.r);
  float stripe_g = fract(direction);
  float g = getColorChanges(color1.g, color2.g, stripe_g, w, blur + fwidth(stripe_g) + gExtraBlur, bump, u_colorTint.g);
  float stripe_b = fract(direction - dispersionBlue);
  float b = getColorChanges(color1.b, color2.b, stripe_b, w, blur + fwidth(stripe_b), bump, u_colorTint.b);

  color = vec3(r, g, b);
  color *= opacity;

  vec3 bgColor = u_colorBack.rgb * u_colorBack.a;
  color = color + bgColor * (1. - opacity);
  opacity = opacity + u_colorBack.a * (1. - opacity);

  ${Or}

  fragColor = vec4(color, opacity);
}
`,Fr=`#version 300 es
precision mediump float;

layout(location = 0) in vec4 a_position;

uniform vec2 u_resolution;
uniform float u_pixelRatio;
uniform float u_imageAspectRatio;
uniform float u_originX;
uniform float u_originY;
uniform float u_worldWidth;
uniform float u_worldHeight;
uniform float u_fit;
uniform float u_scale;
uniform float u_rotation;
uniform float u_offsetX;
uniform float u_offsetY;

out vec2 v_objectUV;
out vec2 v_objectBoxSize;
out vec2 v_responsiveUV;
out vec2 v_responsiveBoxGivenSize;
out vec2 v_patternUV;
out vec2 v_patternBoxSize;
out vec2 v_imageUV;

vec3 getBoxSize(float boxRatio, vec2 givenBoxSize) {
  vec2 box = vec2(0.);
  // fit = none
  box.x = boxRatio * min(givenBoxSize.x / boxRatio, givenBoxSize.y);
  float noFitBoxWidth = box.x;
  if (u_fit == 1.) { // fit = contain
    box.x = boxRatio * min(u_resolution.x / boxRatio, u_resolution.y);
  } else if (u_fit == 2.) { // fit = cover
    box.x = boxRatio * max(u_resolution.x / boxRatio, u_resolution.y);
  }
  box.y = box.x / boxRatio;
  return vec3(box, noFitBoxWidth);
}

void main() {
  gl_Position = a_position;

  vec2 uv = gl_Position.xy * .5;
  vec2 boxOrigin = vec2(.5 - u_originX, u_originY - .5);
  vec2 givenBoxSize = vec2(u_worldWidth, u_worldHeight);
  givenBoxSize = max(givenBoxSize, vec2(1.)) * u_pixelRatio;
  float r = u_rotation * 3.14159265358979323846 / 180.;
  mat2 graphicRotation = mat2(cos(r), sin(r), -sin(r), cos(r));
  vec2 graphicOffset = vec2(-u_offsetX, u_offsetY);


  // ===================================================

  float fixedRatio = 1.;
  vec2 fixedRatioBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );

  v_objectBoxSize = getBoxSize(fixedRatio, fixedRatioBoxGivenSize).xy;
  vec2 objectWorldScale = u_resolution.xy / v_objectBoxSize;

  v_objectUV = uv;
  v_objectUV *= objectWorldScale;
  v_objectUV += boxOrigin * (objectWorldScale - 1.);
  v_objectUV += graphicOffset;
  v_objectUV /= u_scale;
  v_objectUV = graphicRotation * v_objectUV;

  // ===================================================

  v_responsiveBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  float responsiveRatio = v_responsiveBoxGivenSize.x / v_responsiveBoxGivenSize.y;
  vec2 responsiveBoxSize = getBoxSize(responsiveRatio, v_responsiveBoxGivenSize).xy;
  vec2 responsiveBoxScale = u_resolution.xy / responsiveBoxSize;

  v_responsiveUV = uv;
  v_responsiveUV *= responsiveBoxScale;
  v_responsiveUV += boxOrigin * (responsiveBoxScale - 1.);
  v_responsiveUV += graphicOffset;
  v_responsiveUV /= u_scale;
  v_responsiveUV.x *= responsiveRatio;
  v_responsiveUV = graphicRotation * v_responsiveUV;
  v_responsiveUV.x /= responsiveRatio;

  // ===================================================

  float patternBoxRatio = givenBoxSize.x / givenBoxSize.y;
  vec2 patternBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  patternBoxRatio = patternBoxGivenSize.x / patternBoxGivenSize.y;

  vec3 boxSizeData = getBoxSize(patternBoxRatio, patternBoxGivenSize);
  v_patternBoxSize = boxSizeData.xy;
  float patternBoxNoFitBoxWidth = boxSizeData.z;
  vec2 patternBoxScale = u_resolution.xy / v_patternBoxSize;

  v_patternUV = uv;
  v_patternUV += graphicOffset / patternBoxScale;
  v_patternUV += boxOrigin;
  v_patternUV -= boxOrigin / patternBoxScale;
  v_patternUV *= u_resolution.xy;
  v_patternUV /= u_pixelRatio;
  if (u_fit > 0.) {
    v_patternUV *= (patternBoxNoFitBoxWidth / v_patternBoxSize.x);
  }
  v_patternUV /= u_scale;
  v_patternUV = graphicRotation * v_patternUV;
  v_patternUV += boxOrigin / patternBoxScale;
  v_patternUV -= boxOrigin;
  // x100 is a default multiplier between vertex and fragmant shaders
  // we use it to avoid UV presision issues
  v_patternUV *= .01;

  // ===================================================

  vec2 imageBoxSize;
  if (u_fit == 1.) { // contain
    imageBoxSize.x = min(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else if (u_fit == 2.) { // cover
    imageBoxSize.x = max(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else {
    imageBoxSize.x = min(10.0, 10.0 / u_imageAspectRatio * u_imageAspectRatio);
  }
  imageBoxSize.y = imageBoxSize.x / u_imageAspectRatio;
  vec2 imageBoxScale = u_resolution.xy / imageBoxSize;

  v_imageUV = uv;
  v_imageUV *= imageBoxScale;
  v_imageUV += boxOrigin * (imageBoxScale - 1.);
  v_imageUV += graphicOffset;
  v_imageUV /= u_scale;
  v_imageUV.x *= u_imageAspectRatio;
  v_imageUV = graphicRotation * v_imageUV;
  v_imageUV.x /= u_imageAspectRatio;

  v_imageUV += .5;
  v_imageUV.y = 1. - v_imageUV.y;
}`,Pr=Ir;function Zt(e,t,r){const n=e.createShader(t);if(!n)throw new Error("metal-fx: gl.createShader returned null");if(e.shaderSource(n,r),e.compileShader(n),!e.getShaderParameter(n,e.COMPILE_STATUS)){const o=e.getShaderInfoLog(n);throw e.deleteShader(n),new Error(`metal-fx: shader compile failed: ${o??"(no info log)"}`)}return n}function Lr(e,t,r){const n=e.createProgram();if(!n)throw new Error("metal-fx: gl.createProgram returned null");if(e.attachShader(n,t),e.attachShader(n,r),e.linkProgram(n),!e.getProgramParameter(n,e.LINK_STATUS)){const o=e.getProgramInfoLog(n);throw e.deleteProgram(n),new Error(`metal-fx: program link failed: ${o??"(no info log)"}`)}return n}const Po=140,Lo=40,Uo=1.6,zo=1.3;let x=null,Oe=null;function Ur(){var e;if(Oe!==null)return Oe;if(typeof document>"u")return Oe=!1;try{const t=document.createElement("canvas").getContext("webgl2");Oe=!!t,(e=t==null?void 0:t.getExtension("WEBGL_lose_context"))==null||e.loseContext()}catch{Oe=!1}return Oe}let St=null;function zr(e){St=e}const Nr=["u_resolution","u_time","u_pixelRatio","u_colorBack","u_colorTint","u_repetition","u_softness","u_shiftRed","u_shiftBlue","u_distortion","u_contour","u_angle","u_shape","u_isImage","u_image","u_originX","u_originY","u_worldWidth","u_worldHeight","u_fit","u_scale","u_rotation","u_offsetX","u_offsetY","u_imageAspectRatio"];function eo(e){e.enable(e.BLEND),e.blendFunc(e.ONE,e.ONE_MINUS_SRC_ALPHA);const t=Zt(e,e.VERTEX_SHADER,Fr),r=Zt(e,e.FRAGMENT_SHADER,Pr),n=Lr(e,t,r);e.useProgram(n);const o=e.createBuffer();if(!o)throw new Error("metal-fx: gl.createBuffer returned null");e.bindBuffer(e.ARRAY_BUFFER,o),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),e.STATIC_DRAW);const i=e.getAttribLocation(n,"a_position");e.enableVertexAttribArray(i),e.vertexAttribPointer(i,2,e.FLOAT,!1,0,0);const a={};for(const s of Nr)a[s]=e.getUniformLocation(n,s);const l=e.createTexture();return l&&(e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,l),e.texImage2D(e.TEXTURE_2D,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,new Uint8Array([0,0,0,255])),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),a.u_image&&e.uniform1i(a.u_image,0)),{program:n,buffer:o,uniforms:a,dummyTexture:l}}function Ht(){if(x)return x;const e=Math.min(_r,typeof window<"u"&&window.devicePixelRatio||1),t=Math.round(Mr*e),r=typeof OffscreenCanvas<"u";let n,o;if(r)n=new OffscreenCanvas(t,t),o=n.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1});else{const d=document.createElement("canvas");d.width=t,d.height=t,o=d.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1,preserveDrawingBuffer:!0}),n=d}if(!o)throw new Error("metal-fx: WebGL2 not supported");const{program:i,buffer:a,uniforms:l,dummyTexture:s}=eo(o),c=d=>{d.preventDefault(),x&&(x.contextLost=!0)},u=()=>{if(!x)return;const d=eo(x.gl);x.program=d.program,x.buffer=d.buffer,x.uniforms=d.uniforms,x.dummyTexture=d.dummyTexture,x.presetDirty=!0,x.contextLost=!1,St==null||St()};return n.addEventListener("webglcontextlost",c,!1),n.addEventListener("webglcontextrestored",u,!1),x={glCanvas:n,gl:o,program:i,buffer:a,uniforms:l,dummyTexture:s,preset:Gt.chromatic.modes.dark,presetDirty:!0,contextLost:!1,useOffscreen:r,frameBitmap:null,startMs:performance.now(),pausedMs:0,pausedAtMs:null,rafId:0,dpr:e,instances:new Set,frameCount:0,glowQueue:[],glowIdx:0,glowSkip:0,glowPixels:new Uint8Array(t*t*4),glowPixelsW:t,glowPixelsH:t},x}function Vr(){var e;if(!x)return;const{gl:t,program:r,buffer:n,frameBitmap:o,dummyTexture:i}=x;try{o==null||o.close(),t.deleteBuffer(n),t.deleteProgram(r),i&&t.deleteTexture(i),(e=t.getExtension("WEBGL_lose_context"))==null||e.loseContext()}catch{}x=null}let to=0;function Wr(){if(!x)return;const e=performance.now();if(e-to<br)return;to=e;const{gl:t,glCanvas:r}=x,n=r.width,o=r.height;(x.glowPixelsW!==n||x.glowPixelsH!==o)&&(x.glowPixelsW=n,x.glowPixelsH=o,x.glowPixels=new Uint8Array(n*o*4)),t.readPixels(0,0,n,o,t.RGBA,t.UNSIGNED_BYTE,x.glowPixels)}const Ae={bx:0,by:0};function $t(e,t,r){if(!x)return Ae.bx=0,Ae.by=0,Ae;const{glCanvas:n}=x,o=n.width,i=n.height,a=e.dpr,l=e.cssWidth*a,s=e.cssHeight*a,c=Po*a,u=Lo*a;let d=l*(o/c)/e.shaderScale,f=s*(i/u)/e.shaderScale;d>o&&(d=o),f>i&&(f=i);const m=(o-d)/2,g=(i-f)/2,p=m+t/e.cssWidth*d,M=g+r/e.cssHeight*f;return Ae.bx=Math.round(p),Ae.by=Math.round(i-1-M),Ae}const ce={r:0,g:0,b:0,lum:0,count:0};function No(e,t,r,n,o,i){const a=Math.max(1,i|0),l=Math.max(0,n-a),s=Math.min(t,n+a+1),c=Math.max(0,o-a),u=Math.min(r,o+a+1);ce.r=0,ce.g=0,ce.b=0,ce.lum=0,ce.count=0;for(let d=c;d<u;d++){const f=d*t;for(let m=l;m<s;m++){const g=(f+m)*4;ce.r+=e[g],ce.g+=e[g+1],ce.b+=e[g+2],ce.lum+=(.2126*e[g]+.7152*e[g+1]+.0722*e[g+2])/255,ce.count++}}return ce}const J={r:255,g:255,b:255};function kt(e,t,r,n){if(!x)return 0;const o=$t(e,t,r),i=No(x.glowPixels,x.glowPixelsW,x.glowPixelsH,o.bx,o.by,n);return i.count>0?i.lum/i.count:0}function Vo(e,t,r,n){if(!x)return J.r=255,J.g=255,J.b=255,J;const o=$t(e,t,r),i=No(x.glowPixels,x.glowPixelsW,x.glowPixelsH,o.bx,o.by,n);return i.count===0?(J.r=255,J.g=255,J.b=255,J):(J.r=i.r/i.count,J.g=i.g/i.count,J.b=i.b/i.count,J)}function Dr(e,t,r,n){if(!x)return J.r=255,J.g=255,J.b=255,J;const o=$t(e,t,r),{glowPixels:i,glowPixelsW:a,glowPixelsH:l}=x,s=Math.max(1,n|0),c=Math.max(0,o.bx-s),u=Math.min(a,o.bx+s+1),d=Math.max(0,o.by-s),f=Math.min(l,o.by+s+1);let m=-1;J.r=255,J.g=255,J.b=255;for(let g=d;g<f;g++){const p=g*a;for(let M=c;M<u;M++){const b=(p+M)*4,v=i[b],h=i[b+1],y=i[b+2],w=Math.max(v,h,y),E=Math.min(v,h,y),A=(w>0?(w-E)/w:0)*(.35+.65*(w/255));A>m&&(m=A,J.r=v,J.g=h,J.b=y)}}return J}const mt=14,oo=1.5,pt={x:0,y:0};function We(e=512){return{xy:new Float32Array(e*2),n:0}}function De(e,t,r,n,o,i,a=We()){o=Math.max(0,Math.min(o,Math.min(r,n)/2));const l=4*(mt+1)+Math.ceil(2*(r+n)/oo)+8;a.xy.length<l*2&&(a.xy=new Float32Array(l*2));const s=a.xy;let c=0;const u=(m,g)=>{i?(i(m,g,pt),s[c*2]=pt.x,s[c*2+1]=pt.y):(s[c*2]=m,s[c*2+1]=g),c++},d=(m,g,p,M)=>{const b=Math.hypot(p-m,M-g),v=Math.max(1,Math.ceil(b/oo));for(let h=0;h<v;h++){const y=h/v;u(m+(p-m)*y,g+(M-g)*y)}},f=(m,g,p,M)=>{for(let b=0;b<=mt;b++){const v=p+(M-p)*(b/mt);u(m+o*Math.cos(v),g+o*Math.sin(v))}};return d(e+o,t,e+r-o,t),f(e+r-o,t+o,-Math.PI/2,0),d(e+r,t+o,e+r,t+n-o),f(e+r-o,t+n-o,0,Math.PI/2),d(e+r-o,t+n,e+o,t+n),f(e+o,t+n-o,Math.PI/2,Math.PI),d(e,t+n-o,e,t+o),f(e+o,t+o,Math.PI,1.5*Math.PI),a.n=c,a}zr(()=>{x&&x.instances.size>0&&x.pausedAtMs===null&&Ze()});typeof document<"u"&&document.addEventListener("visibilitychange",()=>{!x||x.pausedAtMs!==null||x.contextLost||(document.hidden?$o():x.instances.size>0&&Ze())});function Gr(e){const t=Ht(),r=e.hostCanvas.getContext("2d",{alpha:!0});if(!r)throw new Error("metal-fx: canvas 2D context unavailable");const n=e.scale??1,o={canvas:e.hostCanvas,ctx:r,cssWidth:e.cssWidth,cssHeight:e.cssHeight,cornerRadius:e.cornerRadius,kind:e.kind,ringCssPx:e.ringCssPx??(e.kind==="circle"?2:1)*n,shaderScale:e.shaderScale??(e.kind==="circle"?zo:Uo)*n,opacityMul:e.opacityMul??1,glowGain:e.glowGain??1,visible:!0,paused:e.paused??!1,everCopied:!1,frozen:null,dpr:typeof window<"u"&&window.devicePixelRatio||1,scale:n,onAfterFrame:e.onAfterFrame,onComposite:e.onComposite,onFirstCopy:e.onFirstCopy,mask:e.mask??null,deform:null,deformLayers:null,overscan:0,cursorLight:null,glowFast:!1,rawCanvas:null,wantRaw:!1,ringCanvas:null,wantRing:!1};return Xt(o),t.instances.add(o),t.rafId===0&&t.pausedAtMs===null&&Ze(),o}function Hr(e){if(!x)return;x.instances.delete(e);const t=x.glowQueue.indexOf(e);t!==-1&&x.glowQueue.splice(t,1),x.instances.size===0&&($o(),Vr())}function $r(e){x&&(x.glowQueue.includes(e)||x.glowQueue.push(e))}function Xr(e){if(!x)return;const t=x.glowQueue.indexOf(e);t!==-1&&x.glowQueue.splice(t,1)}function Ie(e,t){let r=!1;t.mask!==void 0&&(e.mask=t.mask),t.cssWidth!==void 0&&t.cssWidth!==e.cssWidth&&(e.cssWidth=t.cssWidth,r=!0),t.cssHeight!==void 0&&t.cssHeight!==e.cssHeight&&(e.cssHeight=t.cssHeight,r=!0),t.cornerRadius!==void 0&&(e.cornerRadius=t.cornerRadius),t.scale!==void 0&&(e.scale=t.scale),t.kind!==void 0&&t.kind!==e.kind&&(e.kind=t.kind,t.shaderScale===void 0&&(e.shaderScale=(t.kind==="circle"?zo:Uo)*e.scale),t.ringCssPx===void 0&&(e.ringCssPx=(t.kind==="circle"?2:1)*e.scale)),t.shaderScale!==void 0&&(e.shaderScale=t.shaderScale),t.ringCssPx!==void 0&&(e.ringCssPx=t.ringCssPx),t.opacityMul!==void 0&&(e.opacityMul=t.opacityMul),t.glowGain!==void 0&&(e.glowGain=t.glowGain),t.paused!==void 0&&t.paused!==e.paused&&(e.paused=t.paused,t.paused?Do(e):e.frozen=null,!t.paused&&x&&x.rafId===0&&x.pausedAtMs===null&&!x.contextLost&&Ze()),r&&Xt(e)}function Yr(e,t){e.visible=t,t&&x&&x.rafId===0&&x.pausedAtMs===null&&!x.contextLost&&Ze()}function jr(e){return(typeof window<"u"&&window.devicePixelRatio||1)===e.dpr?!1:(Xt(e),Go(e),!0)}let Wo=null;function qr(e,t){const r=Ht();r.preset=Wo??Gt[e].modes[t],r.presetDirty=!0}function ro(e){const t=Ht();Wo=e,e&&(t.preset=e,t.presetDirty=!0)}let Se=null;function Qr(e){Se=e}function gt(e,t){!Se||!x||!e.visible||e.paused||x.glowQueue.includes(e)&&(e.glowFast=!!Se(e,t))}function Xt(e){e.dpr=typeof window<"u"&&window.devicePixelRatio||1;const t=e.overscan,r=Math.max(1,Math.round((e.cssWidth+2*t)*e.dpr)),n=Math.max(1,Math.round((e.cssHeight+2*t)*e.dpr));e.canvas.width!==r&&(e.canvas.width=r),e.canvas.height!==n&&(e.canvas.height=n);const o=e.canvas.style;t>0?(o.left=`${-t}px`,o.top=`${-t}px`,o.width=`calc(100% + ${2*t}px)`,o.height=`calc(100% + ${2*t}px)`,o.borderRadius="0"):o.left!==""&&(o.left="",o.top="",o.width="100%",o.height="100%",o.borderRadius="")}function Jr(e){const{ctx:t,dpr:r,canvas:n}=e,o=e.ringCssPx*r,i=n.width,a=n.height,l=Math.max(0,(e.cornerRadius-e.ringCssPx)*r);t.save(),t.globalCompositeOperation="destination-out",t.fillStyle="#000",t.beginPath(),t.roundRect(o,o,i-2*o,a-2*o,l),t.fill(),t.restore()}const Kr=We();function Re(e,t,r,n,o,i,a,l){const{xy:s,n:c}=De(t,r,n,o,i,a,Kr);e.beginPath();for(let u=0;u<c;u++)u===0?e.moveTo(s[0]*l,s[1]*l):e.lineTo(s[u*2]*l,s[u*2+1]*l);e.closePath()}function Do(e){if(!x)return null;const t=x.frameBitmap??x.glCanvas,r=x.glCanvas.width,n=x.glCanvas.height;if(r<1||n<1)return null;let o=e.frozen;o||(o=document.createElement("canvas"),e.frozen=o),(o.width!==r||o.height!==n)&&(o.width=r,o.height=n);const i=o.getContext("2d");return i?(i.clearRect(0,0,r,n),i.drawImage(t,0,0),o):(e.frozen=null,null)}function Go(e){var t,r;if(!x)return;const n=(e.paused?e.frozen??Do(e):null)??x.frameBitmap??x.glCanvas,o=e.dpr,i=e.canvas.width,a=e.canvas.height;if(i<1||a<1)return;const l=Math.max(1,Math.round(e.cssWidth*o)),s=Math.max(1,Math.round(e.cssHeight*o)),c=e.overscan*o,u=n.width,d=n.height,f=Po*o,m=Lo*o;let g=l*(u/f)/e.shaderScale,p=s*(d/m)/e.shaderScale;g>u&&(g=u),p>d&&(p=d);const M=Math.max(0,(u-g)/2),b=Math.max(0,(d-p)/2),v=e.opacityMul*x.preset.shaderOpacity,h=e.ctx;h.clearRect(0,0,i,a);const y=e.deform;if(e.mask){if(v<1&&(h.globalAlpha=v),h.drawImage(n,M,b,g,p,0,0,i,a),v<1&&(h.globalAlpha=1),e.wantRaw){let w=e.rawCanvas;w||(w=document.createElement("canvas"),e.rawCanvas=w),(w.width!==i||w.height!==a)&&(w.width=i,w.height=a);const E=w.getContext("2d");E&&(E.clearRect(0,0,i,a),E.drawImage(e.canvas,0,0))}h.save(),h.globalCompositeOperation="destination-in",h.fillStyle="#000",e.mask(h,i,a,o),h.restore(),h.globalCompositeOperation="source-over"}else if(!y)v<1&&(h.globalAlpha=v),h.drawImage(n,M,b,g,p,0,0,i,a),v<1&&(h.globalAlpha=1),Jr(e);else{const w=e.cssWidth,E=e.cssHeight,A=e.cornerRadius,P=e.ringCssPx,B=e.deformLayers;h.save(),h.translate(c,c);const X=l/g,L=s/p,N=Math.min(u,g*(l+2*c)/l),C=Math.min(d,p*(s+2*c)/s),G=Math.max(0,(u-N)/2),Y=Math.max(0,(d-C)/2),H=N*X,S=C*L;if(v<1&&(h.globalAlpha=v),h.drawImage(n,G,Y,N,C,l/2-H/2,s/2-S/2,H,S),v<1&&(h.globalAlpha=1),h.globalCompositeOperation="destination-in",Re(h,0,0,w,E,A,y,o),h.fillStyle="#000",h.fill(),h.globalCompositeOperation="destination-out",Re(h,P,P,w-2*P,E-2*P,Math.max(0,A-P),y,o),h.fill(),e.wantRing){let _=e.ringCanvas;_||(_=document.createElement("canvas"),e.ringCanvas=_),(_.width!==i||_.height!==a)&&(_.width=i,_.height=a);const k=_.getContext("2d");k&&(k.setTransform(1,0,0,1,0,0),k.globalCompositeOperation="source-over",k.clearRect(0,0,i,a),k.translate(c,c),v<1&&(k.globalAlpha=v),k.drawImage(n,G,Y,N,C,l/2-H/2,s/2-S/2,H,S),k.globalAlpha=1,k.globalCompositeOperation="destination-out",Re(k,P,P,w-2*P,E-2*P,Math.max(0,A-P),y,o),k.fillStyle="#000",k.fill(),k.globalCompositeOperation="source-over",k.setTransform(1,0,0,1,0,0))}if(B!=null&&B.hairline){const _=B.hairline;h.globalCompositeOperation="destination-over",Re(h,_.inset,_.inset,w-2*_.inset,E-2*_.inset,Math.max(0,A-_.inset),y,o),h.lineWidth=_.width*o,h.strokeStyle=_.color,h.stroke()}if(B!=null&&B.fill&&(h.globalCompositeOperation="destination-over",Re(h,0,0,w,E,A,y,o),h.fillStyle=B.fill,h.fill()),B!=null&&B.rim){const _=B.rim;h.globalCompositeOperation="source-over",h.save(),Re(h,0,0,w,E,A,y,o),h.clip();const k=_.inset+_.width/2;Re(h,k,k,w-2*k,E-2*k,Math.max(0,A-k),y,o),h.lineWidth=_.width*o,h.strokeStyle=_.color,h.stroke(),h.restore()}h.restore(),h.globalCompositeOperation="source-over"}if((t=e.onComposite)==null||t.call(e),e.onFirstCopy){const w=e.onFirstCopy;e.onFirstCopy=void 0,w()}(r=e.onAfterFrame)==null||r.call(e)}function Zr(){if(!x)return;const{gl:e,uniforms:t,preset:r,glCanvas:n,dpr:o}=x;t.u_resolution&&e.uniform2f(t.u_resolution,n.width,n.height),t.u_pixelRatio&&e.uniform1f(t.u_pixelRatio,o),t.u_colorBack&&e.uniform4fv(t.u_colorBack,Jt(r.colorBack)),t.u_colorTint&&e.uniform4fv(t.u_colorTint,Jt(r.colorTint)),t.u_repetition&&e.uniform1f(t.u_repetition,r.repetition),t.u_softness&&e.uniform1f(t.u_softness,r.softness),t.u_shiftRed&&e.uniform1f(t.u_shiftRed,r.shiftRed),t.u_shiftBlue&&e.uniform1f(t.u_shiftBlue,r.shiftBlue),t.u_distortion&&e.uniform1f(t.u_distortion,r.distortion),t.u_contour&&e.uniform1f(t.u_contour,r.contour),t.u_angle&&e.uniform1f(t.u_angle,r.angle),t.u_shape&&e.uniform1f(t.u_shape,r.shape),t.u_isImage&&e.uniform1i(t.u_isImage,0),t.u_imageAspectRatio&&e.uniform1f(t.u_imageAspectRatio,1),t.u_originX&&e.uniform1f(t.u_originX,r.originX),t.u_originY&&e.uniform1f(t.u_originY,r.originY),t.u_worldWidth&&e.uniform1f(t.u_worldWidth,r.worldWidth),t.u_worldHeight&&e.uniform1f(t.u_worldHeight,r.worldHeight),t.u_fit&&e.uniform1f(t.u_fit,r.fit),t.u_scale&&e.uniform1f(t.u_scale,r.scale),t.u_rotation&&e.uniform1f(t.u_rotation,r.rotation),t.u_offsetX&&e.uniform1f(t.u_offsetX,r.offsetX),t.u_offsetY&&e.uniform1f(t.u_offsetY,r.offsetY),x.presetDirty=!1}function en(e){if(!x)return;const{gl:t,uniforms:r,preset:n,glCanvas:o}=x,i=(e-x.startMs-x.pausedMs)/1e3*n.speed;t.viewport(0,0,o.width,o.height),t.clearColor(0,0,0,0),t.clear(t.COLOR_BUFFER_BIT),x.presetDirty&&Zr(),r.u_time&&t.uniform1f(r.u_time,i),t.drawArrays(t.TRIANGLES,0,6),x.frameCount++}let no=0;function Ho(e){var t;if(!x)return;if(x.contextLost){x.rafId=0;return}let r=!1;for(const n of x.instances)if(n.visible&&(!n.paused||!n.everCopied)){r=!0;break}if(!r){x.rafId=0;return}if(x.rafId=requestAnimationFrame(Ho),e-no<vr){if(Se)for(const n of x.glowQueue)n.glowFast&&n.visible&&!n.paused&&(n.glowFast=!!Se(n,e));return}no=e,en(e),Wr(),x.useOffscreen&&((t=x.frameBitmap)==null||t.close(),x.frameBitmap=x.glCanvas.transferToImageBitmap());for(const n of x.instances)n.visible&&(n.paused&&n.everCopied||(Go(n),n.everCopied=!0));if(Se&&x.glowQueue.length>0&&++x.glowSkip%yr===0)for(const n of x.glowQueue)n.visible&&!n.paused&&(n.glowFast=!!Se(n,e))}function Ze(){!x||x.rafId!==0||(x.rafId=requestAnimationFrame(Ho))}function $o(){x&&(x.rafId!==0&&cancelAnimationFrame(x.rafId),x.rafId=0)}const Tt={linear:e=>e,smoothstep:e=>e*e*(3-2*e)};function $e(e,t,r,n=Tt.linear){return{from:e,to:t,dur:r,ease:n,startMs:-1,val:e,done:!1}}function Xe(e,t){e.startMs=t,e.val=e.from,e.done=!1}function ao(e,t){if(e.done||e.startMs<0)return e.val;const r=Math.min(1,(t-e.startMs)/e.dur);return e.val=e.from+(e.to-e.from)*e.ease(r),r>=1&&(e.done=!0),e.val}const tn=Object.freeze({haloOpMul:2,extraIntensity:3.51,peakOp:.85,baseOp:.34,inset:1.5,extraOutward:1,wanderRange:15,wanderLerp:.0075,fadeRate:.00875,lumLo:.08,lumHi:.32,minDwellMs:1500,relocFadeMs:300,relocFadeOutMs:450,pointGain:2.5,haloHalfLen:7.8,extraHalfLen:9.13952/3,haloStrokeXl:26.4,haloStrokeLg:15.6,haloStrokeMd:7.2,haloStrokeSm:3,haloBlurXl:8.4,haloBlurLg:4.8,haloBlurMd:2.1,haloBlurSm:.9,haloOpXl:.385,haloOpLg:.595,haloOpMd:.7,haloOpSm:.7,extraStrokeOuter:4/3,extraStrokeCore:2/3,extraBlurOuter:2/3,extraBlurCore:1.35/3,extraFadeR:13/3,extraOpOuter:.85}),R={...tn},io=new Set;function on(e){return io.add(e),()=>{io.delete(e)}}const rn=Object.freeze({enabled:!0,reach:56,fadeMs:200,cursor:!0,cursorDistance:186,cursorStrength:3.35,cursorDiffuse:1.4,cursorFalloff:37,cursorDepth:.4,cursorEdge:0,cursorReach:11.5,cursorBlur:.5,cursorZoom:3,spill:!1,spillRadius:48,spillStrength:.55,spillOffset:.35,spillLumGain:.7,spillSaturation:1.3,spillInside:.5,spillBlur:0,catchLight:!1,catchFollow:.25,catchGain:1}),Ye={...rn};let Xo=!1,Yo=0,at=0,je=0,Ge=!1,Te=0,Et=0,pe=Number.NaN,ke=Number.NaN,Bt=0,Ot=0,Ce=0,Pe=0,Q=null;const K={d:0,nx:0,ny:0,k:1,left:0,top:0},xt={x:0,y:0},fe={r:255,g:255,b:255};let xe=null,At="",It=-1,Ft=-1,Je=!1;function nn(){je++,ln()}function an(){je=Math.max(0,je-1),je===0&&cn()}const sn=e=>typeof window.matchMedia=="function"&&window.matchMedia(e).matches;function so(){return Xo||performance.now()<Yo,!1}function ln(){Ge||je===0||typeof document>"u"||sn("(pointer: fine)")&&(Ge=!0,document.addEventListener("pointermove",jo,{passive:!0}),document.addEventListener("pointerleave",ye),document.addEventListener("pointercancel",ye),document.addEventListener("keydown",qo,{passive:!0}),document.addEventListener("visibilitychange",ye),window.addEventListener("blur",ye))}function cn(){Ge&&(Ge=!1,document.removeEventListener("pointermove",jo),document.removeEventListener("pointerleave",ye),document.removeEventListener("pointercancel",ye),document.removeEventListener("keydown",qo),document.removeEventListener("visibilitychange",ye),window.removeEventListener("blur",ye),Te!==0&&(cancelAnimationFrame(Te),Te=0),Q&&(Q.cursorLight=null,Q=null),Ce=0,Pe=0,xe&&(xe.remove(),xe=null,At="",It=-1,Ft=-1,Je=!1),Be(),Me&&(Me.remove(),Me=null))}let Pt=!0,Yt=!1;function jo(e){Pt=e.pointerType==="mouse"||e.pointerType==="",Yt=!1,pe=Bt=e.clientX,ke=Ot=e.clientY,Lt&&Me&&(Pt&&Jo(pe,ke)?void 0:Be()),Qo()}function qo(){Yt=!0,Be()}function ye(){pe=ke=Number.NaN,Qo()}function Qo(){!Ge||Te!==0||(Et=performance.now(),Te=requestAnimationFrame(Ko))}function un(e,t,r,n,o,i,a){const l=i==="circle"?Math.min(r,n)/2:Math.max(0,Math.min(o,Math.min(r,n)/2)),s=r/2,c=n/2,u=Math.max(0,r/2-l),d=Math.max(0,n/2-l),f=Math.max(-u,Math.min(u,e-s)),m=Math.max(-d,Math.min(d,t-c)),g=e-s-f,p=t-c-m,M=Math.hypot(g,p);if(M>1e-6)return a.x=s+f+g/M*l,a.y=c+m+p/M*l,M-l;const b=e,v=r-e,h=t,y=n-t,w=Math.min(b,v,h,y);return w===b?(a.x=0,a.y=t):w===v?(a.x=r,a.y=t):w===h?(a.x=e,a.y=0):(a.x=e,a.y=n),-w}let Me=null,Lt=!1,Ne=!1,Ut="",ge=null,qe="";const dn=/^(INPUT|TEXTAREA|SELECT)$/;let zt=new WeakMap,lo=0,Nt=null;function hn(e){let t=e;for(;t&&t!==document.body;){if(dn.test(t.tagName)||t.isContentEditable)return!0;t=t.parentElement}return!1}function fn(){if(Me)return!0;const e=document.createElement("div");e.className="metal-fx-cursor",e.setAttribute("aria-hidden","true"),e.style.cssText="position:fixed;left:0;top:0;pointer-events:none;z-index:2147483001;will-change:transform;transform-origin:0 0;display:none";const t=document.createElement("canvas");t.style.display="block",e.appendChild(t),document.body.appendChild(e);const r=t.getContext("2d"),n=document.createElement("canvas"),o=n.getContext("2d");return!r||!o?(e.remove(),!1):(Me=e,!0)}function Jo(e,t,r=!1){const n=performance.now();if(!r&&Ne&&n-lo<12)return!0;lo=n;const o=document.elementFromPoint(e,t);if(!o)return Vt(),!1;if(o===Nt&&Ne)return!0;Nt=o;let i=zt.get(o);if(i===void 0){if(i=!hn(o),i){const a=getComputedStyle(o).cursor;i=a==="auto"||a==="default"||a==="none"}zt.set(o,i)}if(!i)return Vt(),!1;if(!Ne){const a=document.documentElement;Ut=a.style.cursor,a.style.cursor="none",Ne=!0}return o!==ge&&(ge&&(ge.style.cursor=qe,ge=null,qe=""),getComputedStyle(o).cursor!=="none"&&(ge=o,qe=o.style.cursor,o.style.cursor="none")),!0}function Vt(){ge&&(ge.isConnected&&(ge.style.cursor=qe),ge=null,qe=""),Ne&&(document.documentElement.style.cursor=Ut,Ne=!1,Ut=""),Nt=null,zt=new WeakMap}function Be(){Vt(),Me&&Lt&&(Me.style.display="none",Lt=!1)}function mn(){if(xe)return xe;const e=document.createElement("div");return e.className="metal-fx-cursor-spill",e.setAttribute("aria-hidden","true"),e.style.cssText="position:fixed;left:0;top:0;pointer-events:none;z-index:2147483000;border-radius:50%;mix-blend-mode:plus-lighter;will-change:transform,opacity;opacity:0;display:none",document.body.appendChild(e),xe=e,e}function Wt(){!xe||!Je||(xe.style.display="none",xe.style.opacity="0",Je=!1)}function Ko(e){if(Te=0,!Ge)return;const t=performance.now();try{pn(e)}catch(r){Xo=!0,Be(),Wt(),Q&&(Q.cursorLight=null,Q=null),typeof console<"u"&&console.warn("metal-fx: cursor light disabled after error",r);return}performance.now()-t>6?++at>=20&&(at=0,Yo=performance.now()+5e3,Be()):at>0&&at--}function pn(e){const t=Ye,r=Math.min(.05,Math.max(.001,(e-Et)/1e3));Et=e;let n=null,o=0,i=0;if(t.enabled&&x&&!Number.isNaN(pe)){let l=Number.POSITIVE_INFINITY;const s=Math.max(1,t.reach),c=t.cursor&&so()?Math.max(1,t.cursorDistance):0,u=Math.max(s,c);for(const d of x.instances){if(!d.visible||!d.canvas.isConnected)continue;const f=d.canvas.getBoundingClientRect();if(f.width<=0)continue;const m=d.overscan,g=f.width/(d.cssWidth+2*m),p=f.left+m*g,M=f.top+m*g,b=u*g;if(pe<p-b||pe>p+d.cssWidth*g+b||ke<M-b||ke>M+d.cssHeight*g+b)continue;const v=(pe-p)/g,h=(ke-M)/g,y=un(v,h,d.cssWidth,d.cssHeight,d.cornerRadius,d.kind,xt),w=Math.abs(y);w<=u&&w<l&&(l=w,n=d,K.d=y,K.nx=xt.x,K.ny=xt.y,K.k=g,K.left=p,K.top=M)}if(n){if(l<=s){const d=1-l/s;o=d*d*(3-2*d)}l<=c&&(i=Math.min(1,(1-l/c)*3)),n.mask&&(K.nx=n.cssWidth/2,K.ny=n.cssHeight/2,n.wantRaw=!0)}}const a=1-Math.exp(-(r*1e3)/(Math.max(1,t.fadeMs)/3));if(Ce+=(o-Ce)*a,Pe+=(i-Pe)*a,n&&n!==Q&&(Q&&(Q.cursorLight=null,gt(Q,e)),Q=n),!n&&Ce<.002&&Pe<.002){Ce=0,Pe=0,Q&&(Q.cursorLight=null,gt(Q,e),Q=null),Wt(),Be();return}if(Q){if(t.catchLight){const l=Q.cursorLight??(Q.cursorLight={x:0,y:0,w:0});l.x=K.nx,l.y=K.ny,l.w=Ce}else Q.cursorLight&&(Q.cursorLight=null);if(gt(Q,e),t.cursor&&Pe>.002&&Pt&&!Yt&&!Number.isNaN(pe)&&so()&&fn()&&Jo(pe,ke)?void 0:Be(),t.spill){const l=mn(),s=Vo(Q,K.nx,K.ny,2),c=kt(Q,K.nx,K.ny,3),u=Math.max(s.r,s.g,s.b)||1,d=Io(s.r*255/u,s.g*255/u,s.b*255/u),[f,m,g]=Fo(d[0],Math.min(1,d[1]*t.spillSaturation),1);fe.r+=(f-fe.r)*.15,fe.g+=(m-fe.g)*.15,fe.b+=(g-fe.b)*.15;const p=Math.round(fe.r/6)*6,M=Math.round(fe.g/6)*6,b=Math.round(fe.b/6)*6,v=`radial-gradient(closest-side, rgba(${p},${M},${b},1) 0%, rgba(${p},${M},${b},0.35) 45%, rgba(${p},${M},${b},0) 100%)`;v!==At&&(At=v,l.style.background=v);const h=Math.max(1,t.spillRadius*K.k);h!==It&&(It=h,l.style.width=`${(2*h).toFixed(1)}px`,l.style.height=`${(2*h).toFixed(1)}px`),t.spillBlur!==Ft&&(Ft=t.spillBlur,l.style.filter=t.spillBlur>0?`blur(${t.spillBlur}px)`:"");const y=K.left+K.nx*K.k,w=K.top+K.ny*K.k,E=Bt+(y-Bt)*t.spillOffset,A=Ot+(w-Ot)*t.spillOffset;l.style.transform=`translate3d(${(E-h).toFixed(2)}px,${(A-h).toFixed(2)}px,0)`;const P=Math.min(1,Math.max(0,c/.3)),B=1-t.spillLumGain+t.spillLumGain*P,X=K.d<0?t.spillInside:1,L=Math.max(0,Math.min(1,t.spillStrength*Ce*B*X));Je||(l.style.display="",Je=!0),l.style.opacity=L.toFixed(3)}else Wt();Te=requestAnimationFrame(Ko)}}const ct=new Map;function gn(e,t){const r=Math.sqrt(12*e*e/t+1);let n=Math.floor(r);n%2===0&&n--;const o=n+2,i=(12*e*e-t*n*n-4*t*n-3*t)/(-4*n-4),a=Math.round(i),l=[];for(let s=0;s<t;s++)l.push(s<a?n:o);return l}function xn(e,t,r,n,o){const i=1/(o+o+1);for(let a=0;a<n;a++){const l=a*r;let s=0;for(let c=-o;c<=o;c++)s+=e[l+Math.min(r-1,Math.max(0,c))];for(let c=0;c<r;c++){t[l+c]=s*i;const u=l+Math.max(0,c-o),d=l+Math.min(r-1,c+o+1);s+=e[d]-e[u]}}}function vn(e,t,r,n,o){const i=1/(o+o+1);for(let a=0;a<r;a++){let l=0;for(let s=-o;s<=o;s++)l+=e[Math.min(n-1,Math.max(0,s))*r+a];for(let s=0;s<n;s++){t[s*r+a]=l*i;const c=Math.max(0,s-o)*r+a,u=Math.min(n-1,s+o+1)*r+a;l+=e[u]-e[c]}}}function ht(e,t,r,n){if(n<=.05)return e;const o=new Float32Array(e.length);let i=e;for(const a of gn(n,3)){const l=(a-1)/2;xn(i,o,t,r,l),vn(o,i,t,r,l)}return i}function wn(e,t,r,n,o,i,a){const l=document.createElement("canvas");l.width=r,l.height=n;const s=l.getContext("2d",{willReadFrequently:!0}),c=new Float32Array(r*n);if(!s)return c;s.scale(o,o),s.strokeStyle="#fff",s.lineCap="round",s.lineJoin="round",s.lineWidth=t,s.beginPath(),s.moveTo(i-e,a),s.lineTo(i+e,a),s.stroke();const u=s.getImageData(0,0,r,n).data;for(let d=0,f=3;d<c.length;d++,f+=4)c[d]=u[f]/255;return c}function Zo(e,t,r,n,o){let i=0;for(const p of e)i=Math.max(i,(p.stroke/2+3*p.blur)*r);const a=Math.ceil(i)+1,l=2*t+2*a,s=2*a,c=Math.ceil(l*n),u=Math.ceil(s*n),d=new Float32Array(c*u);for(const p of e){let M=wn(t,p.stroke*r,c,u,n,a,a);M=ht(M,c,u,p.blur*r*n);const b=p.opacity;for(let v=0;v<d.length;v++){const h=M[v]*b;d[v]=d[v]+h*(1-d[v])}}if(o>0){const p=a*n,M=a*n,b=o*r*n;for(let v=0;v<u;v++)for(let h=0;h<c;h++){const y=Math.hypot(h+.5-p,v+.5-M)/b;let w;y<=.3?w=1:y<=.65?w=1-(y-.3)/.35*.75:y<1?w=.25*(1-(y-.65)/.35):w=0,d[v*c+h]*=w}}const f=document.createElement("canvas");f.width=c,f.height=u;const m=f.getContext("2d"),g=new Uint8ClampedArray(c*u);for(let p=0;p<d.length;p++)g[p]=Math.round(Math.min(1,d[p])*255);if(m){const p=m.createImageData(c,u),M=p.data;for(let b=0,v=0;b<d.length;b++,v+=4)M[v]=255,M[v+1]=255,M[v+2]=255,M[v+3]=g[b];m.putImageData(p,0,0)}return{canvas:f,alpha:g,w:l,h:s,ax:a,ay:a}}function er(){return[R.haloStrokeXl,R.haloStrokeLg,R.haloStrokeMd,R.haloStrokeSm,R.haloBlurXl,R.haloBlurLg,R.haloBlurMd,R.haloBlurSm,R.haloOpXl,R.haloOpLg,R.haloOpMd,R.haloOpSm,R.extraStrokeOuter,R.extraStrokeCore,R.extraBlurOuter,R.extraBlurCore,R.extraFadeR,R.extraOpOuter].join(",")}function bn(e,t,r){const n=`h|${e.toFixed(2)}|${t}|${r}|${er()}`;let o=ct.get(n);return o||(o=Zo([{stroke:R.haloStrokeXl,blur:R.haloBlurXl,opacity:R.haloOpXl},{stroke:R.haloStrokeLg,blur:R.haloBlurLg,opacity:R.haloOpLg},{stroke:R.haloStrokeMd,blur:R.haloBlurMd,opacity:R.haloOpMd},{stroke:R.haloStrokeSm,blur:R.haloBlurSm,opacity:R.haloOpSm}],e,t,r,0),ct.set(n,o)),o}function yn(e,t,r){const n=`e|${e.toFixed(2)}|${t}|${r}|${er()}`;let o=ct.get(n);return o||(o=Zo([{stroke:R.extraStrokeOuter,blur:R.extraBlurOuter,opacity:R.extraOpOuter},{stroke:R.extraStrokeCore,blur:R.extraBlurCore,opacity:1}],e,t,r,R.extraFadeR),ct.set(n,o)),o}function co(e,t,r,n,o){var i;const a=t<<16|r<<8|n;if(o.canvas&&o.tint===a&&o.src===e)return o.canvas;let l=o.canvas,s=o.img;(!l||!s||o.src!==e)&&(l=document.createElement("canvas"),l.width=e.canvas.width,l.height=e.canvas.height,s=((i=l.getContext("2d"))==null?void 0:i.createImageData(l.width,l.height))??null);const c=l.getContext("2d");if(c&&s){const u=s.data,d=e.alpha;for(let f=0,m=0;f<d.length;f++,m+=4)u[m]=t,u[m+1]=r,u[m+2]=n,u[m+3]=d[f];c.putImageData(s,0,0)}return o.canvas=l,o.img=s,o.tint=a,o.src=e,l}function jt(e,t,r){const n=Math.max(0,Math.min(r,Math.min(e,t)/2));return 2*Math.max(0,e-2*n)+2*Math.max(0,t-2*n)+2*Math.PI*n}function ut(e,t,r,n){return n==="circle"?2*Math.PI*Math.max(0,Math.min(r,Math.min(e,t)/2)):jt(e,t,r)}function Ke(e,t,r,n,o,i,a,l){const s=l||{x:0,y:0},c=Math.max(0,Math.min(n,Math.min(t,r)/2));if(a==="circle"){const b=2*Math.PI*c;if(b<=1e-4)return s.x=t*.5,s.y=r*.5,s;e=(e%b+b)%b;const v=-Math.PI/2+e/b*Math.PI*2,h=Math.max(0,c-o+i);return s.x=t*.5+h*Math.cos(v),s.y=r*.5+h*Math.sin(v),s}const u=Math.max(0,t-2*c),d=Math.max(0,r-2*c),f=Math.PI*c/2,m=2*(u+d)+4*f;e=(e%m+m)%m;const g=Math.max(0,c-o+i);let p=e;if(p<u)return s.x=c+p,s.y=o-i,s;if(p-=u,p<f){const b=-Math.PI/2+(f>0?p/f:0)*(Math.PI/2);return s.x=t-c+g*Math.cos(b),s.y=c+g*Math.sin(b),s}if(p-=f,p<d)return s.x=t-o+i,s.y=c+p,s;if(p-=d,p<f){const b=(f>0?p/f:0)*(Math.PI/2);return s.x=t-c+g*Math.cos(b),s.y=r-c+g*Math.sin(b),s}if(p-=f,p<u)return s.x=t-c-p,s.y=r-o+i,s;if(p-=u,p<f){const b=Math.PI/2+(f>0?p/f:0)*(Math.PI/2);return s.x=c+g*Math.cos(b),s.y=r-c+g*Math.sin(b),s}if(p-=f,p<d)return s.x=o-i,s.y=r-c-p,s;p-=d;const M=Math.PI+(f>0?p/f:0)*(Math.PI/2);return s.x=c+g*Math.cos(M),s.y=c+g*Math.sin(M),s}function Mn(e,t,r,n,o,i){const a=Math.max(0,Math.min(o,Math.min(r,n)/2));if(i==="circle"){const w=2*Math.PI*a;return w<=1e-4?0:((Math.atan2(t-n/2,e-r/2)+Math.PI/2)/(2*Math.PI)*w%w+w)%w}const l=Math.max(0,r-2*a),s=Math.max(0,n-2*a),c=Math.PI*a/2,u=Math.PI/2,d=l,f=d+c,m=f+s,g=m+c,p=g+l,M=p+c,b=M+s,v=e>=a&&e<=r-a,h=t>=a&&t<=n-a;if(v&&h){const w=e,E=r-e,A=t,P=n-t,B=Math.min(w,E,A,P);return B===A?e-a:B===E?f+(t-a):B===P?g+(r-a-e):M+(n-a-t)}if(v)return t<n/2?e-a:g+(r-a-e);if(h)return e>r/2?f+(t-a):M+(n-a-t);if(e>r/2&&t<n/2){const w=Math.atan2(t-a,e-(r-a));return d+(w+u)/u*c}if(e>r/2){const w=Math.atan2(t-(n-a),e-(r-a));return m+w/u*c}if(t>n/2){const w=Math.atan2(t-(n-a),e-a);return p+(w-u)/u*c}const y=Math.atan2(t-a,e-a);return b+(y+Math.PI)/u*c}const vt={x:0,y:0},wt={x:0,y:0};function _n(e,t,r,n,o,i){return Ke(e-.1,t,r,n,o,0,i,vt),Ke(e+.1,t,r,n,o,0,i,wt),Math.atan2(wt.y-vt.y,wt.x-vt.x)}function uo(e,t,r){if(e===t)return r<e?0:1;const n=Math.max(0,Math.min(1,(r-e)/(t-e)));return n*n*(3-2*n)}function Rn(e){if(e.samplePoints&&e.samplePoints.length>0)return e.samplePoints.map((o,i)=>({x:o.x,y:o.y,arc:i}));const t=ut(e.width,e.height,e.cornerRadius,e.kind),r=R.inset*(e.scale??1),n=[];for(let o=0;o<Kt;o++){const i=o/Kt*t,a=Ke(i,e.width,e.height,e.cornerRadius,r,0,e.kind);n.push({x:a.x,y:a.y,arc:i})}return n}const Cn=.05,Sn=120*(1e3/15),ho=1e3/15,fo=2e3,bt=400,kn=2.625,Tn=1.008,En=.31,tr=140,or=40,rr=20,Bn=34,it=.25,On=.01,mo=.004,An=.5,In=3.5,ie={x:0,y:0};function po(e,t){const{width:r,height:n}=t,o=t.scale??1,i=Math.min(3,typeof window<"u"&&window.devicePixelRatio||1),a=ut(r,n,t.cornerRadius,t.kind)/jt(tr,or,rr),l=Math.max(1,R.haloHalfLen*a),s=Math.max(.6,R.extraHalfLen*a),c=bn(l,o,i),u=yn(s,o,i),d=Math.ceil(Math.max(c.ay,u.ay)+R.extraOutward*a*o+2),f=document.createElement("div");f.className="metal-fx-glow-svg",f.setAttribute("aria-hidden","true");const m=document.createElement("div");m.className="metal-fx-glow-env",m.style.cssText="position:absolute;inset:0;pointer-events:none;opacity:0";const g=document.createElement("canvas");g.className="metal-fx-glow-canvas";const p=r+2*d,M=n+2*d;g.width=Math.ceil(p*i),g.height=Math.ceil(M*i),g.style.cssText=`position:absolute;left:${-d}px;top:${-d}px;width:${p}px;height:${M}px;pointer-events:none`,m.appendChild(g),f.appendChild(m),e.appendChild(f);const b=g.getContext("2d",{willReadFrequently:!!t.maskDataUrl});if(!b)throw new Error("metal-fx: glow canvas 2D context unavailable");const v={wrap:f,env:m,canvas:g,ctx:b,surroundPath:null,bandPath:null,maskAlpha:null,maskReady:!1,margin:d,dpr:i,halo:c,extra:u,haloTint:{canvas:null,img:null,tint:-1,src:null},extraTint:{canvas:null,img:null,tint:-1,src:null},mO:We(),mI:We(),maskSum:Number.NaN,maskDeformed:!1,deform:null,width:r,height:n,cornerRadius:t.cornerRadius,kind:t.kind,scale:o,perim:Rn(t),pointMode:!!(t.samplePoints&&t.samplePoints.length>0),currentIdx:0,appearedAt:0,glowOpacity:0,relocTween:null,relocNextIdx:-1,relocMul:0,envClock:0,cursorMode:!1,cursorArc:0,cursorTargetArc:0,lastTickMs:0,wanderS:0,wanderTargetS:0,wanderFrames:0,tintFrom:{r:255,g:255,b:255},tintTarget:{r:255,g:255,b:255},tintTween:null,tintHoldUntil:0,dX:Number.NaN,dY:Number.NaN,dAng:Number.NaN,dEX:Number.NaN,dEY:Number.NaN,dHOp:Number.NaN,dEOp:Number.NaN,dHaloTint:"",dExtraTint:"",dirty:!0,dEnv:-1};if(t.maskDataUrl){const h=new Image;h.onload=()=>{const y=document.createElement("canvas");y.width=g.width,y.height=g.height;const w=y.getContext("2d",{willReadFrequently:!0});if(!w)return;w.scale(i,i),w.drawImage(h,d,d,r,n);const E=w.getImageData(0,0,y.width,y.height).data,A=y.width*y.height,P=new Float32Array(A);for(let C=0,G=3;C<A;C++,G+=4)P[C]=E[G]/255;const B=ht(Float32Array.from(P),y.width,y.height,In*i);let X=0;for(let C=0;C<A;C++)B[C]>X&&(X=B[C]);const L=X>0?An/X:0,N=new Uint8ClampedArray(A);for(let C=0;C<A;C++)N[C]=Math.round(Math.max(P[C],B[C]*L)*255);v.maskAlpha=N,v.maskReady=!0,v.dirty=!0},h.src=t.maskDataUrl}else Dt(v,null);return v}function Dt(e,t){if(e.pointMode)return;const{margin:r,width:n,height:o,cornerRadius:i}=e,a=e.kind==="circle"?2:1;De(0,0,n,o,i,t,e.mO),De(a,a,n-2*a,o-2*a,Math.max(0,i-a),t,e.mI);const l=new Path2D;yt(l,e.mO,r);const s=new Path2D;yt(s,e.mO,r),yt(s,e.mI,r);const c=new Path2D;c.rect(0,0,n+2*r,o+2*r),c.addPath(l),e.surroundPath=c,e.bandPath=s,e.maskReady=!0}function yt(e,t,r){const n=t.xy;for(let o=0;o<t.n;o++){const i=n[o*2]+r,a=n[o*2+1]+r;o===0?e.moveTo(i,a):e.lineTo(i,a)}e.closePath()}function Fn(e,t){if(!e)return 0;De(0,0,t.width,t.height,t.cornerRadius,e,t.mO);let r=0;const n=t.mO.xy;for(let o=0;o<t.mO.n;o+=4)r+=n[o*2]*1.37+n[o*2+1];return r}function Pn(e,t){if(e.deform=t,!e.pointMode)if(t){const r=Fn(t,e);r!==e.maskSum&&(e.maskSum=r,Dt(e,t),e.maskDeformed=!0,e.dirty=!0)}else e.maskDeformed&&(e.maskSum=Number.NaN,Dt(e,null),e.maskDeformed=!1,e.dirty=!0)}function Ln(e,t,r,n,o="dark"){var i;const{width:a,height:l,cornerRadius:s,perim:c}=e;if(c.length===0)return!1;const u=2;let d=-1,f=e.currentIdx,m=0;for(let F=0;F<c.length;F++){const q=c[F],$=kt(t,q.x,q.y,u);$>d&&(d=$,f=F),F===e.currentIdx&&(m=$)}const g=e.appearedAt>0&&r-e.appearedAt<R.minDwellMs,p=R.baseOp+(R.peakOp-R.baseOp)*uo(R.lumLo,R.lumHi,m),M=!g&&d-m>Cn,b=t.cursorLight,v=Ye.enabled&&Ye.catchLight&&!e.pointMode&&!!b&&b.w>.02,h=ut(a,l,s,e.kind);v&&(e.cursorTargetArc=Mn(b.x,b.y,a,l,s,e.kind));const y=v?Math.min(1,R.peakOp*Ye.catchGain*b.w):0,w=e.lastTickMs>0?Math.min(200,Math.max(.5,r-e.lastTickMs)):ho;e.lastTickMs=r,e.envClock+=Math.min(w,Bn);const E=F=>1-Math.pow(1-F,w/ho),A=Math.max(1,R.relocFadeMs),P=Math.max(1,R.relocFadeOutMs),B=-2,X=-3,L=()=>{e.appearedAt=r,e.wanderS=0,e.wanderTargetS=0,e.wanderFrames=0,e.relocTween=$e(0,1,A,Tt.smoothstep),Xe(e.relocTween,e.envClock)},N=F=>{e.relocNextIdx=F,e.relocTween=$e(1,0,P,Tt.smoothstep),Xe(e.relocTween,e.envClock)};if((i=e.relocTween)!=null&&i.done&&e.relocTween.to===0){let F=e.relocNextIdx;if(F===B&&!v&&(F=X),F===X)e.cursorMode=!1,e.appearedAt=0,e.relocTween=null;else if(F===B)e.cursorMode=!0,e.cursorArc=e.cursorTargetArc,e.glowOpacity=y,L();else{e.currentIdx=F;const q=c[e.currentIdx],$=kt(t,q.x,q.y,u);e.glowOpacity=R.baseOp+(R.peakOp-R.baseOp)*uo(R.lumLo,R.lumHi,$),L()}}if((!e.relocTween||e.relocTween.done)&&(e.appearedAt===0?(v?(e.cursorMode=!0,e.cursorArc=e.cursorTargetArc,e.glowOpacity=y):(e.cursorMode=!1,e.currentIdx=f,e.glowOpacity=p),L()):v!==e.cursorMode?N(v?B:X):!e.cursorMode&&M&&N(f)),e.cursorMode){v&&(e.glowOpacity=y);const F=Math.max(.01,Math.min(1,Ye.catchFollow)),q=1-Math.pow(1-F,w/(1e3/60));let $=e.cursorTargetArc-e.cursorArc;$=($%h+h*1.5)%h-h/2,e.cursorArc+=$*q}else e.glowOpacity+=(p-e.glowOpacity)*E(R.fadeRate);e.glowOpacity=Math.max(0,Math.min(1,e.glowOpacity)),e.relocMul=e.relocTween?ao(e.relocTween,e.envClock):1;const C=ut(a,l,s,e.kind)/jt(tr,or,rr),G=R.wanderRange*C;e.wanderFrames+=w,e.wanderFrames>=Sn&&(e.wanderTargetS=(Math.random()*2-1)*G,e.wanderFrames=0),e.wanderS+=(e.wanderTargetS-e.wanderS)*E(R.wanderLerp);let Y,H,S,_,k;if(e.pointMode){const F=c[e.currentIdx];Y=F.x+e.wanderS,H=F.y,S=0,_=Y,k=H}else{const F=e.cursorMode?e.cursorArc:c[e.currentIdx].arc+e.wanderS,q=R.inset*e.scale;Ke(F,a,l,s,q,0,e.kind,ie),Y=ie.x,H=ie.y,S=_n(F,a,l,s,q,e.kind);const $=R.extraOutward*C*e.scale;Ke(F,a,l,s,q,$,e.kind,ie),_=ie.x,k=ie.y}e.deform&&(e.deform(Y,H,ie),Y=ie.x,H=ie.y,e.deform(_,k,ie),_=ie.x,k=ie.y);const Z=o==="light",ee=Z?Dr(t,Y,H,u):Vo(t,Y,H,u);e.tintTween?e.tintTween.done&&(Z?(e.tintFrom={r:e.tintFrom.r+(e.tintTarget.r-e.tintFrom.r)*e.tintTween.val,g:e.tintFrom.g+(e.tintTarget.g-e.tintFrom.g)*e.tintTween.val,b:e.tintFrom.b+(e.tintTarget.b-e.tintFrom.b)*e.tintTween.val},e.tintTarget={...ee},e.tintTween=$e(0,1,bt),Xe(e.tintTween,r)):r>=e.tintHoldUntil&&(e.tintFrom={...e.tintTarget},e.tintTarget={...ee},e.tintTween=$e(0,1,bt),Xe(e.tintTween,r),e.tintHoldUntil=r+fo)):(e.tintFrom={...ee},e.tintTarget={...ee},e.tintTween=$e(0,1,bt),Xe(e.tintTween,r),e.tintHoldUntil=Z?0:r+fo),ao(e.tintTween,r);const te=e.tintTween.val;let I,O,W;if(Z)I=Math.round(e.tintFrom.r+(e.tintTarget.r-e.tintFrom.r)*te),O=Math.round(e.tintFrom.g+(e.tintTarget.g-e.tintFrom.g)*te),W=Math.round(e.tintFrom.b+(e.tintTarget.b-e.tintFrom.b)*te);else{const F=e.tintFrom.r+(e.tintTarget.r-e.tintFrom.r)*te,q=e.tintFrom.g+(e.tintTarget.g-e.tintFrom.g)*te,$=e.tintFrom.b+(e.tintTarget.b-e.tintFrom.b)*te,ae=Math.max(F,q,$)||1;I=Math.round(255*(F/ae)),O=Math.round(255*(q/ae)),W=Math.round(255*($/ae))}const V=`rgb(${I},${O},${W})`;let U="#ffffff";if(Z){const F=Io(I,O,W),[q,$,ae]=Fo(F[0],Math.min(1,F[1]*kn),Math.max(En,F[2]*Tn));U=`rgb(${q},${$},${ae})`}const oe=Math.max(0,Math.min(1,n))*(e.pointMode?R.pointGain:1),ne=Math.min(1,e.glowOpacity*R.haloOpMul*oe),ue=Math.min(1,e.glowOpacity*R.extraIntensity*oe);if(Math.abs(e.relocMul-e.dEnv)>.002){const F=e.relocMul>=.998&&e.dEnv<.998;e.dEnv=e.relocMul,e.env.style.opacity=e.relocMul.toFixed(3),F&&(e.dirty=!0)}const le=!!(e.relocTween&&!e.relocTween.done)||e.cursorMode,de=!(Math.abs(Y-e.dX)<it&&Math.abs(H-e.dY)<it&&Math.abs(S-e.dAng)<On&&Math.abs(_-e.dEX)<it&&Math.abs(k-e.dEY)<it),he=!(Math.abs(ne-e.dHOp)<mo&&Math.abs(ue-e.dEOp)<mo),ve=V!==e.dHaloTint||U!==e.dExtraTint;return(e.dirty||de||he||ve)&&(e.dX=Y,e.dY=H,e.dAng=S,e.dEX=_,e.dEY=k,e.dHOp=ne,e.dEOp=ue,e.dHaloTint=V,e.dExtraTint=U,e.dirty=!1,Un(e,Y,H,S,_,k,ne,ue,V,U)),le}function Un(e,t,r,n,o,i,a,l,s,c){const{ctx:u,canvas:d,dpr:f,margin:m}=e;if(u.setTransform(1,0,0,1,0,0),u.globalCompositeOperation="source-over",u.globalAlpha=1,u.clearRect(0,0,d.width,d.height),a<=.002&&l<=.002||!e.maskReady)return;const g=a>.002?co(e.halo,...go(s),e.haloTint):null,p=l>.002?c==="#ffffff"?e.extra.canvas:co(e.extra,...go(c),e.extraTint):null,M=y=>{g&&(u.save(),u.translate(t+m,r+m),u.rotate(n),u.globalAlpha=a*y,u.drawImage(g,-e.halo.ax,-e.halo.ay,e.halo.w,e.halo.h),u.restore()),p&&(u.save(),u.translate(o+m,i+m),u.rotate(n),u.globalAlpha=l*y,u.drawImage(p,-e.extra.ax,-e.extra.ay,e.extra.w,e.extra.h),u.restore())};if(!e.pointMode&&e.surroundPath&&e.bandPath){u.save(),u.scale(f,f),u.clip(e.surroundPath,"evenodd"),M(.5),u.restore(),u.save(),u.scale(f,f),u.clip(e.bandPath,"evenodd"),M(1),u.restore();return}u.save(),u.scale(f,f),M(1),u.restore();const b=e.maskAlpha;if(!b)return;const v=u.getImageData(0,0,d.width,d.height),h=v.data;for(let y=0,w=3;y<b.length;y++,w+=4){const E=b[y];if(E!==255){if(E===0){h[w]=0;continue}h[w]=(h[w]*E+127)/255}}u.putImageData(v,0,0)}const Fe=[255,255,255];function go(e){if(e[0]==="#")return Fe[0]=parseInt(e.slice(1,3),16),Fe[1]=parseInt(e.slice(3,5),16),Fe[2]=parseInt(e.slice(5,7),16),Fe;let t=4,r=0,n=0;for(;t<e.length&&n<3;){const o=e.charCodeAt(t++);o>=48&&o<=57?r=r*10+(o-48):(o===44||o===41)&&(Fe[n++]=r,r=0)}return Fe}function zn(e,t){e.pointMode===t.pointMode&&(t.currentIdx=Math.min(e.currentIdx,Math.max(0,t.perim.length-1)),t.appearedAt=e.appearedAt,t.glowOpacity=e.glowOpacity,t.relocTween=e.relocTween,t.relocNextIdx=e.relocNextIdx,t.relocMul=e.relocMul,t.envClock=e.envClock,t.cursorMode=e.cursorMode,t.cursorArc=e.cursorArc,t.cursorTargetArc=e.cursorTargetArc,t.lastTickMs=e.lastTickMs,t.wanderS=e.wanderS,t.wanderTargetS=e.wanderTargetS,t.wanderFrames=e.wanderFrames,t.tintFrom=e.tintFrom,t.tintTarget=e.tintTarget,t.tintTween=e.tintTween,t.tintHoldUntil=e.tintHoldUntil,t.dEnv=e.relocMul,t.env.style.opacity=e.relocMul.toFixed(3))}const xo=Object.freeze({offsetY:1,blur:.5,alpha:.9,color:"#ffffff"});function Nn(e,t,r){const n=Math.min(3,typeof window<"u"&&window.devicePixelRatio||1),o=Math.ceil(3*r.blur+Math.abs(r.offsetY)+1),i=t.width+2*o,a=t.height+2*o,l=document.createElement("canvas");l.className="metal-fx-rim-canvas",l.setAttribute("aria-hidden","true"),l.width=Math.ceil(i*n),l.height=Math.ceil(a*n),l.style.cssText=`position:absolute;left:${-o}px;top:${-o}px;width:${i}px;height:${a}px;pointer-events:none`;const s=l.getContext("2d"),c=document.createElement("canvas");c.width=l.width,c.height=l.height;const u=c.getContext("2d",{willReadFrequently:!0});if(!s||!u)return null;e.appendChild(l);const d={canvas:l,ctx:s,scratch:c,sctx:u,width:t.width,height:t.height,cornerRadius:t.cornerRadius,kind:t.kind,ring:t.ring,margin:o,dpr:n,opts:r,mO:We(),mI:We(),sum:Number.NaN};return nr(d,null,!0),d}function vo(e,t,r){const n=t.xy;for(let o=0;o<t.n;o++){const i=n[o*2]+r,a=n[o*2+1]+r;o===0?e.moveTo(i,a):e.lineTo(i,a)}e.closePath()}function nr(e,t,r=!1){const{width:n,height:o,cornerRadius:i,ring:a,margin:l,dpr:s}=e;De(0,0,n,o,i,t,e.mO),De(a,a,n-2*a,o-2*a,Math.max(0,i-a),t,e.mI);let c=0;const u=e.mO.xy;for(let C=0;C<e.mO.n;C+=4)c+=u[C*2]*1.37+u[C*2+1];if(!r&&c===e.sum)return;e.sum=c;const{sctx:d,scratch:f,ctx:m,canvas:g,opts:p}=e,M=f.width,b=f.height;d.setTransform(1,0,0,1,0,0),d.clearRect(0,0,M,b),d.scale(s,s),d.fillStyle="#fff",d.beginPath(),vo(d,e.mO,l),vo(d,e.mI,l),d.fill("evenodd");const v=d.getImageData(0,0,M,b).data,h=M*b,y=new Float32Array(h);for(let C=0,G=3;C<h;C++,G+=4)y[C]=v[G]/255;const w=Math.round(p.offsetY*s)*M,E=new Float32Array(h);if(w>=0)for(let C=0;C<h;C++)E[C]=Math.max(0,y[C]-(C>=w?y[C-w]:0));else for(let C=0;C<h;C++)E[C]=Math.max(0,y[C]-(C-w<h?y[C-w]:0));const A=ht(E,M,b,p.blur*s),P=parseInt(p.color.slice(1,3),16),B=parseInt(p.color.slice(3,5),16),X=parseInt(p.color.slice(5,7),16),L=m.createImageData(M,b),N=L.data;for(let C=0,G=0;C<h;C++,G+=4)N[G]=P,N[G+1]=B,N[G+2]=X,N[G+3]=Math.round(Math.min(1,A[C]*y[C]*p.alpha)*255);m.setTransform(1,0,0,1,0,0),m.putImageData(L,0,0)}function wo(e){e&&e.canvas.remove()}const lt=12,bo=32,yo=1,Mo=.55,Vn=1,Wn=1,Dn=.85,Gn=0,Hn=1.3,_o=3.6,$n=.7,Xn=1,Yn=.52,jn=1,qn=.044,Qn=235,Jn=2.535,Ro=.7,Kn=.5,Zn=new Set(["INPUT","TEXTAREA","SELECT","OPTION"]);function ea(e,t){const r=Math.max(e.left-t.right,t.left-e.right,0),n=Math.max(e.top-t.bottom,t.top-e.bottom,0);return Math.sqrt(r*r+n*n)}function ta(e,t,r,n){return!(Math.min(e.bottom,t.bottom)-Math.max(e.top,t.top)<r||Math.max(e.left-t.right,t.left-e.right,0)>n)}function oa(e,t,r,n){return Math.min(e.right,t.right)-Math.max(e.left,t.left)<r?!1:Math.max(e.top-t.bottom,t.top-e.bottom,0)<=n}function Ee(e,t,r,n,o,i){const a=Math.max(0,Math.min(i,n*.5,o*.5)),l=e.roundRect;if(typeof l=="function"){l.call(e,t,r,n,o,a);return}e.moveTo(t+a,r),e.lineTo(t+n-a,r),e.quadraticCurveTo(t+n,r,t+n,r+a),e.lineTo(t+n,r+o-a),e.quadraticCurveTo(t+n,r+o,t+n-a,r+o),e.lineTo(t+a,r+o),e.quadraticCurveTo(t,r+o,t,r+o-a),e.lineTo(t,r+a),e.quadraticCurveTo(t,r,t+a,r)}function ar(e,t,r,n,o){if(!o.flipX&&!o.flipY){e.drawImage(t,o.sx??0,o.sy??0,r,n,o.x,o.y,o.w,o.h);return}e.save(),o.flipX&&(e.translate(o.x+o.w,0),e.scale(-1,1)),o.flipY&&(e.translate(0,o.y+o.h),e.scale(1,-1)),e.drawImage(t,o.sx??0,o.sy??0,r,n,o.flipX?0:o.x,o.flipY?0:o.y,o.w,o.h),e.restore()}const ra=4;function na(e,t,r,n,o,i,a){if(n<=2*a||o<=2*a){e.beginPath(),Ee(e,t,r,n,o,i),e.clip();return}e.beginPath(),Ee(e,t,r,n,o,i),Ee(e,t+a,r+a,n-2*a,o-2*a,Math.max(0,i-a)),e.clip("evenodd")}function aa(e,t,r,n,o,i,a,l,s,c,u,d){const f=d??Math.max(1,Math.round((lt+ra*3)*u));let m=Math.max(0,a),g=!0;for(let p=0;p<3&&m>1e-4;p++){const M=Math.min(1,m);e.save(),na(e,c.x,c.y,c.w,c.h,c.r,f),e.globalCompositeOperation=g?"source-over":"lighter",g=!1,e.globalAlpha=M,ar(e,t,r,n,s),e.globalAlpha=1,e.globalCompositeOperation="destination-in",e.fillStyle=l,e.fillRect(0,0,o,i),e.restore(),m-=M}}function ir(e,t,r,n,o,i,a){const l=a|0;if(l<1||n<=2*l||o<=2*l){e.beginPath(),Ee(e,t,r,n,o,i),e.clip();return}e.beginPath(),Ee(e,t,r,n,o,i),Ee(e,t+l,r+l,n-2*l,o-2*l,Math.max(0,i-l)),e.clip("evenodd")}function ia(e,t,r,n,o,i,a,l,s,c,u,d){let f=l*u,m=!0;for(let g=0;g<3&&f>1e-4;g++){const p=Math.min(1,f);e.save(),ir(e,a.x,a.y,a.w,a.h,a.r,s),e.globalCompositeOperation=m?"source-over":"lighter",m=!1,e.globalAlpha=p,ar(e,t,r,n,d),e.globalAlpha=1,e.globalCompositeOperation="destination-in",e.fillStyle=c,e.fillRect(0,0,o,i),e.restore(),f-=p}}function sa(e,t,r,n,o,i,a,l){const s=e.createLinearGradient(n,o,i,a);s.addColorStop(0,`rgba(255,255,255,${l.toFixed(3)})`),s.addColorStop(.5,`rgba(255,255,255,${(l*.45).toFixed(3)})`),s.addColorStop(1,"rgba(255,255,255,0)"),e.save(),ir(e,t.x,t.y,t.w,t.h,t.r,r),e.globalCompositeOperation="lighter",e.lineWidth=r*2,e.strokeStyle=s,e.beginPath(),Ee(e,t.x,t.y,t.w,t.h,t.r),e.stroke(),e.restore()}function sr(e){const t=getComputedStyle(e),r=[parseFloat(t.borderTopLeftRadius)||0,parseFloat(t.borderTopRightRadius)||0,parseFloat(t.borderBottomRightRadius)||0,parseFloat(t.borderBottomLeftRadius)||0].filter(n=>n>0);return r.length?Math.min.apply(null,r):0}function lr(e){const t=getComputedStyle(e),r=Math.max(parseFloat(t.borderTopWidth)||0,parseFloat(t.borderRightWidth)||0,parseFloat(t.borderBottomWidth)||0,parseFloat(t.borderLeftWidth)||0);let n=0,o=0;const i=t.boxShadow;if(i&&i!=="none"){const l=i.replace(/rgba?\([^)]*\)/g,u=>u.replace(/,/g,"\0")).split(/,\s*/);let s=1/0,c=1/0;for(const u of l){const d=u.match(/-?\d+(?:\.\d+)?px/g);if(!d||d.length<4)continue;const f=parseFloat(d[3]);f>0&&(/\binset\b/.test(u)?f<s&&(s=f):f<c&&(c=f))}Number.isFinite(s)&&(n=s),Number.isFinite(c)&&(o=c)}const a=Math.max(r,o);return{width:Math.max(r,n,o)||1,outerCssPx:a}}function Co(e){e.cornerRadius=sr(e.el);const t=lr(e.el);e.hairlineWidth=t.width,e.hairlineOuterCssPx=t.outerCssPx}function la(e){typeof ResizeObserver<"u"&&(e.resizeObserver=new ResizeObserver(()=>Co(e)),e.resizeObserver.observe(e.el)),typeof MutationObserver<"u"&&(e.mutationObserver=new MutationObserver(()=>Co(e)),e.mutationObserver.observe(e.el,{attributes:!0,attributeFilter:["style","class"]}))}function ca(e){var t,r;(t=e.resizeObserver)==null||t.disconnect(),e.resizeObserver=null,(r=e.mutationObserver)==null||r.disconnect(),e.mutationObserver=null}const _e=new Set,ua=Object.freeze({enabled:!0,radius:11.5,strength:.57,penumbra:.55,falloff:.21,edgeFade:.7,softness:.24,repaintMs:36}),ft={...ua};let be=null,Mt=0,So=0,ko=!1;function qt(){Mt!==0||typeof requestAnimationFrame>"u"||(Mt=requestAnimationFrame(e=>{if(Mt=0,e-So<ft.repaintMs){qt();return}So=e,ur()}))}let dt=!1;function da(e,t){const r=ft.radius;for(const n of _e){const o=n.anchorEl.getBoundingClientRect(),i=n.el.getBoundingClientRect(),a=Math.min(o.left,i.left)-r,l=Math.max(o.right,i.right)+r,s=Math.min(o.top,i.top)-r,c=Math.max(o.bottom,i.bottom)+r;if(e>=a&&e<=l&&t>=s&&t<=c)return!0}return!1}function To(e){if(be={x:e.clientX,y:e.clientY},!ft.enabled)return;const t=da(e.clientX,e.clientY);(t||dt)&&qt(),dt=t}function st(){be=null,dt&&qt(),dt=!1}function cr(e){typeof document>"u"||e===ko||(ko=e,e?(document.addEventListener("pointermove",To,{passive:!0}),document.addEventListener("pointerleave",st),window.addEventListener("blur",st)):(document.removeEventListener("pointermove",To),document.removeEventListener("pointerleave",st),window.removeEventListener("blur",st),be=null))}function ha(e,t,r,n,o,i,a,l,s){if(!be)return;const c=ft;if(!c.enabled||c.strength<=0)return;const u=c.radius;let d,f,m,g,p,M;if(o){const S=r.left>=n.right;d=S?n.right:r.right,f=S?r.left:n.left,m=be.x,g=be.y,p=Math.max(r.top,n.top),M=Math.min(r.bottom,n.bottom)}else{const S=r.top>=n.bottom;d=S?n.bottom:r.bottom,f=S?r.top:n.top,m=be.y,g=be.x,p=Math.max(r.left,n.left),M=Math.min(r.right,n.right)}const b=Math.min(d,f),v=Math.max(d,f),h=Math.max(1,v-b);if(m<b-u||m>v+u||g<p-u||g>M+u)return;const y=Math.max(0,Math.min(1,Math.abs(m-d)/h)),w=Math.max(.5,u*c.edgeFade),E=Math.min(1,Math.min(m-(b-u),v+u-m)/w),A=Math.min(1,Math.min(g-(p-u),M+u-g)/w),P=c.strength*(1-c.falloff*y)*E*A;if(P<=.001)return;const B=u*s*(1+c.penumbra*y),X=o?(g-n.top+l)*s:(g-n.left+l)*s,L=Math.max(0,Math.min(.5,(1-c.softness)*.5)),N=Math.max(.001,.5-L),C=o?a:i,G=Math.max(0,Math.floor(X-B)),Y=Math.min(C,Math.ceil(X+B));if(Y<=G)return;const H=new Float32Array(Y-G);for(let S=G;S<Y;S++){const _=(S+.5-(X-B))/(2*B),k=_<N?_/N:_>1-N?(1-_)/N:1;H[S-G]=1-P*Math.max(0,Math.min(1,k))}for(const S of[e,t]){const _=o?0:G,k=o?G:0,Z=o?i:Y-G,ee=o?Y-G:a,te=S.getImageData(_,k,Z,ee),I=te.data;if(o)for(let O=0;O<ee;O++){const W=H[O];if(!(W>=.999))for(let V=O*Z*4+3,U=(O+1)*Z*4;V<U;V+=4)I[V]=I[V]*W}else for(let O=0;O<ee;O++)for(let W=0;W<Z;W++){const V=H[W];if(V>=.999)continue;const U=(O*Z+W)*4+3;I[U]=I[U]*V}S.putImageData(te,_,k)}}let me=null,Le=null,Ue=null,ze=null;function fa(e,t){return me||(me=document.createElement("canvas"),Le=document.createElement("canvas"),Ue=me.getContext("2d",{alpha:!0}),ze=Le.getContext("2d",{alpha:!0})),!Ue||!ze||!me||!Le?!1:(me.width!==e&&(me.width=e,Le.width=e),me.height!==t&&(me.height=t,Le.height=t),Ue.setTransform(1,0,0,1,0,0),ze.setTransform(1,0,0,1,0,0),Ue.globalCompositeOperation="source-over",ze.globalCompositeOperation="source-over",Ue.clearRect(0,0,e,t),ze.clearRect(0,0,e,t),!0)}function ma(e,t,r,n=1){if(typeof document>"u"||Zn.has(e.tagName))return null;for(const g of _e)if(g.el===e)return g.strength=n,g;const o=document.createElement("div");o.setAttribute("data-metal-fx-reflection",""),o.setAttribute("aria-hidden","true");const i=document.createElement("canvas");i.className="metal-fx-reflection-canvas";const a=i.getContext("2d",{alpha:!0,willReadFrequently:!0});if(!a)return null;const l=document.createElement("canvas");l.className="metal-fx-reflection-stroke-canvas";const s=l.getContext("2d",{alpha:!0,willReadFrequently:!0});if(!s)return null;o.appendChild(i),o.appendChild(l);const c=getComputedStyle(e);let u=!1;c.position==="static"&&(e.style.position="relative",u=!0);let d=!1;c.isolation!=="isolate"&&(e.style.isolation="isolate",d=!0),e.setAttribute("data-metal-fx-reflect-host",""),e.insertBefore(o,e.firstChild);const f=lr(e),m={el:e,anchor:t,anchorEl:r,strength:n,wrap:o,canvas:i,ctx:a,strokeCanvas:l,strokeCtx:s,cornerRadius:sr(e),hairlineWidth:f.width,hairlineOuterCssPx:f.outerCssPx,appliedPositionRelative:u,appliedIsolation:d,resizeObserver:null,mutationObserver:null};return la(m),_e.add(m),cr(!0),m}function pa(e){for(const t of _e)if(t.el===e){ca(t),t.canvas.width=0,t.canvas.height=0,t.strokeCanvas.width=0,t.strokeCanvas.height=0,t.wrap.parentNode===t.el&&t.el.removeChild(t.wrap),t.el.removeAttribute("data-metal-fx-reflect-host"),t.appliedPositionRelative&&(t.el.style.position=""),t.appliedIsolation&&(t.el.style.isolation=""),_e.delete(t),_e.size===0&&cr(!1);return}}function ga(e,t,r,n,o){if(n<1||o<1)return null;const i=e.getContext("2d");if(!i)return null;const a=i.getImageData(t,r,n,o).data;let l=n,s=o,c=-1,u=-1;for(let d=0;d<o;d++){const f=d*n;for(let m=0;m<n;m++)a[(f+m)*4+3]>8&&(m<l&&(l=m),m>c&&(c=m),d<s&&(s=d),d>u&&(u=d))}return c<0?null:{x:t+l,y:r+s,w:c-l+1,h:u-s+1}}function ur(){if(_e.size===0)return;const e=typeof window<"u"&&window.devicePixelRatio||1,t=new Map;for(const r of _e){const n=r.el.getBoundingClientRect();let o=t.get(r.anchorEl);if(o||(o=r.anchorEl.getBoundingClientRect(),t.set(r.anchorEl,o)),n.width<1||n.height<1||o.width<1||o.height<1)continue;const i=r.el.hasAttribute("data-metal-fx-text");if(i&&!r.glyphStyled&&(r.canvas.style.filter="blur(0.4px) saturate(1.35) brightness(1.2)",r.glyphStyled=!0),!ta(o,n,yo,bo)&&!oa(o,n,yo,bo)){r.canvas.width!==1&&(r.canvas.width=1,r.canvas.height=1),r.strokeCanvas.width!==1&&(r.strokeCanvas.width=1,r.strokeCanvas.height=1);continue}const a=i&&!!r.anchor.mask;a&&!r.anchor.wantRaw&&(r.anchor.wantRaw=!0),r.anchor.wantRing||(r.anchor.wantRing=!0);const l=!!r.anchor.deform&&!!r.anchor.ringCanvas,s=a&&r.anchor.rawCanvas?r.anchor.rawCanvas:l?r.anchor.ringCanvas:r.anchor.canvas,c=Math.round(r.anchor.overscan*e);let u=c,d=c,f=(s.width|0)-2*c,m=(s.height|0)-2*c;if(r.anchor.mask&&!a){const ee=ga(s,u,d,f,m);ee&&(u=ee.x,d=ee.y,f=ee.w,m=ee.h)}if(f<4||m<4)continue;const g=(o.left+o.right)*.5,p=(o.top+o.bottom)*.5,M=(n.left+n.right)*.5,b=(n.top+n.bottom)*.5,v=g-M,h=p-b,y=Math.max(o.left-n.right,n.left-o.right,0),w=Math.max(o.top-n.bottom,n.top-o.bottom,0),E=y>=w,A=ea(o,n);let P=1-Math.min(1,A/lt);P=P*P*(3-2*P);const B=Mo+(Vn-Mo)*P,X=Math.min(_o,B*Hn*$n)*r.strength,L=o.left>=n.left&&o.right<=n.right&&o.top>=n.top&&o.bottom<=n.bottom?[!0,!1]:[E],N=r.anchor.scale??1,C=Math.max(Xn*N,r.hairlineWidth),G=Math.max(1,Math.round(C*e)),Y=Math.max(1,Math.round(Math.max(jn*N,r.hairlineWidth)*e)),H=r.hairlineOuterCssPx;r.wrap.style.inset=`${-H}px`,r.wrap.style.borderRadius=`${Math.max(0,r.cornerRadius)}px`;const S=Math.max(1,Math.round((n.width+H*2)*e)),_=Math.max(1,Math.round((n.height+H*2)*e));r.canvas.width!==S&&(r.canvas.width=S),r.canvas.height!==_&&(r.canvas.height=_),r.strokeCanvas.width!==S&&(r.strokeCanvas.width=S),r.strokeCanvas.height!==_&&(r.strokeCanvas.height=_);const k=r.ctx;k.setTransform(1,0,0,1,0,0),k.clearRect(0,0,S,_);const Z=r.strokeCtx;Z.setTransform(1,0,0,1,0,0),Z.clearRect(0,0,S,_);for(const[ee,te]of L.entries()){const I=ee>0&&fa(S,_),O=I?Ue:k,W=I?ze:Z,V=Math.min((i?lt*1.5:lt)*e,Math.max(S,_));let U,oe,ne,ue;te?(U=v>0?S:0,ne=v>0?S-V:V,oe=_*.5,ue=_*.5):(oe=h>0?_:0,ue=h>0?_-V:V,U=S*.5,ne=S*.5);const le=k.createLinearGradient(U,oe,ne,ue);le.addColorStop(0,`rgba(0,0,0,${Wn})`),le.addColorStop(.5,`rgba(0,0,0,${Dn})`),le.addColorStop(1,`rgba(0,0,0,${Gn})`);const de=f/e,he=i?Math.max(1,Math.min(te?S:_,Math.round(te?f:m))):Math.max(1,Math.round(Qn*Math.max(.1,de/140)*e));let ve,F,q,$,ae=!1,He=!1;if(te){const D=Math.max(o.top,n.top),j=Math.min(o.bottom,n.bottom);ae=!0,ve=v>0?S-he:0,F=Math.round((D-n.top+H)*e),q=he,$=Math.max(1,Math.round((j-D)*e))}else{const D=Math.max(o.left,n.left),j=Math.min(o.right,n.right);He=!0,ve=Math.round((D-n.left+H)*e),F=h>0?_-he:0,q=Math.max(1,Math.round((j-D)*e)),$=he}const et={x:ve,y:F,w:q,h:$,flipX:ae,flipY:He,sx:u,sy:d},we={x:0,y:0,w:S,h:_,r:Math.max(0,r.cornerRadius*e)},T=i?Math.min(1,X*Ro):Math.min(_o,X*Jn*Ro*Kn);aa(O,s,f,m,S,_,T,le,et,we,e,i?Math.max(S,_):void 0),i||(ia(W,s,f,m,S,_,we,X,G,le,Yn,et),sa(W,we,Y,U,oe,ne,ue,Math.min(.85,qn*X))),I&&(k.globalCompositeOperation="lighter",k.drawImage(me,0,0),Z.globalCompositeOperation="lighter",Z.drawImage(Le,0,0))}for(const ee of L)ha(k,Z,o,n,ee,S,_,H,e);k.globalCompositeOperation="source-over",Z.globalCompositeOperation="source-over"}}let _t=!1,Eo=0;function xa(){_t||(_t=!0,!(typeof requestAnimationFrame>"u")&&requestAnimationFrame(e=>{_t=!1,!(e-Eo<wr)&&(Eo=e,ur())}))}const Bo="metal-fx-styles",va=`
.metal-fx-root {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  isolation: isolate;
  overflow: visible;
  background: #272727;
  color: #f8f8f8;
}
.metal-fx-root[data-theme='light'] {
  background: #ffffff;
  color: #1d1d1d;
}

.metal-fx-root::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  pointer-events: none;
  z-index: 2;
  box-shadow: inset 0 0 50px 0 rgba(255, 255, 255, 0.02);
}
.metal-fx-root[data-theme='light']::before {
  box-shadow: inset 0 0 50px 0 rgba(0, 0, 0, 0.02);
}

.metal-fx-root::after {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  pointer-events: none;
  z-index: 4;
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.1);
}
.metal-fx-root[data-theme='light']::after {
  box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.06);
}
/* Circle variant gets a thicker outer rim than the button variant. */
.metal-fx-root[data-variant='circle']::after {
  box-shadow: inset 0 0 0 2px rgba(255, 255, 255, 0.1);
}
.metal-fx-root[data-theme='light'][data-variant='circle']::after {
  box-shadow: inset 0 0 0 2px rgba(0, 0, 0, 0.06);
}

.metal-fx-canvas {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  display: block;
  z-index: 0;
  pointer-events: none;
  border-radius: inherit;
}

/* The inner spacer — defines the inset geometry where the metal ring meets
   the interior (3 px for Button, 1-2 px for Circle) and carries the Circle dark
   hairline ('box-shadow: inset' rules below). Intentionally transparent so
   the wrapper's background propagates through to the punched shader centre,
   giving consumers a single surface tone to override. See "Single-surface
   background" in the file header for the rationale. */
.metal-fx-inner {
  position: absolute;
  inset: 3px;
  border-radius: inherit;
  z-index: 1;
  pointer-events: none;
}

.metal-fx-root[data-variant='button'][data-shape='pill'] .metal-fx-inner {
  border-radius: calc(var(--mfx-radius, 20px) - 3px);
}
.metal-fx-root[data-variant='button'][data-shape='circle'] .metal-fx-inner {
  border-radius: calc(var(--mfx-radius, 16px) - 3px);
}
.metal-fx-root[data-variant='circle'][data-shape='pill'] .metal-fx-inner {
  inset: 0;
  border-radius: var(--mfx-radius, 20px);
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.45);
}
.metal-fx-root[data-variant='circle'][data-shape='circle'] .metal-fx-inner {
  inset: 0;
  border-radius: var(--mfx-radius, 16px);
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.45);
}
/* Circle-variant hairline alpha — light mode.
   Source-of-truth: index.html L2261-2267. The 0.45-alpha black inset that
   reads as a single-pixel frame against the dark interior is too heavy
   on a #ffffff inner: it ends up looking like a hard 2-px black ring
   against the iridescent shader. Suppressed entirely (alpha 0) — the
   shader's own iridescent rim already defines the silhouette in light
   mode, so an extra dark hairline only competes with it. The rule is
   kept (rather than deleted) as a tunable hook in case a future variant
   wants to re-introduce a soft edge. NOTE: we keep the dark-mode inset
   and border-radius values because — unlike index.html — our renderer
   does NOT overscan the canvas in light mode, so there is no 1-px gap
   between inner element and shader to compensate for. */
.metal-fx-root[data-theme='light'][data-variant='circle'][data-shape='pill'] .metal-fx-inner,
.metal-fx-root[data-theme='light'][data-variant='circle'][data-shape='circle'] .metal-fx-inner {
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0);
}

/* ─── Combined glow SVG (z=3) ──────────────────────────────────────────────
   Single SVG per instance that holds BOTH the wide-halo group
   (#mfx_haloTravel) and the catch-light group (#mfx_extraTravel), exactly
   mirroring canonical's _buildGlowSvgInner (index.html L8078). One
   mix-blend-mode: screen lifts the combined composite onto the shader
   ring; per-frame opacity attributes on each inner group still drive the
   independent fade-in / fade-out cycles for the halo and the catch-light.

   Why a single SVG: the circle variant anchors halo + catch-light at the same
   perimeter point, so they overlap in the bright zone. Two separately-
   screened SVGs would double-screen the overlap (A + B + C - AB - AC -
   BC + ABC instead of A + B + C - AB - AC once both groups composite
   in source-over inside one SVG and then screen against the host once).
   That overlap looked muted versus canonical specifically on the circle
   variant where both layers travel together.

   Source-of-truth opacity: #btnGlowSvg drops to 0.7 in dark and 0.2746 in
   light (index.html L632/L643). */
.metal-fx-glow-svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
  z-index: 3;
  pointer-events: none;
  opacity: 0.7;
}
.metal-fx-root[data-theme='light'] .metal-fx-glow-svg {
  /* Light-mode 1-px overscan mirrors .btn-glow-svg in metal.html so the
     halo stays glued to the visible silhouette (the shader ring there sits
     1 px outside the host's padding box). */
  inset: -1px;
  width: calc(100% + 2px);
  height: calc(100% + 2px);
  mix-blend-mode: multiply;
  /* Source-of-truth: html[data-theme="light"] #btnGlowSvg { opacity: 0.2746 }
     → −35 % from 0.4225 from the original 0.7 dark-mode opacity. */
  opacity: 0.2746;
  filter: saturate(5.355) brightness(0.78);
}
/* Circle light-mode small variants (e.g. 36×36 send button): the geometrically
   shrunk halo loses density when multiplied against #ffffff. Mirror the
   canonical override at index.html L2316 — bump saturation + drop brightness
   so the small glow holds together visually. */
.metal-fx-root[data-variant='circle'][data-shape='circle'][data-theme='light'] .metal-fx-glow-svg {
  filter: saturate(7.5) brightness(0.6);
}

/* The wrapped child — hoisted into z=5 so it sits above every overlay, with
   normalized chrome so consumer button styles don't fight the metal frame. */
.metal-fx-content {
  position: relative;
  z-index: 5;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  pointer-events: none;
}
.metal-fx-content > * {
  pointer-events: auto;
}
.metal-fx-root[data-normalize='true'] .metal-fx-content > * {
  background: transparent !important;
  border: 0 !important;
  outline: 0 !important;
  box-shadow: none !important;
  /* Sizing: we deliberately DO NOT force \`width: 100%; height: 100%\` on the
     child here. That used to be the contract ("the wrapper is the visible
     button surface; the child stretches to fill it"), but it created a cyclic
     percentage dependency: the wrapper is \`inline-flex\` with no intrinsic
     size, .metal-fx-content is \`width/height: 100%\` of the wrapper, and the
     child was \`100%\` of .metal-fx-content. With nothing breaking the cycle,
     icon-only / class-sized children collapsed.

     The new contract: the child sizes itself (intrinsic content, CSS class,
     or inline style — all work), and the wrapper's \`inline-flex\` wraps it
     tightly. Consumers who want a metal frame BIGGER than the child (e.g.
     padding around an icon) size <MetalFx style={{ width, height }}> AND
     explicitly set width/height on the child to fill (or accept that the
     child renders at its intrinsic size, centered).

     Typography is intentionally NOT touched. We used to apply
     \`color: inherit; font: inherit;\` here to "match" the wrapper, but
     \`font: inherit\` is a shorthand that overrides font-family, font-size,
     font-weight, AND line-height on the child — which (a) shrank the
     button height (line-height changes propagate through the flex
     content box) and (b) scaled em-based icons / font-icons inside the
     child to whatever the wrapper inherited. The wrapper now stays out
     of the child's typography entirely; consumers who want typographic
     normalization can apply it themselves on the child element. */
}

[data-metal-fx-reflection] {
  position: absolute;
  inset: 0;
  pointer-events: none;
  border-radius: inherit;
  overflow: hidden;
  z-index: 0;
  isolation: isolate;
}
.metal-fx-reflection-canvas {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  display: block;
  filter: blur(4px) saturate(1.2) brightness(1.58);
}
.metal-fx-reflection-stroke-canvas {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  display: block;
  filter: saturate(1.35) brightness(1.75);
}
/* Hosts that participate as reflection targets need positioning + isolation
   so the wrap composites only against the host (not the parent stack). The
   wrap injects these inline as well, but stating them here keeps reflections
   working on hosts that already have other inline styles applied. */
[data-metal-fx-reflect-host] {
  isolation: isolate;
}
`;let Rt=!1;function wa(){if(Rt||typeof document>"u")return;if(document.getElementById(Bo)){Rt=!0;return}const e=document.createElement("style");e.id=Bo,e.textContent=va,document.head.appendChild(e),Rt=!0}wa();const ba={position:"absolute",inset:0,width:"100%",height:"100%"},ya={position:"absolute",inset:3},Ma={position:"absolute",inset:0,pointerEvents:"none",zIndex:3,borderRadius:"inherit"},_a={position:"absolute",inset:0,pointerEvents:"none",zIndex:4},Qe=new Map;function Ra(){const e=globalThis;e.__MFX_DEBUG__&&(e.__mfxGlow=Qe)}Qr((e,t)=>{const r=Qe.get(e);return r?Ln(r.handles,e,t,e.opacityMul*e.glowGain,r.themeRef.current):!1});function Ca(e){const[t,r]=z.useState(()=>e!=="auto"?e:typeof window>"u"||!window.matchMedia||window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");return z.useEffect(()=>{if(e!=="auto"){r(e);return}if(typeof window>"u"||!window.matchMedia)return;const n=window.matchMedia("(prefers-color-scheme: dark)"),o=()=>r(n.matches?"dark":"light");return o(),n.addEventListener("change",o),()=>n.removeEventListener("change",o)},[e]),t}const dr=z.forwardRef(function({children:e,variant:t="button",preset:r="chromatic",theme:n="auto",strength:o=1,glowGain:i=1,paused:a=!1,borderRadius:l,normalizeHostStyles:s=!0,reflectionTargets:c,disableGlow:u=!1,innerShadow:d,shaderScale:f,ringCssPx:m,scale:g=1,mask:p,glowMode:M="mask",className:b,style:v,...h},y){const w=z.useRef(null),E=z.useRef(null),A=z.useRef(null),P=z.useRef(null),B=z.useRef(null),X=z.useRef(null),L=z.useRef(null),N=z.useRef(null),C=z.useRef("dark"),G=z.useRef(0),[Y,H]=z.useState(!1),S=Ca(n),_=z.useMemo(()=>Ur(),[]);C.current=S;const k=t==="circle"?"circle":"pill",Z=!u;z.useImperativeHandle(y,()=>w.current,[]);const ee=(I,O)=>{if(k==="circle")return Math.min(I,O)/2;const W=typeof l=="number"?l:(()=>{var V;const U=(V=X.current)==null?void 0:V.firstElementChild;if(U){const oe=parseFloat(getComputedStyle(U).borderTopLeftRadius);if(Number.isFinite(oe)&&oe>0)return oe}return G.current})();return Math.min(W,Math.min(I,O)/2)};z.useEffect(()=>{_&&qr(r,S)},[r,S,_]),z.useEffect(()=>{const I=L.current;I&&Ie(I,{mask:p??null})},[p]),z.useEffect(()=>{const I=L.current;I&&Ie(I,{paused:a})},[a]),z.useEffect(()=>{const I=L.current;if(!I)return;const O={};f!==void 0&&(O.shaderScale=f),m!==void 0&&(O.ringCssPx=m),g!==void 0&&(O.scale=g),Object.keys(O).length>0&&Ie(I,O)},[f,m,g]),z.useLayoutEffect(()=>{const I=E.current,O=w.current,W=A.current;if(!I||!O||!_)return;{const T=getComputedStyle(O),D=parseFloat(T.borderTopLeftRadius);G.current=Number.isFinite(D)?D:0}const V=()=>{const T=O.getBoundingClientRect(),D=Math.max(1,Math.round(T.width)),j=Math.max(1,Math.round(T.height));return{cssWidth:D,cssHeight:j,cornerRadius:ee(D,j)}},U=V();L.current=Gr({onComposite:()=>{const T=L.current,D=N.current;T&&D&&Pn(D,T.deform);const j=B.current;T&&j&&nr(j,T.deform)},hostCanvas:I,cssWidth:U.cssWidth,cssHeight:U.cssHeight,cornerRadius:U.cornerRadius,kind:k,paused:a,shaderScale:f,ringCssPx:m,scale:g,mask:p??null,onFirstCopy:()=>H(!0)}),O.style.setProperty("--mfx-radius",`${U.cornerRadius}px`),O.style.borderRadius=`${U.cornerRadius}px`;const oe=(T,D)=>{if(!p||M==="ring")return{};const j=window.devicePixelRatio||1,re=document.createElement("canvas");re.width=Math.max(1,Math.round(T*j)),re.height=Math.max(1,Math.round(D*j));const tt=re.getContext("2d");if(!tt)return{};tt.fillStyle="#fff",p(tt,re.width,re.height,j);const mr=tt.getImageData(0,0,re.width,re.height).data,Qt=[],ot=Math.max(1,Math.round(2*j));for(let rt=ot>>1;rt<re.height;rt+=ot)for(let nt=ot>>1;nt<re.width;nt+=ot)mr[(rt*re.width+nt)*4+3]>128&&Qt.push({x:nt/j,y:rt/j});return{samplePoints:Qt,maskDataUrl:re.toDataURL("image/png")}};W&&(N.current=po(W,{width:U.cssWidth,height:U.cssHeight,cornerRadius:U.cornerRadius,kind:k,scale:g,...oe(U.cssWidth,U.cssHeight)}));const ne=T=>{if(!W)return;const D=N.current;W.innerHTML="",N.current=po(W,{width:T.cssWidth,height:T.cssHeight,cornerRadius:T.cornerRadius,kind:k,scale:g,...oe(T.cssWidth,T.cssHeight)}),D&&zn(D,N.current);const j=L.current;j&&N.current&&Qe.set(j,{handles:N.current,themeRef:C})},ue=()=>d?d===!0?xo:{...xo,...d}:null,le=T=>{const D=P.current,j=L.current;wo(B.current),B.current=null;const re=ue();!D||!j||!re||(B.current=Nn(D,{width:T.cssWidth,height:T.cssHeight,cornerRadius:T.cornerRadius,kind:k,ring:j.ringCssPx},re))};le(U);let de=0,he=U.cssWidth,ve=U.cssHeight,F=U.cornerRadius;const q=new ResizeObserver(()=>{de===0&&(de=requestAnimationFrame(()=>{de=0;const T=V(),D=L.current;!D||Math.abs(T.cssWidth-he)<.5&&Math.abs(T.cssHeight-ve)<.5&&Math.abs(T.cornerRadius-F)<.5||(he=T.cssWidth,ve=T.cssHeight,F=T.cornerRadius,Ie(D,{cssWidth:T.cssWidth,cssHeight:T.cssHeight,cornerRadius:T.cornerRadius}),O.style.setProperty("--mfx-radius",`${T.cornerRadius}px`),O.style.borderRadius=`${T.cornerRadius}px`,ne(T),le(T))}))});q.observe(O);let $=null;const ae=()=>{const T=L.current;if(T&&jr(T)){const D=V();ne(D),le(D)}He()},He=()=>{$==null||$.removeEventListener("change",ae),$=typeof window.matchMedia=="function"?window.matchMedia(`(resolution: ${window.devicePixelRatio||1}dppx)`):null,$==null||$.addEventListener("change",ae)};He();const et=on(T=>{T&&L.current&&ne(V())});let we=null;return typeof IntersectionObserver<"u"&&(we=new IntersectionObserver(T=>{const D=L.current;if(D)for(const j of T)Yr(D,j.isIntersecting)},{rootMargin:"64px"}),we.observe(O)),L.current&&N.current&&(Qe.set(L.current,{handles:N.current,themeRef:C}),$r(L.current)),nn(),Ra(),()=>{an(),wo(B.current),B.current=null,q.disconnect(),$==null||$.removeEventListener("change",ae),we==null||we.disconnect(),et(),de!==0&&cancelAnimationFrame(de);const T=L.current;T&&(Qe.delete(T),Xr(T),Hr(T)),L.current=null,N.current=null,W&&(W.innerHTML="")}},[k]),z.useEffect(()=>{const I=L.current;I&&Ie(I,{opacityMul:Math.max(0,Math.min(1,o)),glowGain:Math.max(0,i)})},[o,i,t]),z.useEffect(()=>{const I=L.current,O=w.current;if(!I||!O||!c||S!=="dark")return;I.onAfterFrame=xa;const W=c.flatMap(V=>{const U="current"in V?V:V.ref,oe="current"in V?1:V.strength??1;return U.current?[{el:U.current,strength:oe}]:[]});for(const{el:V,strength:U}of W)ma(V,I,O,U);return()=>{I.onAfterFrame=void 0;for(const{el:V}of W)pa(V)}},[c,S]),z.useEffect(()=>{const I=w.current,O=L.current;if(!I||!O)return;const W=ee(O.cssWidth,O.cssHeight);Ie(O,{cornerRadius:W}),I.style.setProperty("--mfx-radius",`${W}px`),I.style.borderRadius=`${W}px`},[l,S,t,k]);const te=z.useMemo(()=>({...v,"--mfx-strength":String(Math.min(1,Math.max(0,o))),opacity:Y?1:0,visibility:Y?"visible":"hidden",transition:Y?"opacity 0.15s ease-out":"none"}),[v,o,Y]);return _?se.jsxs("div",{...h,ref:w,className:b?`metal-fx-root ${b}`:"metal-fx-root","data-variant":t,"data-shape":k,"data-theme":S,"data-paused":a?"true":void 0,"data-normalize":s?"true":"false",style:te,children:[se.jsx("canvas",{ref:E,className:"metal-fx-canvas",style:ba}),se.jsx("div",{className:"metal-fx-inner","aria-hidden":"true",style:ya}),se.jsx("div",{ref:A,"aria-hidden":"true",style:{...Ma,display:Z?void 0:"none"}}),d?se.jsx("div",{ref:P,"aria-hidden":"true",style:_a}):null,se.jsx("div",{ref:X,className:"metal-fx-content",children:e})]}):se.jsx("div",{...h,ref:w,className:b?`metal-fx-fallback ${b}`:"metal-fx-fallback","data-metal-fx-unsupported":"",style:{display:"inline-flex",...v},children:e})});dr.displayName="MetalFx";function hr(e,t,r,n){const o=getComputedStyle(r),i=t.getBoundingClientRect(),a=document.createRange();a.selectNodeContents(r);const l=a.getBoundingClientRect();a.detach(),e.save(),e.scale(n,n),e.font=`${o.fontStyle} ${o.fontWeight} ${o.fontSize} ${o.fontFamily}`,e.textAlign="left",e.textBaseline="alphabetic";const s=r.textContent??"",c=e.measureText(s),u=c.fontBoundingBoxAscent??parseFloat(o.fontSize)*.9,d=c.fontBoundingBoxDescent??parseFloat(o.fontSize)*.2,f=l.left-i.left,m=l.top-i.top+(l.height-(u+d))/2+u;e.fillText(s,f,m),e.restore()}const fr={offsetY:1,blur:.5,alpha:.9},Ct=Object.freeze({metalOpacity:.62,shaderScale:2.8,glowGain:2.5,innerShadow:fr});function Sa(e,t,r,n){const o=window.devicePixelRatio||1,i=t.getBoundingClientRect(),a=Math.max(1,Math.round(i.width*o)),l=Math.max(1,Math.round(i.height*o)),s=document.createElement("canvas");s.width=a,s.height=l;const c=s.getContext("2d",{willReadFrequently:!0}),u=e.getContext("2d");if(!c||!u)return;c.fillStyle="#fff",hr(c,t,r,o);const d=c.getImageData(0,0,a,l).data,f=a*l,m=new Float32Array(f);for(let h=0,y=3;h<f;h++,y+=4)m[h]=d[y]/255;const g=Math.max(1,Math.round(n.offsetY*o))*a,p=new Float32Array(f);for(let h=0;h<f;h++){const y=h>=g?m[h-g]:0;p[h]=Math.max(0,m[h]-y)}const M=ht(p,a,l,n.blur*o);e.width=a,e.height=l,e.style.width=`${i.width}px`,e.style.height=`${i.height}px`;const b=u.createImageData(a,l),v=b.data;for(let h=0,y=0;h<f;h++,y+=4)v[y]=255,v[y+1]=255,v[y+2]=255,v[y+3]=Math.round(Math.min(1,M[h]*m[h]*n.alpha)*255);u.putImageData(b,0,0)}const Oo="mfx-bare-style",ka=".metal-fx-root[data-mfx-bare]{background:transparent!important}.metal-fx-root[data-mfx-bare]::before,.metal-fx-root[data-mfx-bare]::after{box-shadow:none!important}.metal-fx-root[data-mfx-bare] .metal-fx-inner{display:none!important}";function Ta({children:e,font:t,color:r,strength:n=1,theme:o,reflectionTargets:i,className:a,innerShadow:l=fr,glow:s=!1,glowGain:c=Ct.glowGain,metalOpacity:u=Ct.metalOpacity,shaderScale:d=Ct.shaderScale}){const f=z.useRef(null),m=z.useRef(null);z.useEffect(()=>{var M,b,v,h;if(!document.getElementById(Oo)){const E=document.createElement("style");E.id=Oo,E.textContent=ka,document.head.appendChild(E)}(M=f.current)==null||M.setAttribute("data-mfx-bare","");const y=(b=f.current)==null?void 0:b.querySelector("canvas.metal-fx-canvas");y&&(y.style.zIndex="6");const w=(h=(v=f.current)==null?void 0:v.querySelector(".metal-fx-glow-svg"))==null?void 0:h.parentElement;w&&(w.style.zIndex="7")},[]),z.useEffect(()=>{var M;const b=f.current,v=m.current;if(!b||!v||!l)return;const h=document.createElement("canvas");h.className="metal-fx-text-rim",h.setAttribute("aria-hidden","true"),h.style.cssText="position:absolute;left:0;top:0;pointer-events:none;z-index:8",b.appendChild(h);const y=()=>Sa(h,b,v,l);y();let w=!0;(M=document.fonts)==null||M.ready.then(()=>{w&&y()});const E=new ResizeObserver(y);E.observe(b);let A=null;const P=()=>{A==null||A.removeEventListener("change",B),A=typeof window.matchMedia=="function"?window.matchMedia(`(resolution: ${window.devicePixelRatio||1}dppx)`):null,A==null||A.addEventListener("change",B)},B=()=>{w&&(y(),P())};return P(),()=>{w=!1,E.disconnect(),A==null||A.removeEventListener("change",B),h.remove()}},[l]);const g=z.useCallback((M,b,v,h)=>{const y=f.current,w=m.current;y&&w&&hr(M,y,w,h)},[]),p={font:t,color:r,letterSpacing:0,whiteSpace:"nowrap"};return se.jsx(dr,{ref:f,preset:"chromatic",theme:o,strength:n*u,glowGain:c,disableGlow:!s,mask:g,reflectionTargets:i,shaderScale:d,borderRadius:4,style:{background:"transparent",borderRadius:4},children:se.jsx("span",{ref:m,className:a,style:p,"aria-label":e,children:e})})}const Ea=Object.freeze({enabled:!0,applyTo:"ring",strength:.74,fadeInMs:200,fadeOutMs:350,smoothMs:140,reach:36,blob:13,liquidBlob:10,maxDisp:9,gain:.6,pressGain:.55,pullGain:.49,press:5,liquid:7.5,liquidReach:8,liquidStiffness:53,liquidDamping:9,stiffness:260,damping:13,mass:1,follow:.32,mapRes:2,smooth:.25});({...Ea});const Ao={light:{base:"#E0468A",tint:"#ff4f9ed0"},dark:{base:"#FF7AB8",tint:"#ff8ac4d0"}},Ba={speed:1.8,distortion:.24,repetition:2.2,angle:70},Oa=1500;function Fa({text:e,size:t=30,className:r}){const n=gr(),o=xr(),i=z.useRef(null),[a,l]=z.useState(!1),[s]=z.useState(()=>{const u=getComputedStyle(document.documentElement).getPropertyValue("--font-display").trim()||"system-ui, sans-serif";return`900 ${t}px/1.15 ${u}`}),c=Ao[o].base;return z.useEffect(()=>{if(!n)return ro({...Gt.gold.modes[o],...Ba,colorTint:Ao[o].tint}),()=>ro(null)},[o,n]),z.useEffect(()=>{const u=i.current;if(n||a||!u)return;const d=document.createElement("span");u.appendChild(d);const f=pr.createRoot(d);f.render(se.jsx(Ta,{font:s,color:c,theme:o,strength:1,metalOpacity:.7,className:r,children:e}));let m=0;const g=()=>{if(document.hidden){document.addEventListener("visibilitychange",p,{once:!0});return}const M=d.querySelector(".metal-fx-root");(!M||getComputedStyle(M).opacity==="0")&&l(!0)},p=()=>{m=window.setTimeout(g,Oa)};return p(),()=>{window.clearTimeout(m),document.removeEventListener("visibilitychange",p),queueMicrotask(()=>{f.unmount(),d.remove()})}},[n,a,o,e,s,c,r]),n||a?se.jsx("span",{className:r,style:{font:s,color:c},children:e}):se.jsx("span",{ref:i,className:"inline-flex"})}export{Fa as default};
