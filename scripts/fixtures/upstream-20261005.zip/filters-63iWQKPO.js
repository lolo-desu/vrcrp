import{k as n,c7 as l,c8 as c}from"./index-ChaQPnFI.js";/**
 * @license lucide-react v1.48.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a={name:"sliders-horizontal",size:24,node:[["path",{d:"M10 5H3",key:"1qgfaw"}],["path",{d:"M12 19H3",key:"yhmn1j"}],["path",{d:"M14 3v4",key:"1sua03"}],["path",{d:"M16 17v4",key:"1q0r14"}],["path",{d:"M21 12h-9",key:"1o4lsq"}],["path",{d:"M21 19h-5",key:"1rlt1p"}],["path",{d:"M21 5h-7",key:"1oszz2"}],["path",{d:"M8 10v4",key:"tgpxqk"}],["path",{d:"M8 12H3",key:"a7s4jb"}]]};a.node;const d=n(a),h=l()(c(t=>({filters:{},setFilters:s=>t({filters:s}),reset:()=>t({filters:{}})}),{name:"erp_filters",version:2,migrate:(t,s)=>{const e=t??{};if(s<2&&e.filters){const{utcOffsetMin:i,utcOffsetMax:o,...r}=e.filters;e.filters=i!==void 0&&o!==void 0?{...r,nearTimezone:!0}:r}return e}}));function p(t){let s=0;for(const e of Object.values(t))(Array.isArray(e)?e.length>0:e!==void 0&&e!==!1&&e!==null)&&s++;return s}export{d as S,p as a,h as u};
